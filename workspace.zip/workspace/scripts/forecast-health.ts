import { SimEngine } from '../src/lib/sim'
import { forecastDemand } from '../src/lib/forecast'
import { optimize, forecastPreDispatch } from '../src/lib/optimizer'
import { healthBreakdown, dispatchCostFactor } from '../src/lib/health'
import { DEFAULT_CONFIGS, DEFAULT_PRICE, STATION_DEFAULTS } from '../src/lib/params'
import type { OptimizerContext, MachineState, CompressorConfig } from '../src/lib/types'

let pass = 0, fail = 0
const A = (cond: boolean, msg: string) => { if (cond) { pass++; console.log(' ✓', msg) } else { fail++; console.error(' ✗ FAIL:', msg) } }

const start = new Date(); start.setHours(10, 0, 0, 0)
const engine = new SimEngine({
  configs: DEFAULT_CONFIGS.map(c => ({ ...c })), price: { ...DEFAULT_PRICE },
  tankVolume: STATION_DEFAULTS.tankVolume, bandLow: STATION_DEFAULTS.bandLow, bandHigh: STATION_DEFAULTS.bandHigh,
  safeMin: STATION_DEFAULTS.safeMinPressure, headerOffset: STATION_DEFAULTS.headerOffset,
}, start.getTime() - 24 * 3600000)
engine.generateHistory(1440)

function mkCtx(over: Partial<OptimizerContext> = {}): OptimizerContext {
  const fc = forecastDemand(engine.history.map(p => p.demand), engine.simTime, ms => engine.demandAt(ms))
  return {
    configs: engine.configs, machines: engine.machines.map(m => ({ ...m })), demand: 420,
    forecast: fc, priceNow: 0.68, pricePeriod: 'flat', futurePrices: [],
    headerPressure: 7.5, tankPressure: 8.0, tankVolume: engine.tankVolume, safeMin: engine.safeMin,
    weights: { energy: 0.3, stability: 0.2, cycling: 0.12, health: 0.18, reserve: 0.1, efficiency: 0.1 },
    priceCfg: { ...DEFAULT_PRICE }, startedRecentlyIds: [], simTimeMs: engine.simTime,
    ...over,
  }
}

console.log('=== F1 负荷预测：30min/1h/4h 输出有效性 ===')
{
  const fc = forecastDemand(engine.history.map(p => p.demand), engine.simTime, ms => engine.demandAt(ms))
  A(Number.isFinite(fc.f30) && Number.isFinite(fc.f60) && Number.isFinite(fc.f240), `三档预测有限：30m=${fc.f30.toFixed(0)} / 1h=${fc.f60.toFixed(0)} / 4h=${fc.f240.toFixed(0)}`)
  A(Object.is(fc.values.length, 240) && fc.horizon.length === 240, '滚动预测序列 240 点（覆盖 4 小时）')
  A(fc.upper.every((u, i) => u >= fc.lower[i]), '置信区间上下界有序')
  A(Math.abs(fc.f30 - engine.demandNow) / engine.demandNow < 0.6, '30min 预测与当前需求同量级（预测稳定）')
}

console.log('=== F2 预测真正驱动调度（未来需求进入目标）===')
{
  const flat = mkCtx({ demand: 560, forecast: { ...mkCtx().forecast, f30: 560, f60: 560, f240: 560, trend: 'flat', trendPct: 0 } })
  const up = mkCtx({ demand: 560, forecast: { ...mkCtx().forecast, f30: 780, f60: 900, f240: 980, trend: 'up', trendPct: 40 } })
  const pFlat = optimize(flat).plans.find(p => p.key === 'A')!
  const pUp = optimize(up).plans.find(p => p.key === 'A')!
  A(pUp.totalFlow > pFlat.totalFlow + 50, `同一当前需求下，预测上行的方案供气 ${pUp.totalFlow} > 平稳的 ${pFlat.totalFlow}（调度提前放大目标）`)
  const upRec = optimize(up).plans.find(p => p.key === 'C')!
  const guarantee = Math.max(up.demand * 1.01, up.forecast.f30, up.forecast.f60 * 0.97) - 30
  A(upRec.supplyCapacity >= guarantee, `推荐方案能力 ${upRec.supplyCapacity} ≥ 调度保证值 ${guarantee.toFixed(0)}（含 f60 折扣与量化容差）`)
  A(upRec.supplyCapacity > pFlat.totalFlow + 50, `推荐方案能力较平稳预测显著提升（${pFlat.totalFlow} → ${upRec.supplyCapacity}）`)
}

console.log('=== F3 预测上升 → 提前增机提示 ===')
{
  const c = mkCtx({ demand: 620 })
  c.machines = c.machines.map((m, i) => ({ ...m, status: i === 0 ? 'running' as const : 'standby' as const, load: i === 0 ? 0.9 : 0, flow: i === 0 ? 450 : 0, power: i === 0 ? 80 : 0, runMinutes: 999, stopMinutes: 9999 }))
  c.forecast = { ...c.forecast, f30: 1200, f60: 1400, f240: 1500, trend: 'up', trendPct: 55 }
  const adv = forecastPreDispatch(c)
  A(adv !== null && adv.escalate, `运行能力 500 无法覆盖 1200 预测 → 触发提前增机：${adv?.reason.slice(0, 40)}...`)
  A(!!adv && adv.recommendStarts.length > 0 && !adv.recommendStarts.includes('A1'), `建议启动备机 ${adv?.recommendStarts.join('、')}（排除已在运行的 A1）`)
  A(!!adv && adv.supplyGap > 0 && adv.inMinutes === 30, `缺口 ${adv?.supplyGap} Nm³/h，提前量 30 分钟`)
  const ample = mkCtx({ demand: 420 })
  ample.machines = ample.machines.map(m => ({ ...m, status: 'running' as const, load: 0.5, flow: 250, power: 60, runMinutes: 999 }))
  ample.forecast = { ...ample.forecast, f30: 500, f60: 540, f240: 600, trend: 'flat', trendPct: 2 }
  A(forecastPreDispatch(ample) === null, '运力充足时不误报提前增机')
}

console.log('=== H1 健康度：七维评分 ===')
{
  const m = engine.machines.find(x => x.id === 'A2')!
  const cfg = engine.configs.find(x => x.id === 'A2')!
  const hb = healthBreakdown(cfg, m)
  A(hb.dims.length === 7, `七维明细：${hb.dims.map(d => d.label).join('/')}`)
  A(hb.dims.every(d => d.score >= 0 && d.score <= 100 && d.weight > 0), '各维分值/权重合法')
  const wsum = hb.dims.reduce((s, d) => s + d.weight, 0)
  A(Math.abs(wsum - 1) < 1e-6, `权重归一 ${wsum.toFixed(2)}`)
  A(Math.abs(hb.score - m.health) < 0.11, `评分与运行健康度一致（${hb.score} vs ${m.health.toFixed(1)}）`)
}

console.log('=== H2 健康度→调度成本系数（低健康更贵）===')
{
  const hi: MachineState = { ...engine.machines[0], health: 92 }
  const mid: MachineState = { ...engine.machines[0], health: 60 }
  const lo: MachineState = { ...engine.machines[0], health: 20 }
  A(dispatchCostFactor(hi) < dispatchCostFactor(mid) && dispatchCostFactor(mid) < dispatchCostFactor(lo),
    `成本系数单调：92分×${dispatchCostFactor(hi).toFixed(3)} < 60分×${dispatchCostFactor(mid).toFixed(3)} < 20分×${dispatchCostFactor(lo).toFixed(3)}`)
}

console.log('=== H3 低健康设备被调度主动回避（同等能耗下选健康机）===')
{
  const cfgs: CompressorConfig[] = engine.configs.map((c, i) => i === 0
    ? { ...c, id: 'A1', ratedFlow: 500, ratedPower: 90, baseEff: 0.985 }
    : i === 1
    ? { ...c, id: 'A2', ratedFlow: 600, ratedPower: 100, baseEff: 1.05 }
    : { ...c, ratedFlow: 1, ratedPower: 1 })
  const machines: MachineState[] = cfgs.map((c, i) => ({
    ...engine.machines[0], id: c.id, status: 'standby', load: 0, flow: 0, power: 0, runMinutes: 0, stopMinutes: 9999,
    health: i === 0 ? 90 : i === 1 ? 20 : 5, efficiency: c.baseEff,
  }))
  const c = mkCtx({ demand: 380, configs: cfgs, machines })
  c.forecast = { ...c.forecast, f30: 380, f60: 380, f240: 380 }
  c.weights = { energy: 1, stability: 0, cycling: 0, health: 0, reserve: 0, efficiency: 0 }
  const p = optimize(c).plans.find(x => x.key === 'A')!
  const rawA2Better = true
  void rawA2Better
  A(!p.units.some(u => u.id === 'A2'), `A2 原始能效更优但健康度 20，方案A 仍回避它（选 ${p.units.map(u => u.id).join('+')}）`)
}

console.log('=== H4 健康度异常下降 → 维护提醒（经 store 实时链路）===')
{
  process.env.NODE_NO_WARNINGS = '1'
  const { useStore } = await import('../src/store')
  const st = () => useStore.getState()
  st().adopt('auto')
  const idx = st().machines.findIndex(m => m.id === 'A4')
  // 模拟健康度骤降：直接压低运行健康度
  const eng = (await import('../src/store')).engine
  eng.machines[idx].health = 58
  for (let i = 0; i < 3; i++) st().tick()
  const hasMaint = st().maintenance.some(r => r.id === 'A4') || st().alerts.some(a => a.id.includes('maint-A4'))
  A(hasMaint, `A4 健康度 58（<60 关注区）触发维护提醒：${st().maintenance.find(r => r.id === 'A4')?.message.slice(0, 46) ?? st().alerts.find(a => a.id.includes('maint'))?.message.slice(0, 40)}`)
  A(st().preDispatch !== undefined, 'store 每 tick 输出预测提前调度提示字段')
}

console.log(`\nFORECAST-HEALTH: ${pass} passed, ${fail} failed`)
if (fail) process.exit(1)
