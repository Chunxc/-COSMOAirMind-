import * as React from 'react'
import { renderToString } from 'react-dom/server'
import { MemoryRouter } from 'react-router-dom'
import { useStore, engine } from '../src/store'
import { liveDispatchFlags, TENSE_THRESHOLDS } from '../src/lib/dashboard'
import Dashboard from '../src/pages/Dashboard'

let pass = 0, fail = 0
const A = (c: boolean, m: string) => { if (c) { pass++; console.log(' ✓', m) } else { fail++; console.error(' ✗ FAIL:', m) } }
const st = () => useStore.getState()

console.log('=== 1. 数据层：同 tick 同源一致 ===')
{
  st().resetAll(); st().adopt('auto')
  let ok = true
  for (let i = 0; i < 120; i++) {
    st().tick()
    const s = st(); const last = engine.history[engine.history.length - 1]
    if (Math.abs(last.header - s.station.header) > 1e-6 || Math.abs(last.demand - s.station.demand) > 1e-6 || Math.abs(last.supply - s.station.supply) > 1e-6) ok = false
  }
  A(ok, '每 tick：压力/需求/供气 图表末点 = 页面状态（同一时刻同一套数据）')
  const h = engine.history.slice(-180)
  A(h.every(p => [p.demand, p.header, p.tank, p.power, p.supply].every(Number.isFinite)), '曲线数据无 NaN/Infinity')
  A(h.every(p => p.header > 4 && p.header < 11 && p.tank > 5 && p.tank <= 10.6), `压力/罐压在物理量程（${Math.min(...h.map(p => p.header)).toFixed(2)}~${Math.max(...h.map(p => p.header)).toFixed(2)} bar）`)
  A(h.every(p => p.demand >= 120 && p.demand <= 2600), '需求在合理区间')
  let maxJump = 0
  for (let i = 1; i < h.length; i++) maxJump = Math.max(maxJump, Math.abs(h[i].demand - h[i - 1].demand))
  A(maxJump < 300, `需求曲线无异常尖峰（最大单步 ${maxJump.toFixed(0)}）`)
  A(h.flatMap(p => Object.values(p.perLoad)).every(v => v >= 0 && v <= 1.0001), '负荷率曲线均在 0~100%')
}

console.log('=== 2. 紧张判定：阈值 + 原因（单一事实来源）===')
{
  const base = { header: 7.6, safeMin: 6.8, gap: 0, capReserve: 60, supplyMargin: 30, lowHealth: [] as string[] }
  A(liveDispatchFlags(base).tense === false, '全部达标 → 不显示“供气紧张”')
  const lowP = liveDispatchFlags({ ...base, header: 6.5 })
  A(lowP.tense && lowP.critical && lowP.reasons[0].includes('低于安全下限'), `压力低于下限 → 紧张(严重) 且原因=“${lowP.reasons[0]}”`)
  const nearP = liveDispatchFlags({ ...base, header: 6.8 + TENSE_THRESHOLDS.headerWarnGap - 0.05 })
  A(nearP.tense && !nearP.critical && nearP.reasons[0].includes('接近安全下限'), '压力接近下限 → 紧张(关注)')
  const gap = liveDispatchFlags({ ...base, gap: 120 })
  A(gap.tense && gap.critical && gap.reasons[0].includes('供气缺口'), `存在缺口 → 紧张 且原因=“${gap.reasons[0]}”`)
  const capR = liveDispatchFlags({ ...base, capReserve: 3.2 })
  A(capR.tense && capR.reasons[0].includes('可扩备用容量仅 3.2%'), `可扩备用不足 → 原因=“${capR.reasons[0]}”`)
  const marg = liveDispatchFlags({ ...base, supplyMargin: 6.8 })
  A(marg.tense && marg.reasons[0].includes('供气裕度仅 6.8%'), `供气裕度不足 → 原因=“${marg.reasons[0]}”`)
  const hp = liveDispatchFlags({ ...base, lowHealth: ['A2'] })
  A(hp.tense && hp.reasons[0].includes('A2 健康度低于 40'), `低健康 → 原因=“${hp.reasons[0]}”`)
}

console.log('=== 3. 实况紧张判定与当前数据一致 ===')
{
  st().adopt('auto'); for (let i = 0; i < 3; i++) st().tick()
  const s = st()
  const rec = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current
  const capAll = engine.configs.reduce((a, c) => { const m = s.machines.find(x => x.id === c.id); if (!m || m.status === 'fault' || m.status === 'maintenance') return a; const cap = m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad; return a + c.ratedFlow * cap }, 0)
  const live = liveDispatchFlags({ header: s.station.header, safeMin: engine.safeMin, gap: s.result.insufficient?.gap ?? 0, capReserve: Math.max(0, (capAll - s.station.demand) / Math.max(1, s.station.demand) * 100), supplyMargin: rec.reserveRatio, lowHealth: [] })
  A(live.critical === (s.station.header < engine.safeMin || !!s.result.insufficient), '实况 critical 判定与 压力/缺口 数据一致')
  if (s.result.insufficient) A(live.tense && live.reasons.some(r => r.includes('缺口')), '存在缺口时紧张判定含缺口原因')
  A(rec.totalFlow >= s.station.demand || !!s.result.insufficient, `AI 方案满足当前需求（供气 ${rec.totalFlow} vs 需求 ${Math.round(s.station.demand)}）`)
  // 手动加压：制造低压，验证判定随数据变化
  engine.tank = 6.0; st().rescheduleNow()
  const s2 = st()
  const low = liveDispatchFlags({ header: s2.station.header, safeMin: engine.safeMin, gap: 0, capReserve: 50, supplyMargin: 30, lowHealth: [] })
  A(s2.station.header < engine.safeMin && low.tense && low.reasons[0].includes('低于安全下限'), `压低罐压后：压力 ${s2.station.header.toFixed(2)} bar，判定紧张且原因一致`)
  engine.tank = 8.2; for (let i = 0; i < 3; i++) st().rescheduleNow()
  A(st().station.header > engine.safeMin + 0.4, `恢复后压力 ${st().station.header.toFixed(2)} bar 回到安全带`)
}

console.log('=== 4. 首页渲染结构（无 NaN、关键展示项齐全）===')
{
  st().adopt('auto'); for (let i = 0; i < 2; i++) st().tick()
  const html = renderToString(<MemoryRouter><Dashboard /></MemoryRouter>)
  A(!/NaN|undefined|\[object/.test(html), '渲染无 NaN/undefined')
  for (const key of ['空压站总状态', '当前空气需求', '当前供气量', '管网压力', '总功率', '当前能耗', '设备健康度', 'AI 推荐运行组合', '未来 1 小时需求预测', '当前节能效果'])
    A(html.includes(key), `总览包含「${key}」`)
  A(html.includes('满足需求'), 'AI 组合含“满足需求”校验')
  A(html.includes('级联基准') && html.includes('kW → AI'), '节能比例可由 级联基准→AI 功率 解释')
  A(html.includes('供气裕度') && html.includes('可扩备用'), '备用容量=(实际能力/当前需求) 与 供气裕度 分列')
  A(html.includes('安全下限') && html.includes('近3h最低'), '压力卡区分“当前”与“历史最低”')
  A(html.includes('设备区域') && html.includes('A1') && html.includes('启停次数'), '设备区含 A1-A4 与启停次数')
}

console.log(`\nDASH-CONSISTENCY: ${pass} passed, ${fail} failed`)
if (fail) process.exit(1)
