import { SimEngine } from '../src/lib/sim'
import { forecastDemand } from '../src/lib/forecast'
import { optimize } from '../src/lib/optimizer'
import { explainSixQuestions, explainPlan } from '../src/lib/explain'
import { answer } from '../src/lib/chat'
import { DEFAULT_CONFIGS, DEFAULT_PRICE, STATION_DEFAULTS } from '../src/lib/params'
import type { OptimizerContext } from '../src/lib/types'

let pass = 0, fail = 0
const A = (cond: boolean, msg: string) => { if (cond) { pass++; console.log(' ✓', msg) } else { fail++; console.error(' ✗ FAIL:', msg) } }

const start = new Date(); start.setHours(13, 0, 0, 0)
const engine = new SimEngine({
  configs: DEFAULT_CONFIGS.map(c => ({ ...c })), price: { ...DEFAULT_PRICE },
  tankVolume: STATION_DEFAULTS.tankVolume, bandLow: STATION_DEFAULTS.bandLow, bandHigh: STATION_DEFAULTS.bandHigh,
  safeMin: STATION_DEFAULTS.safeMinPressure, headerOffset: STATION_DEFAULTS.headerOffset,
}, start.getTime() - 24 * 3600000)
engine.generateHistory(1440)

function mkCtx(over: Partial<OptimizerContext> = {}): OptimizerContext {
  const fc = forecastDemand(engine.history.map(p => p.demand), engine.simTime, ms => engine.demandAt(ms))
  return {
    configs: engine.configs, machines: engine.machines.map(m => ({ ...m })), demand: Math.round(engine.demandNow),
    forecast: fc, priceNow: DEFAULT_PRICE.flat, pricePeriod: 'flat', futurePrices: [],
    headerPressure: engine.header, tankPressure: 8.0, tankVolume: engine.tankVolume, safeMin: engine.safeMin,
    weights: { energy: 0.3, stability: 0.2, cycling: 0.12, health: 0.18, reserve: 0.1, efficiency: 0.1 },
    priceCfg: { ...DEFAULT_PRICE }, startedRecentlyIds: [], simTimeMs: engine.simTime, ...over,
  }
}

console.log('=== S1 调度六问：结构完整且全部动态 ===')
{
  const ctx = mkCtx()
  const res = optimize(ctx)
  const plan = res.plans.find(p => p.key === res.recommended)!
  const six = explainSixQuestions(plan, res.baseline, ctx, res)
  A(six.length === 6, `六问齐全：${six.map(x => x.q).join(' / ')}`)
  A(six.every(x => x.a.length > 20 && !/NaN|undefined|\[object/.test(x.a)), '所有回答非空且无 NaN/undefined')
  const joined = six.map(x => x.a).join(' ')
  const priceOk = joined.includes(ctx.priceNow.toFixed(2)) || joined.includes(String(Math.round(ctx.demand)))
  A(priceOk, '回答引用了当前电价/需求等实时数值')
  A(six[5].a.includes('A') && /健康/.test(six[5].a), '健康风险问作答包含具体机组与健康度')
}

console.log('=== S2 解释随策略(方案)变化，非固定模板 ===')
{
  const ctx = mkCtx()
  const res = optimize(ctx)
  const pA = res.plans.find(p => p.key === 'A')!
  const pB = res.plans.find(p => p.key === 'B')!
  const q1A = explainSixQuestions(pA, res.baseline, ctx, res)[0].a
  const q1B = explainSixQuestions(pB, res.baseline, ctx, res)[0].a
  const idsOf = (p: typeof pA) => p.units.map(u => u.id)
  A(idsOf(pA).every(id => q1A.includes(id)), `方案A解释点名其机组 ${idsOf(pA).join('+')}`)
  A(idsOf(pB).every(id => q1B.includes(id)), `方案B解释点名其机组 ${idsOf(pB).join('+')}`)
  A(q1A !== q1B || idsOf(pA).join() === idsOf(pB).join(), '不同方案解释内容不同（或组合相同则等价）')
  const hA = explainPlan(pA, res.baseline, ctx, res).headline
  const hB = explainPlan(pB, res.baseline, ctx, res).headline
  console.log(`    A: ${hA} | B: ${hB}`)
}

console.log('=== S3 AI 对话：三类必备提问均结构化且引用实时数据 ===')
{
  const ctx = mkCtx()
  const res = optimize(ctx)
  const adopted = res.plans.find(p => p.key === res.recommended) ?? null
  const snap = { ctx, result: res, adoptedPlan: adopted }
  const QS = ['为什么现在启动A3？', '如果需求增加20%怎么办？', '哪台设备最应该优先维护？']
  for (const qq of QS) {
    const a = answer(qq, snap)
    A(a.includes('【结论】') && a.length > 40 && !/NaN|undefined/.test(a), `「${qq}」→ 结构化回答（${a.length} 字）`)
    const ids = [...a.matchAll(/A(\d)/g)].map(m => Number(m[1]))
    A(ids.every(n => n >= 1 && n <= 4), `「${qq}」未编造不存在的设备（出现的机组：${[...new Set(ids)].map(n => 'A' + n).join('/') || '无'}）`)
  }
  const aStart = answer('为什么现在启动A3？', snap)
  const aDemand = answer('如果需求增加20%怎么办？', snap)
  const aMaint = answer('哪台设备最应该优先维护？', snap)
  A(aStart.includes('A3'), '启动原因回答聚焦 A3')
  const upNum = aDemand.match(/(\d{3,4})\s*Nm/)
  A(!!upNum && Number(upNum[1]) >= Math.round(ctx.demand), `需求+20%回答给出上修后的需求 ${upNum?.[1]} ≥ 当前 ${Math.round(ctx.demand)}`)
  A(/A[1-4]/.test(aMaint) && /健康/.test(aMaint), '维护优先级回答给出具体机组与健康度')
}

console.log('=== S4 store 策略切换：方案与解释同步 ===')
{
  const { useStore, engine: eng } = await import('../src/store')
  const st = () => useStore.getState()
  st().adopt('auto')
  for (let i = 0; i < 3; i++) st().tick()
  const recAuto = st().result.plans.find(p => p.key === st().result.recommended) ?? st().result.current
  A(st().result.plans.length === 3, `store 稳态产出三方案（${st().result.plans.map(p => p.key).join('')}）`)
  st().adopt('A')
  let resA = st().result.plans.find(p => p.key === 'A') ?? null
  for (let i = 0; i < 3 && !resA; i++) { st().tick(); resA = st().result.plans.find(p => p.key === 'A') ?? null }
  if (resA) {
    st().chatSend('为什么推荐这个组合？')
    const last = st().chat[st().chat.length - 1].text
    const comboA = resA.units.map(u => u.id)
    A(comboA.some(id => last.includes(id)), `锁定方案A后 AI 解释引用方案A组合（${comboA.join('+')}）`)
  } else {
    A(false, '未能取得方案A（plans 为空）')
  }
  st().adopt('auto')
  for (let i = 0; i < 2; i++) st().tick()
  const recAfter = st().result.plans.find(p => p.key === st().result.recommended) ?? st().result.current
  A(st().adoptedKey === 'auto', `切回综合最优成功（推荐 ${recAfter.key}，组合 ${recAfter.units.map(u => u.id).join('+')}）`)
  void recAuto; void eng
}

console.log(`\nASSISTANT: ${pass} passed, ${fail} failed`)
if (fail) process.exit(1)
