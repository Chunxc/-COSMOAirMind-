import * as React from 'react'
import { renderToString } from 'react-dom/server'
import { MemoryRouter } from 'react-router-dom'
import { useStore, engine } from '../src/store'
import { optimize, baselineSeries } from '../src/lib/optimizer'
import { explainPlan, explainSixQuestions, explainReschedule } from '../src/lib/explain'
import { answer } from '../src/lib/chat'
import Dashboard from '../src/pages/Dashboard'
import Scheduling from '../src/pages/Scheduling'
import Sandbox from '../src/pages/Sandbox'
import Forecast from '../src/pages/Forecast'
import Health from '../src/pages/Health'
import Events from '../src/pages/Events'
import Assistant from '../src/pages/Assistant'
import Report from '../src/pages/Report'
import Settings from '../src/pages/Settings'

let pass = 0, fail = 0
const A = (c: boolean, m: string) => { if (c) { pass++; console.log(' ✓', m) } else { fail++; console.error(' ✗ FAIL:', m) } }
const st = () => useStore.getState()
const PAGES: [string, React.ComponentType][] = [['驾驶舱', Dashboard], ['智能调度', Scheduling], ['调度沙盘', Sandbox], ['负荷预测', Forecast], ['设备健康', Health], ['事件仿真', Events], ['AI助手', Assistant], ['调度报告', Report], ['系统设置', Settings]]

const KNOWN_SSR_WARN = ['useLayoutEffect does nothing on the server', 'getServerSnapshot should be cached', 'The result of getServerSnapshot']

function renderAllCapture(): { blank: number; bad: number; consoleErrs: string[] } {
  const errs: string[] = []
  const oe = console.error, ow = console.warn
  console.error = (...a: unknown[]) => errs.push(a.map(String).join(' '))
  console.warn = (...a: unknown[]) => errs.push(a.map(String).join(' '))
  let blank = 0, bad = 0
  try {
    for (const [name, P] of PAGES) {
      const html = renderToString(<MemoryRouter><P /></MemoryRouter>)
      if (html.length < 700) { blank++; errs.push(`空白页面 ${name}`) }
      if (/NaN|undefined|\[object Object\]/.test(html)) { bad++; errs.push(`含 NaN/undefined: ${name}`) }
    }
  } catch (e) { bad++; errs.push('渲染异常: ' + (e as Error).message) } finally { console.error = oe; console.warn = ow }
  const realErrs = errs.filter(m => !KNOWN_SSR_WARN.some(k => m.includes(k)))
  return { blank, bad, consoleErrs: realErrs }
}

console.log('===== 步骤一：页面运行错误 / 控制台错误检查 =====')
{
  st().resetAll(); st().adopt('auto'); for (let i = 0; i < 5; i++) st().tick()
  const r = renderAllCapture()
  A(r.blank === 0, '9 个页面均非空白')
  A(r.bad === 0, '9 个页面无 NaN/undefined 渲染')
  A(r.consoleErrs.length === 0, r.consoleErrs.length ? `发现控制台错误：${r.consoleErrs.slice(0, 3).join(' | ')}` : '无真实控制台错误（已过滤已知 SSR 提示）')
}

console.log('===== 步骤二：跨状态页面一致性与刷新/切换 =====')
{
  const scenarios: [string, () => void][] = [
    ['正常需求', () => { st().resetAll(); st().adopt('auto'); st().setDemandOverride(800); for (let i = 0; i < 3; i++) st().tick() }],
    ['需求+20%', () => { st().setDemandOverride(null); st().injectDemandShock(20, 20, '验收+20%') }],
    ['需求+40%', () => { st().injectDemandShock(20, 20, '验收再+20%') }],
    ['A2 故障', () => { st().toggleFault('A2') }],
    ['A2 恢复', () => { st().toggleFault('A2') }],
  ]
  let consistent = true, conflicts = 0
  for (const [name, act] of scenarios) {
    const before = st().tickCount
    act()
    const last = engine.history[engine.history.length - 1]; const s = st()
    if (Math.abs(last.header - s.station.header) > 1e-9 || Math.abs(last.demand - s.station.demand) > 1e-9 || Math.abs(last.supply - s.station.supply) > 1e-9) consistent = false
    // 渲染（等价切换页面）不应改变状态
    const tc = st().tickCount
    renderAllCapture()
    if (st().tickCount !== tc) conflicts++
    const a2 = s.machines.find(m => m.id === 'A2')!
    const plans = s.result.plans
    if (a2.status === 'fault' && plans.length && plans.some(p => p.units.some(u => u.id === 'A2'))) consistent = false
    console.log(`   · ${name}: 压力 ${s.station.header.toFixed(2)} 需求 ${Math.round(s.station.demand)} 供气 ${Math.round(s.station.supply)} A2=${a2.status} 方案数 ${plans.length}`)
    void before
  }
  A(consistent, '跨状态：图/卡/方案同源且故障机组不参与调度')
  A(conflicts === 0, '刷新/切换页面不会改变仿真状态（无状态冲突）')
}

console.log('===== 步骤三：演示重启不产生冲突 =====')
{
  const realST = globalThis.setTimeout
  globalThis.setTimeout = ((fn: () => void) => { fn(); return 0 }) as unknown as typeof setTimeout
  try { st().startDemo() } finally { globalThis.setTimeout = realST }
  A(!st().demo.running && st().demo.summary !== null, '一键演示可跑完并产出结论')
  st().startDemo(); st().stopDemo()
  A(!st().demo.running && st().demandShock.pct === 0, '重复启动/结束演示后状态归位（无残留冲击）')
  const r = renderAllCapture()
  A(r.consoleErrs.length === 0 && r.bad === 0, '演示后所有页面仍正常渲染')
}

console.log('===== 步骤四：十项重点场景验收 =====')
{
  st().resetAll(); st().adopt('auto')
  // 1 正常需求
  st().setDemandOverride(800); for (let i = 0; i < 3; i++) st().tick()
  let s = st(); let rec = s.result.plans.find(p => p.key === s.result.recommended)!
  A(rec.units.length >= 1 && rec.totalFlow >= 800 * 0.97, `1) 正常需求：推荐 ${rec.units.map(u => u.id).join('+')}（${rec.totalFlow} Nm³/h）`)
  // 2 需求+20/40
  st().setDemandOverride(960); st().tick(); s = st()
  A(s.station.demand > 900 && (s.result.plans.length ? s.result.plans.find(p => p.key === s.result.recommended)!.totalFlow >= s.station.demand * 0.95 : true), `2) 需求+20% 重调度（${Math.round(s.station.demand)}）`)
  st().setDemandOverride(1120); st().tick(); s = st()
  A(s.station.demand >= 1100, `   需求+40%（${Math.round(s.station.demand)}）`)
  st().setDemandOverride(null)
  // 3/4 故障
  for (const id of ['A1', 'A2', 'A3', 'A4']) {
    st().resetAll(); st().adopt('auto'); st().setDemandOverride(800); for (let i = 0; i < 2; i++) st().tick()
    st().toggleFault(id)
    const r = st().result; const p = r.plans.find(x => x.key === r.recommended)
    const excl = r.plans.length === 0 || r.plans.every(pp => !pp.units.some(u => u.id === id))
    A(excl && (r.insufficient !== null || !!p), `3) ${id} 故障：更新供气/功率/压力风险并重排（组合 ${p ? p.units.map(u => u.id).join('+') : '缺口 ' + r.insufficient?.gap}）`)
  }
  // 4 能力不足（显式置全部故障，避免 toggle 语义歧义）
  for (const id of ['A1', 'A2', 'A3', 'A4']) st().setMachineMode(id, 'fault')
  const ri = st().result
  A(ri.plans.length === 0 && ri.insufficient !== null && ri.insufficient.gap > 0,
    `4) 全部故障：明确能力不足（缺口 ${ri.insufficient?.gap} Nm³/h），不显示虚假可行方案`)
  A(!!ri.insufficient && ri.insufficient.measures.length >= 2, `   给出恢复建议 ${ri.insufficient?.measures.length} 条`)
  for (const id of ['A1', 'A2', 'A3', 'A4']) st().setMachineMode(id, 'auto')
  // 5 低压告警+建议
  engine.tank = 6.0; st().rescheduleNow()
  const flags = st().buildCtx()
  A(st().station.header < engine.safeMin, `5) 管网压力 ${st().station.header.toFixed(2)} bar 低于安全下限 ${engine.safeMin}`)
  A(flags.safeMin === engine.safeMin, '   告警与恢复建议使用同一安全下限')
  engine.tank = 8.2; for (let i = 0; i < 3; i++) st().rescheduleNow()
  // 6 电价切换
  const ctxV = { ...st().buildCtx(), priceNow: 0.38, pricePeriod: 'valley' as const }
  const rV = optimize(ctxV); const pV = rV.plans.find(p => p.key === rV.recommended)!
  A(Math.abs(pV.costPerHour - pV.totalPower * 0.38) < Math.max(0.5, pV.costPerHour * 0.02), `6) 电价切换后成本按当前电价复算（${pV.totalPower}kW×0.38=¥${pV.costPerHour}）`)
  // 7 节能复算
  const s7 = st(); const rec7 = s7.result.plans.find(p => p.key === s7.result.recommended) ?? s7.result.current
  const save = (s7.result.baseline.totalPower - rec7.totalPower) / s7.result.baseline.totalPower * 100
  A(Math.abs(save - (100 - rec7.totalPower / s7.result.baseline.totalPower * 100)) < 1e-6, `7) 节能率可复算：基准 ${s7.result.baseline.totalPower}kW → 优化 ${rec7.totalPower}kW（-${save.toFixed(1)}%）`)
  A(Math.abs(rec7.specificPower - rec7.totalPower / rec7.totalFlow) < 0.002, `   单位能耗复算一致（${rec7.specificPower}≈${(rec7.totalPower / rec7.totalFlow).toFixed(3)}）`)
}

console.log('===== 步骤五：AI 助手引用当前状态（不编造）=====')
{
  st().resetAll(); st().adopt('auto'); st().setDemandOverride(820); for (let i = 0; i < 2; i++) st().tick()
  st().toggleFault('A2'); st().tick()
  const s = st()
  const snapCtx = s.buildCtx()
  const adopted = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current
  const aCombo = answer('为什么推荐这个组合？', { ctx: snapCtx, result: s.result, adoptedPlan: adopted })
  const aStart = answer('为什么现在启动A3？', { ctx: snapCtx, result: s.result, adoptedPlan: adopted })
  const six = explainSixQuestions(adopted, s.result.baseline, snapCtx, s.result)
  const all = [aCombo, aStart, six.map(q => q.a).join(' ')].join(' ')
  const ids = [...all.matchAll(/A(\d)/g)].map(m => Number(m[1]))
  A(ids.every(n => n >= 1 && n <= 4), 'AI 未编造不存在机组')
  A(!/A2[^，。；]*运行|推荐[^，。；]*A2/.test(aCombo) || s.machines.find(m => m.id === 'A2')!.status !== 'fault', 'A2 故障时 AI 不将其描述为运行/推荐')
  A(all.includes(String(Math.round(snapCtx.demand))) || all.includes(snapCtx.priceNow.toFixed(2)), 'AI 解释引用当前需求/电价等实时数据')
  const ex = explainPlan(adopted, s.result.baseline, snapCtx, s.result)
  A(ex.reasons.length >= 1 && !/NaN/.test(ex.reasons.join()), 'AI 调度原因基于实际数据生成')
  // 事件重调度解释
  const snap = s.lastEventSnapshot!
  const rEx = explainReschedule(snap, adopted, snapCtx, s.result)
  A(rEx.reasons.some(r => r.includes('A2')) && rEx.changes.length >= 6, 'A2 故障重调度解释含原因与前后对比')
}

console.log('===== 步骤六：报告与驾驶舱数据一致 =====')
{
  const s = st()
  const last = engine.history[engine.history.length - 1]
  A(Math.abs(last.demand - s.station.demand) < 1e-9 && Math.abs(last.header - s.station.header) < 1e-9, '报告/驾驶舱同刻压力与需求一致')
  const blRecompute = baselineSeries([s.station.demand], engine.configs, engine.machines, () => s.priceNow, engine.simTime)
  A(blRecompute.power.length === 1 && blRecompute.power[0] > 0, '节能基准可由同一数据独立复算')
}

console.log(`\nFINAL-ACCEPTANCE: ${pass} passed, ${fail} failed`)
if (fail) process.exit(1)
