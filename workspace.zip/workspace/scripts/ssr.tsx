import * as React from "react"
import { renderToString } from 'react-dom/server'
import { MemoryRouter } from 'react-router-dom'
import { useStore, engine } from '../src/store'
import Dashboard from '../src/pages/Dashboard'
import Scheduling from '../src/pages/Scheduling'
import Health from '../src/pages/Health'
import Forecast from '../src/pages/Forecast'
import Sandbox from '../src/pages/Sandbox'
import Events from '../src/pages/Events'
import Assistant from '../src/pages/Assistant'
import Report from '../src/pages/Report'
import Settings from '../src/pages/Settings'

const st = () => useStore.getState()
const pages: Record<string, React.ComponentType> = { Dashboard, Scheduling, Health, Forecast, Sandbox, Events, Assistant, Report, Settings }
let fail = 0

function renderAll(label: string) {
  for (const [name, P] of Object.entries(pages)) {
    try {
      const html = renderToString(<MemoryRouter><P /></MemoryRouter>)
      if (html.includes('NaN') && !['Dashboard', 'Scheduling', 'Health', 'Forecast'].includes(name)) { /* allow charts internals? no, flag */ }
      if (!html.length) throw new Error('empty render')
      console.log(`  [${label}] ${name}: ${(html.length / 1024).toFixed(1)}KB ok`)
    } catch (e) {
      fail++
      console.error(`  [${label}] ${name} CRASH:`, (e as Error).message)
    }
  }
}

console.log('=== SSR render test (cold) ===')
renderAll('cold')

console.log('=== SSR after 60 ticks + events ===')
st().adopt('auto')
for (let i = 0; i < 40; i++) st().tick()
st().injectDemandShock(40, 30, 'ssr test +40')
for (let i = 0; i < 20; i++) st().tick()
st().toggleFault('A2')
st().triggerTankDrop()
st().chatSend('如果A2故障怎么办')
renderAll('hot')

console.log(fail ? `SSR FAILURES: ${fail}` : 'SSR ALL OK')
process.exit(fail ? 1 : 0)
