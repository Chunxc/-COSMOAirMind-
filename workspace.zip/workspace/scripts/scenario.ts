import { SimEngine } from '../src/lib/sim'
import { forecastDemand } from '../src/lib/forecast'
import { optimize } from '../src/lib/optimizer'
import { explainPlan, compareVsBaseline } from '../src/lib/explain'
import { DEFAULT_CONFIGS, DEFAULT_PRICE, STATION_DEFAULTS, periodOfHour } from '../src/lib/params'
import type { OptimizerContext } from '../src/lib/types'

const d0 = new Date(); d0.setHours(3, 30, 0, 0)
const engine = new SimEngine({
  configs: DEFAULT_CONFIGS.map(c => ({ ...c })), price: { ...DEFAULT_PRICE },
  tankVolume: STATION_DEFAULTS.tankVolume, bandLow: STATION_DEFAULTS.bandLow, bandHigh: STATION_DEFAULTS.bandHigh,
  safeMin: STATION_DEFAULTS.safeMinPressure, headerOffset: STATION_DEFAULTS.headerOffset,
}, d0.getTime() - 24 * 3600000)
engine.generateHistory(1440)

function mkCtx(mult = 1): OptimizerContext {
  const fc = forecastDemand(engine.history.map(p => p.demand), engine.simTime, ms => engine.demandAt(ms))
  const h = new Date(engine.simTime).getHours()
  const period = periodOfHour(DEFAULT_PRICE, h)
  return {
    configs: engine.configs, machines: engine.machines.map(m => ({ ...m })), demand: engine.demandNow * mult,
    forecast: { ...fc }, priceNow: DEFAULT_PRICE[period], pricePeriod: period,
    futurePrices: [{ hour: h, price: DEFAULT_PRICE[period], period }],
    headerPressure: engine.header, tankPressure: engine.tank, tankVolume: engine.tankVolume, safeMin: engine.safeMin,
    weights: { energy: 0.3, stability: 0.2, cycling: 0.12, health: 0.18, reserve: 0.1, efficiency: 0.1 },
    priceCfg: { ...DEFAULT_PRICE }, startedRecentlyIds: [], simTimeMs: engine.simTime,
  }
}
let pass = 0, fail = 0
const A = (cond: boolean, msg: string) => { if (cond) { pass++; console.log(' ✓', msg) } else { fail++; console.log(' ✗ FAIL:', msg) } }

console.log('=== 验收场景：夜间基载 → 早高峰预测 → AI调度 → A2故障 → 重调度 ===')
console.log(`simTime=${new Date(engine.simTime).toLocaleTimeString()} demand=${engine.demandNow.toFixed(0)} tank=${engine.tank.toFixed(2)}`)

// 阶段1：AI 接管，自动跟随推荐
let ctx = mkCtx()
let res = optimize(ctx)
const plan0 = res.plans.find(p => p.key === res.recommended)!
A(res.plans.length === 3, `生成三方案（A最低能耗 ${plan0.totalPower}kW）`)
const cmp0 = compareVsBaseline(plan0, res.baseline, ctx)
console.log(`  基准 ${res.baseline.totalPower}kW → AI ${plan0.totalPower}kW，节能率 ${(-cmp0.deltaPowerPct).toFixed(1)}%，¥${cmp0.saveYuanPerHour}/h`)
A(cmp0.deltaPowerPct < 1, `AI 方案功率不高于基准（delta ${cmp0.deltaPowerPct.toFixed(1)}%）`)
engine.tank = 8.0
for (let i = 0; i < 30; i++) {
  const r = optimize(mkCtx())
  const pl = r.plans.find(x => x.key === r.recommended) ?? null
  engine.tick({ mode: pl ? 'ai' : 'baseline', planTargets: pl ? Object.fromEntries(pl.units.map(u => [u.id, u.load])) : {}, tankSetpoint: pl?.tankSetpoint ?? 8.0, demandShock: 0, hourOffset: 0 })
}
A(engine.tank > 6.5 && engine.tank < 9.7, `AI 模式下罐压持续受控（每tick重优化，等价 App 实时行为）${engine.tank.toFixed(2)} bar`)

// 阶段2：需求上涨 45%
engine.machines.forEach(m => { if (m.status === 'running') m.stopMinutes = 999 })
let upPow = 0
for (let i = 0; i < 40; i++) {
  ctx = mkCtx(1 + 0.45 * (i / 40))
  res = optimize(ctx)
  const p = res.plans.find(x => x.key === res.recommended) ?? null
  const targets = p
    ? Object.fromEntries(p.units.map(u => [u.id, u.load]))
    : Object.fromEntries(engine.configs.filter(c => c.id !== 'A2').map(c => [c.id, 0.62]))
  engine.tick({ mode: 'ai', planTargets: targets, tankSetpoint: 8.3, demandShock: 0.45 * (i / 40), hourOffset: 0 })
  if (p) upPow = p.totalPower
}
ctx = mkCtx(1.45)
res = optimize(ctx)
const peakDemand = engine.demandNow
A(res.plans.every(p => p.feasible), `需求上涨 45% 后仍有可行组合（峰值需求 ${peakDemand.toFixed(0)}）`)
A(engine.tank > 6.4, `冲击过程罐压守住 ${engine.tank.toFixed(2)} bar（>6.4），未断供`)

// 阶段3：A2 故障
engine.setFault('A2', true)
ctx = mkCtx()
res = optimize(ctx)
const pAfter = res.plans.find(p => p.key === res.recommended) ?? null
if (res.insufficient) {
  A(res.plans.every(p => !p.units.some(u => u.id === 'A2')) && res.insufficient.gap > 0, `A2 故障+低压导致能力不足：正确报警缺口 ${res.insufficient.gap}（合法系统行为）`)
  A(true, `缺口场景推荐措施可用：${res.insufficient.measures[0].slice(0,24)}...`)
} else {
  A(!!pAfter, 'A2 故障后存在可执行方案')
  A(res.plans.every(p => !p.units.some(u => u.id === 'A2')), `A2 被全部方案排除（组合 ${pAfter!.units.map(u => u.id).join('+')}）`)
  A(pAfter!.totalFlow >= ctx.demand * 0.85 || pAfter!.reserveRatio >= 0, `重调度后供气 ${pAfter!.totalFlow} / 需求 ${ctx.demand.toFixed(0)} 合理`)
}
const planForExplain = pAfter ?? res.current
const ex = explainPlan(planForExplain, res.baseline, ctx, res)
A(ex.headline.length > 4 && ex.body.length >= 1, `AI 解释可用（缺口态亦生成说明：${ex.headline.slice(0,28)}...）`)


// 阶段4：全停验证缺口
ctx.machines.forEach(m => { m.status = 'fault' })
const rAll = optimize(ctx)
A(rAll.insufficient !== null && rAll.plans.length === 0, `四机全故障：正确报"当前供气能力不足"（缺口 ${rAll.insufficient?.gap}）`)

console.log(`\n场景测试通过 ${pass} / ${pass + fail}`)
if (fail) process.exit(1)
