import { SimEngine } from '../src/lib/sim'
import { forecastDemand } from '../src/lib/forecast'
import { optimize } from '../src/lib/optimizer'
import { answer } from '../src/lib/chat'
import { DEFAULT_CONFIGS, DEFAULT_PRICE, STATION_DEFAULTS, periodOfHour } from '../src/lib/params'

function assert(cond: boolean, msg: string) {
  if (!cond) { console.error('FAIL:', msg); process.exitCode = 1 } else console.log('PASS:', msg)
}

const d0 = new Date(); d0.setHours(8, 0, 0, 0)
const engine = new SimEngine({
  configs: DEFAULT_CONFIGS.map(c => ({ ...c })),
  price: { ...DEFAULT_PRICE },
  tankVolume: STATION_DEFAULTS.tankVolume,
  bandLow: STATION_DEFAULTS.bandLow,
  bandHigh: STATION_DEFAULTS.bandHigh,
  safeMin: STATION_DEFAULTS.safeMinPressure,
  headerOffset: STATION_DEFAULTS.headerOffset,
}, d0.getTime() - 24 * 3600000)
engine.generateHistory(1440)

const demands = engine.history.map(p => p.demand)
console.log('demand range:', Math.min(...demands).toFixed(0), '-', Math.max(...demands).toFixed(0))
assert(demands.length === 1440, 'history has 1440 points')
assert(Math.max(...demands) < 3000 && Math.min(...demands) > 110 && Math.max(...demands) < 2600, 'demand in sane industrial range')
assert(engine.tank > 5 && engine.tank < 11, `tank pressure plausible ${engine.tank.toFixed(2)}`)
assert(engine.machines.every(m => m.status === 'running' || m.status === 'standby'), 'history machines resolved')
const powers = engine.history.slice(-600).map(p => p.power)
console.log('last10h baseline avg power:', (powers.reduce((a, b) => a + b, 0) / powers.length).toFixed(1), 'kW; avg demand:', (engine.history.slice(-600).reduce((a, p) => a + p.demand, 0) / 600).toFixed(0), 'Nm3/h')

const fc = forecastDemand(demands, engine.simTime, ms => engine.demandAt(ms))
assert(Math.abs(fc.f30 - engine.demandNow) / engine.demandNow < 0.5, `forecast f30 near current demand (${fc.f30.toFixed(0)} vs ${engine.demandNow.toFixed(0)})`)
assert(fc.values.every(v => v > 0 && isFinite(v)) && fc.upper.every((u, i) => u >= fc.lower[i]), 'forecast series valid & band ordered')

function buildCtx(mult = 1, demandOverride?: number) {
  const h = new Date(engine.simTime).getHours() + 1
  const period = periodOfHour(DEFAULT_PRICE, h)
  return {
    configs: engine.configs,
    machines: engine.machines.map(m => ({ ...m })),
    demand: (demandOverride ?? engine.demandNow) * mult,
    forecast: { ...fc, f30: fc.f30 * mult, f60: fc.f60 * mult },
    priceNow: DEFAULT_PRICE[period] as number,
    pricePeriod: period,
    futurePrices: [{ hour: h, price: DEFAULT_PRICE[period] as number, period }],
    headerPressure: engine.header,
    tankPressure: Math.min(engine.tank, 8.15),
    tankVolume: engine.tankVolume,
    safeMin: engine.safeMin,
    weights: { energy: 0.3, stability: 0.2, cycling: 0.12, health: 0.18, reserve: 0.1, efficiency: 0.1 },
    priceCfg: { ...DEFAULT_PRICE },
    startedRecentlyIds: [],
    simTimeMs: engine.simTime,
  }
}

let res = optimize(buildCtx())
console.log('demand:', engine.demandNow.toFixed(0), 'plans:', res.plans.map(p => `${p.key}[${p.units.map(u => u.id + '@' + Math.round(u.load * 100) + '%').join('+')}] score=${p.totalScore}`).join(' | '))
assert(res.plans.length === 3, 'three plans generated')
assert(res.plans.every(p => p.feasible), 'all plans feasible at normal demand')
for (const p of res.plans) {
  for (const u of p.units) {
    const c = engine.configs.find(x => x.id === u.id)!
    const m = engine.machines.find(x => x.id === u.id)!
    const maxEff = m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad
    assert(u.load >= c.minLoad - 1e-6 && u.load <= maxEff + 1e-6, `${p.key} ${u.id} load ${u.load} within [${c.minLoad}, ${maxEff}]`)
  }
  assert(p.totalFlow >= Math.max(engine.demandNow, fc.f30) * 0.97 - 1, `${p.key} supply ${p.totalFlow} >= ~max(demand,f30)`)
  assert(p.totalScore >= 0 && p.totalScore <= 100 && isFinite(p.totalScore), `${p.key} score in range: ${p.totalScore}`)
  assert(p.scores.energy >= 0 && p.scores.energy <= 100, `${p.key} sub-scores in range`)
}
const specA = res.plans.find(p => p.key === 'A')!
const baseP = res.baseline.totalPower
console.log('baseline power vs planA power:', baseP, specA.totalPower, 'saving%:', ((baseP - specA.totalPower) / baseP * 100).toFixed(1))
assert(specA.totalPower < baseP + 1, 'planA power <= cascade baseline power')

res = optimize(buildCtx(1, 4000))
assert(res.insufficient != null && res.insufficient.gap > 0, `gap detected when demand 4000 (gap ${res.insufficient?.gap})`)
assert(res.result?.recommended !== undefined || true, 'noop')
console.log('gap plan notes:', res.plans.length === 0 ? 'no feasible combos (correct)' : res.plans.map(p => p.key).join(','))

for (const id of ['A1', 'A2', 'A3', 'A4']) {
  const ctx = buildCtx()
  ctx.machines = ctx.machines.map(m => m.id === id ? { ...m, status: 'fault' as const } : m)
  const r = optimize(ctx)
  assert(r.plans.every(p => !p.units.some(u => u.id === id)), `fault ${id} excluded from all plans`)
}

const ctxH = buildCtx()
ctxH.machines = ctxH.machines.map(m => ({ ...m, health: 20 }))
const rh = optimize(ctxH)
assert(rh.plans.every(p => p.units.every(u => u.load <= 0.71)), 'severe-risk machines capped at 70% load')

const ctx2 = buildCtx()
ctx2.machines = ctx2.machines.map(m => m.id === 'A1' ? { ...m, health: 35 } : m)
const rr = optimize(ctx2)
for (const p of rr.plans) {
  const u = p.units.find(x => x.id === 'A1')
  if (u) assert(u.load <= 0.71, `low-health A1 capped in plan ${p.key}: ${u.load}`)
}

engine.tank = 8.2
engine.tick({ mode: 'baseline', planTargets: {}, tankSetpoint: 8, demandShock: 0, hourOffset: 0 })
engine.tick({ mode: 'ai', planTargets: { A3: 0.8, A2: 0.4 }, tankSetpoint: 8, demandShock: 0.2, hourOffset: 0 })
assert(engine.history.length === 1442, 'tick appends history')
assert(engine.machines.every(m => isFinite(m.power) && m.power >= 0), 'tick produces finite powers')
const aiRun = engine.machines.filter(m => m.status === 'running' && m.loaded)
assert(aiRun.length >= 2, `ai mode started machines ${aiRun.map(m => m.id)}`)

engine.machines.forEach(m => { if (m.status === 'running') m.status = 'standby' })
engine.tank = 8.2
const r30 = optimize(buildCtx(1.3))
assert(r30.plans.every(p => p.feasible), 'demand +30% still schedulable with 4 machines')

const snap = {
  ctx: buildCtx(),
  result: optimize(buildCtx()),
  adoptedPlan: (() => { const o = optimize(buildCtx()); return o.plans.find(p => p.key === o.recommended) ?? null })(),
}
const questions = ['为什么不开A4', '为什么推荐这个组合', '未来1小时会不会缺气', '如果A2故障怎么办', '现在能省多少钱', '需求增加30%怎么办', '哪台健康度最低', '现在适合启动A4吗', '压力怎么样', '随便说点啥']
for (const qq of questions) {
  const a = answer(qq, snap)
  assert(a.length > 40 && a.includes('【结论】'), `chat answers "${qq}" with structured block (${a.length} chars)`)
  if (/A4/.test(qq) || a.includes('NaN') || a.includes('undefined')) assert(!a.includes('NaN') && !a.includes('undefined'), `chat "${qq}" no NaN/undefined leakage`)
}

console.log('\nALL SMOKE TESTS DONE, exit code =', process.exitCode ?? 0)
