import { useStore, engine } from '../src/store'

let pass = 0, fail = 0
const A = (cond: boolean, msg: string) => { if (cond) { pass++; console.log(' ✓', msg) } else { fail++; console.error(' ✗ FAIL:', msg) } }
const st = () => useStore.getState()

st().adopt('auto')
for (let i = 0; i < 5; i++) st().tick()
A(st().result.plans.length >= 1 || st().result.insufficient !== null, '初始：调度算法可产出方案或明确缺口')

console.log('=== E1 事件注入即"立即重算"（无需等待定时器）===')
{
  const before = { tick: st().tickCount, demand: st().station.demand }
  st().injectDemandShock(20, 22, '用气需求 +20%')
  A(st().tickCount > before.tick, `事件注入后即时重算（tick ${before.tick} → ${st().tickCount}）`)
  A(st().lastEventSnapshot !== null && st().lastEventSnapshot!.label.includes('需求'), '留存事件前快照')
  A(st().station.demand > before.demand, `需求 +20% 生效（${before.demand.toFixed(0)} → ${st().station.demand.toFixed(0)} Nm³/h）`)
}

console.log('=== E2 故障事件：硬约束排除 + 新组合 + AI 解释 ===')
for (const id of ['A1', 'A2', 'A3', 'A4']) {
  st().toggleFault(id)
  const r = st().result
  const used = r.plans.some(p => p.units.some(u => u.id === id))
  A(!used || r.plans.length === 0, `${id} 故障后调度算法不再使用该设备（方案${r.plans.map(p => p.units.map(u => u.id).join('+')).join(' | ') || '缺口'}）`)
  A(st().machines.find(m => m.id === id)!.status === 'fault', `${id} 系统状态已置为故障`)
  st().toggleFault(id)
  A(st().machines.find(m => m.id === id)!.status !== 'fault', `${id} 恢复`)
}

console.log('=== E3 重点：A2 故障 → 自动识别 → 自动重优化 → 新组合 → AI 解释 ===')
{
  for (let i = 0; i < 3; i++) st().tick()
  const beforeCombo = st().lastEventSnapshot?.combo ?? ''
  st().toggleFault('A2')
  const snap = st().lastEventSnapshot!
  const rec = st().result.plans.find(p => p.key === st().result.recommended) ?? st().result.current
  A(snap !== null && snap.label.includes('A2'), `事件快照捕获「${snap.label}」`)
  A(st().result.plans.every(p => !p.units.some(u => u.id === 'A2')), 'A2 被所有方案硬约束排除')
  A(!rec.units.some(u => u.id === 'A2'), `新组合 ${rec.units.map(u => u.id).join('+') || '保底'} 不含 A2`)
  const { explainReschedule } = await import('../src/lib/explain')
  const ctx = st().buildCtx()
  const expl = explainReschedule(snap, rec, ctx, st().result)
  A(expl.headline.includes('A2'), `AI 解释指向事件：${expl.headline}`)
  A(expl.reasons.some(r => r.includes('A2') && (r.includes('隔离') || r.includes('硬约束'))), '解释说明 A2 因硬约束被隔离')
  A(expl.changes.length >= 6 && expl.changes.some(c => c.metric.includes('压力')), `前后对比含压力/流量/功率/能耗/备用（${expl.changes.length} 项）`)
  const ids = [...expl.reasons.join(' ').matchAll(/A(\d)/g)].map(m => Number(m[1]))
  A(ids.every(n => n >= 1 && n <= 4), 'AI 解释未引用不存在设备')
  console.log(`    事件前组合 ${beforeCombo || snap.combo} → 新组合 ${rec.units.map(u => u.id).join('+') || '保底'}`)
  st().toggleFault('A2')
}

console.log('=== E4 其余事件：需求 / 罐压 / 电价 ===')
{
  const t0 = st().station.demand
  st().injectDemandShock(40, 25, '用气需求 +40%')
  A(st().station.demand > t0 * 1.1, `需求 +40% 大幅上修（${t0.toFixed(0)} → ${st().station.demand.toFixed(0)}）`)
  st().clearEvents()

  engine.tank = 8.2
  st().rescheduleNow()
  const tank0 = st().station.tank
  st().triggerTankDrop()
  A(st().station.tank < tank0 - 0.3, `罐压骤降生效（${tank0.toFixed(2)} → ${st().station.tank.toFixed(2)} bar）`)
  A(st().lastEventSnapshot!.label.includes('储气'), '罐压事件快照留存')

  st().triggerForcePeak()
  A(Math.abs(st().priceNow - st().priceCfg.peak) < 1e-6, `电价进入峰段（${st().priceNow} 元/kWh）`)
  A(st().forecast && st().result, '峰价后仍正常产出预测与方案')
}

console.log('=== E5 供气不足风险：明确告警 + 解决方案 ===')
{
  for (const id of ['A1', 'A2', 'A3', 'A4']) st().toggleFault(id)
  const r = st().result
  A(!!r.insufficient, `全部故障 → 明确报供气不足（缺口 ${r.insufficient?.gap} Nm³/h）`)
  A(!!r.insufficient && r.insufficient.measures.length >= 2, `给出解决方案：${r.insufficient?.measures.slice(0, 2).join('；')}`)
  for (const id of ['A1', 'A2', 'A3', 'A4']) st().toggleFault(id)
  for (let i = 0; i < 4; i++) st().tick()
  A(st().result.insufficient === null || st().result.plans.length >= 1, '恢复后恢复正常调度')
}

console.log(`\nEVENTS: ${pass} passed, ${fail} failed`)
void engine
if (fail) process.exit(1)
