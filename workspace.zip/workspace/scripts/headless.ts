import { useStore } from '../src/store'
import { engine } from '../src/store'

const st = () => useStore.getState()
let fail = 0
const check = (cond: boolean, msg: string) => { if (!cond) { fail++; console.error('RUNTIME FAIL:', msg) } }

console.log('--- headless runtime test: mode baseline first, then AI takeover')
st().adopt('baseline')
for (let i = 0; i < 40; i++) {
  st().tick()
  check(Number.isFinite(st().station.power), 'power finite (baseline)')
  check(st().station.tank > 4.5 && st().station.tank < 11, `tank bounded ${st().station.tank.toFixed(2)}`)
}
console.log('baseline 40 ticks ok. demand', st().station.demand.toFixed(0), 'power', st().station.power.toFixed(0), 'tank', st().station.tank.toFixed(2))

st().adopt('auto')
for (let i = 0; i < 30; i++) st().tick()
console.log('AI 30 ticks: power', st().station.power.toFixed(0), 'tank', st().station.tank.toFixed(2), 'savings kwh', st().savings.kwh.toFixed(2))
check(st().station.tank >= 6.0 && st().station.tank <= 10.0, `tank converges in band under AI (${st().station.tank.toFixed(2)})`)

console.log('--- demand shock +40%')
st().injectDemandShock(40, 30, 'test +40%')
for (let i = 0; i < 45; i++) st().tick()
console.log('shock handled: supply', st().station.supply.toFixed(0), 'demand', st().station.demand.toFixed(0), 'tank', st().station.tank.toFixed(2), 'insufficient', st().result.insufficient?.gap ?? 'none')
check(st().station.tank > 6.0, 'tank survives demand shock')

console.log('--- A2 fault reoptimize')
st().toggleFault('A2')
for (let i = 0; i < 25; i++) st().tick()
check(st().result.plans.every(p => !p.units.some(u => u.id === 'A2')), 'A2 excluded after fault')
console.log('after A2 fault: running', st().machines.map(m => `${m.id}:${m.status}@${Math.round(m.load * 100)}`).join(','))

console.log('--- chat questions all answered without crash')
for (const q of ['为什么不开A4', '如果A2故障怎么办', '需求突增30%', '现在能省多少钱', '压力会不会不够']) {
  st().chatSend(q)
}
const last = st().chat[st().chat.length - 1]
check(last.role === 'ai' && last.text.length > 30 && !last.text.includes('NaN'), 'chat answers valid')

console.log('--- A2 recover')
st().toggleFault('A2')
for (let i = 0; i < 20; i++) st().tick()
const a2s = st().machines.find(m => m.id === 'A2')!.status
check(a2s === 'standby' || a2s === 'running', `A2 故障恢复后被重新评估调度（当前 ${a2s}）`)

console.log('--- tank drop + force peak')
st().triggerTankDrop(); st().triggerForcePeak()
for (let i = 0; i < 30; i++) st().tick()
check(st().station.tank > 5, `tank recovers after drop: ${st().station.tank.toFixed(2)}`)
check(st().priceNow >= st().priceCfg.peak - 0.001, 'peak price active')

console.log('--- report/explain render path data valid')
check(st().result.plans.length >= 1 || st().result.insufficient !== null, 'optimizer outputs')

console.log(fail === 0 ? 'HEADLESS RUNTIME: ALL OK' : `HEADLESS FAILURES: ${fail}`)
process.exit(fail ? 1 : 0)
