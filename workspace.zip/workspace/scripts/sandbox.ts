import { useStore, engine } from '../src/store'

let pass = 0, fail = 0
const A = (cond: boolean, msg: string) => { if (cond) { pass++; console.log(' ✓', msg) } else { fail++; console.error(' ✗ FAIL:', msg) } }
const st = () => useStore.getState()

st().adopt('auto')
for (let i = 0; i < 4; i++) st().tick()

console.log('=== B1 沙盘-调度同源：三方案与利用率可用 ===')
{
  const r = st().result
  A(r.plans.length === 3, `沙盘与核心调度同源，产出三方案 A/B/C（${r.plans.map(p => p.key).join('')}）`)
  const rec = r.plans.find(p => p.key === r.recommended) ?? r.current
  const util = rec.units.length ? rec.units.reduce((a, u) => a + u.load, 0) / rec.units.length * 100 : 0
  A(util >= 0 && util <= 110, `设备利用率可由方案计算（${util.toFixed(0)}%）`)
}

console.log('=== B2 手动需求 → AI 重新调度 ===')
{
  const before = st().station.demand
  const t0 = st().tickCount
  st().setDemandOverride(1400)
  A(st().tickCount > t0, '调整需求后立即触发重算')
  A(Math.abs(st().station.demand - 1400) < 1, `需求量被手动覆盖（${before.toFixed(0)} → ${st().station.demand.toFixed(0)}）`)
  const rec = st().result.plans.find(p => p.key === st().result.recommended) ?? st().result.current
  A(rec.totalFlow >= 1400 * 0.97, `新方案按 1400 需求重算供气（${rec.totalFlow} Nm³/h）`)
  st().setDemandOverride(null)
  st().tick()
  A(st().station.demand !== 1400, `恢复自动后需求回到仿真曲线（${st().station.demand.toFixed(0)}）`)
}

console.log('=== B3 手动电价 → 目标与电费联动 ===')
{
  st().setPriceOverride(1.2)
  const ctx = st().buildCtx()
  A(Math.abs(ctx.priceNow - 1.2) < 1e-6, `电价手动覆盖生效（${ctx.priceNow} 元/kWh）`)
  const rec = st().result.plans.find(p => p.key === st().result.recommended) ?? st().result.current
  A(Math.abs(rec.costPerHour - rec.totalPower * 1.2) < Math.max(1, rec.totalPower * 1.2 * 0.02), `小时电费按新电价重算（¥${rec.costPerHour}）`)
  st().setPriceOverride(null)
}

console.log('=== B4 手动目标压力 → 罐压趋近 ===')
{
  engine.tank = 7.3
  st().setTankSetpointOverride(8.6)
  A(st().tankSetpointOverride === 8.6, '目标压力设定已记录（8.6 bar）')
  for (let i = 0; i < 6; i++) st().tick()
  A(engine.tank > 7.3, `罐压向手动目标趋近（7.30 → ${engine.tank.toFixed(2)} bar）`)
  st().setTankSetpointOverride(null)
}

console.log('=== B5 手动设备状态 → 硬约束与自动重算 ===')
{
  st().setMachineMode('A3', 'fault')
  A(st().machines.find(m => m.id === 'A3')!.status === 'fault', 'A3 被手动置为故障')
  if (st().result.plans.length) A(st().result.plans.every(p => !p.units.some(u => u.id === 'A3')), '重算后所有方案排除 A3')
  st().setMachineMode('A3', 'maintenance')
  A(st().machines.find(m => m.id === 'A3')!.status === 'maintenance', 'A3 转检修')
  st().setMachineMode('A3', 'auto')
  A(st().machines.find(m => m.id === 'A3')!.status === 'standby', 'A3 恢复自动（回到待机纳入调度）')
  const runningBefore = st().machines.filter(m => m.status === 'running').map(m => m.id)
  if (runningBefore.length) {
    const id = runningBefore[0]
    st().setMachineMode(id, 'auto')
    A(st().machines.find(m => m.id === id)!.status === 'running', `对运行中机组点“自动”不会误停机（${id} 仍运行）`)
  } else {
    A(true, '当前无运行机组，跳过运行态恢复校验')
  }
}

console.log('=== B6 AI 重新调度按钮（与定时器解耦）===')
{
  const t0 = st().tickCount
  const prevRunning = st().machines.filter(m => m.status === 'running').map(m => m.id).join('+')
  st().rescheduleNow()
  A(st().tickCount === t0 + 1, '点击“AI重新调度”即产生一次即时重算')
  A(st().result.plans.length >= 1 || st().result.insufficient !== null, '重算后给出方案或缺口结论')
  console.log(`    重算前运行组合 ${prevRunning || '—'} → 重算后 ${st().machines.filter(m => m.status === 'running').map(m => m.id).join('+') || '—'}`)
}

console.log(`\nSANDBOX: ${pass} passed, ${fail} failed`)
if (fail) process.exit(1)
