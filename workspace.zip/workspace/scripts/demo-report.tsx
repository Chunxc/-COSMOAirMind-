import * as React from 'react'
import { renderToString } from 'react-dom/server'
import { MemoryRouter } from 'react-router-dom'
import { useStore, engine } from '../src/store'
import { DEMO_SCRIPT } from '../src/store'
import Report from '../src/pages/Report'

let pass = 0, fail = 0
const A = (cond: boolean, msg: string) => { if (cond) { pass++; console.log(' ✓', msg) } else { fail++; console.error(' ✗ FAIL:', msg) } }
const st = () => useStore.getState()

console.log('=== D1 演示脚本：10 阶段 + 完整动作序列 ===')
{
  A(DEMO_SCRIPT.length === 10, `演示固定 10 个阶段（${DEMO_SCRIPT.length}）`)
  const acts = DEMO_SCRIPT.map(p => p.action ?? '-')
  A(acts[0] === 'baseline' && acts[2] === 'shockRamp' && acts[3] === 'ai' && acts[5] === 'faultA2' && acts[7] === 'reschedule' && acts[9] === 'summary',
    `动作序列符合要求：${acts.join(' → ')}`)
  A(DEMO_SCRIPT.every(p => p.label.includes('阶段') && p.desc.length > 6 && p.dur >= 8), '每阶段有标题/说明/时长')
}

console.log('=== D2 一键演示端到端（同步驱动）===')
{
  const realST = globalThis.setTimeout
  globalThis.setTimeout = ((fn: () => void) => { fn(); return 0 }) as unknown as typeof setTimeout
  try {
    st().startDemo()
  } finally {
    globalThis.setTimeout = realST
  }
  const d = st().demo
  A(!d.running, '演示可完整跑完并自动结束')
  A(d.summary !== null, '产出演示结论汇总')
  if (d.summary) {
    const sm = d.summary
    A([sm.kwh, sm.yuan, sm.pressureImprovePct, sm.switchCuts, sm.avgPowerAi, sm.avgPowerBase].every(v => Number.isFinite(v)),
      `汇总数值有效：节电 ${sm.kwh}kWh / 省费 ¥${sm.yuan} / 压稳 +${sm.pressureImprovePct}% / 减启停 ${sm.switchCuts} 次`)
  }
  A(st().adoptedKey === 'baseline' || st().adoptedKey === 'auto', '结束后调度模式合法')
}

console.log('=== D3 一键生成调度报告：必需章节齐全 ===')
{
  st().adopt('auto')
  for (let i = 0; i < 3; i++) st().tick()
  st().toggleFault('A2')
  for (let i = 0; i < 3; i++) st().tick()
  const html = renderToString(<MemoryRouter><Report /></MemoryRouter>)
  const need = ['AirMind 空压站智能调度运行报告', '一、当前运行状态', '二、需求预测', '三、设备健康度',
    '四、当前调度方案', '五、AI 优化方案', '六、调度前后能耗对比', '七、压力稳定性', '八、备用容量',
    '九、AI 调度原因', '十、故障 / 事件记录', '十一、节能效果总结']
  const miss = need.filter(t => !html.includes(t))
  A(miss.length === 0, miss.length ? `缺少章节：${miss.join(' / ')}` : `报告 12 个必需章节齐全（长度 ${(html.length / 1024).toFixed(1)}KB）`)
  A(html.includes('A2') && html.includes('故障'), '故障/事件记录含 A2 故障事件')
  A(/预测需求 Nm³\/h/.test(html) && html.includes('kW'), '需求预测与能耗字段已渲染')
  A(!/NaN|undefined|\[object/.test(html), '报告无 NaN/undefined 泄漏')
  st().toggleFault('A2')
}

console.log('=== D4 真实定时器下启动/结束演示不报错 ===')
{
  await new Promise<void>(res => {
    try {
      st().startDemo()
      setTimeout(() => {
        A(st().demo.running, '演示已启动（阶段进行中）')
        st().stopDemo()
        A(!st().demo.running, '可随时结束演示且无异常')
        res()
      }, 1200)
    } catch (e) {
      fail++; console.error(' ✗ FAIL:', (e as Error).message); res()
    }
  })
}

console.log('=== D5 30 秒极速演示 ===')
{
  const total = DEMO_SCRIPT.reduce((a, p) => a + p.dur, 0)
  A(Math.abs(total * 0.25 - 30) < 3, `极速模式时长≈30 秒（完整 ${total}s × 0.25 = ${(total * 0.25).toFixed(1)}s）`)
  const realST = globalThis.setTimeout
  globalThis.setTimeout = ((fn: () => void) => { fn(); return 0 }) as unknown as typeof setTimeout
  try { st().startDemo('quick') } finally { globalThis.setTimeout = realST }
  A(!st().demo.running && st().demo.summary !== null, '30 秒演示可完整跑完并产出结论')
  A(st().demo.scale === 1, '演示结束后缩放复位（scale=1）')
}

console.log(`\nDEMO-REPORT: ${pass} passed, ${fail} failed`)
void engine
if (fail) process.exit(1)
