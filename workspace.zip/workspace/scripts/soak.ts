import { useStore } from '../src/store'
const st = () => useStore.getState()
st().adopt('auto')
let zero = 0, ramp = 0, minTank = 99, maxTank = 0, sumP = 0
for (let i = 0; i < 600; i++) {
  if (i === 200) st().injectDemandShock(35, 60, 'soak +35%')
  if (i === 380) st().toggleFault('A2')
  if (i === 460) st().toggleFault('A2')
  st().tick()
  const s = st().station
  if (s.supply < s.demand * 0.5) { if (s.tank > 7.0) ramp++; else zero++ }
  minTank = Math.min(minTank, s.tank); maxTank = Math.max(maxTank, s.tank)
  sumP += s.power
}
console.log(`soak 600 AI: 持续断供=${zero} 启动爬坡瞬态=${ramp} tank[${minTank.toFixed(2)},${maxTank.toFixed(2)}] avgP=${(sumP / 600).toFixed(0)} saved=${st().savings.kwh.toFixed(1)}kWh/¥${st().savings.yuan.toFixed(1)}` + (zero === 0 && minTank > 6.4 && maxTank < 10.0 ? ' PASS' : ' FAIL'))
