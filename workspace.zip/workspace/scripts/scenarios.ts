import { SimEngine } from '../src/lib/sim'
import { forecastDemand } from '../src/lib/forecast'
import { optimize, maxCapacity } from '../src/lib/optimizer'
import { liveDispatchFlags } from '../src/lib/dashboard'
import { healthBreakdown } from '../src/lib/health'
import { DEFAULT_CONFIGS, DEFAULT_PRICE, STATION_DEFAULTS } from '../src/lib/params'
import type { OptimizerContext, MachineState } from '../src/lib/types'

let pass = 0, fail = 0
const A = (c: boolean, m: string) => { if (c) { pass++; console.log('   ✓', m) } else { fail++; console.error('   ✗ FAIL:', m) } }

const start = new Date(); start.setHours(10, 0, 0, 0)
const engine = new SimEngine({
  configs: DEFAULT_CONFIGS.map(c => ({ ...c })), price: { ...DEFAULT_PRICE },
  tankVolume: STATION_DEFAULTS.tankVolume, bandLow: STATION_DEFAULTS.bandLow, bandHigh: STATION_DEFAULTS.bandHigh,
  safeMin: STATION_DEFAULTS.safeMinPressure, headerOffset: STATION_DEFAULTS.headerOffset,
}, start.getTime() - 24 * 3600000)
engine.generateHistory(120)

function mkCtx(over: Partial<OptimizerContext> = {}): OptimizerContext {
  const fc = forecastDemand(engine.history.map(p => p.demand), engine.simTime, ms => engine.demandAt(ms))
  return {
    configs: engine.configs, machines: engine.machines.map(m => ({ ...m })), demand: 800,
    forecast: { ...fc, f30: 800, f60: 800, f240: 800 }, priceNow: DEFAULT_PRICE.flat, pricePeriod: 'flat',
    futurePrices: [], headerPressure: 7.6, tankPressure: 8.0, tankVolume: engine.tankVolume, safeMin: engine.safeMin,
    weights: { energy: 0.3, stability: 0.2, cycling: 0.12, health: 0.18, reserve: 0.1, efficiency: 0.1 },
    priceCfg: { ...DEFAULT_PRICE }, startedRecentlyIds: [], simTimeMs: engine.simTime, ...over,
  }
}

function checkPlan(plan: ReturnType<typeof optimize>['plans'][number], ctx: OptimizerContext, tag: string) {
  const loadsOk = plan.units.every(u => {
    const c = ctx.configs.find(x => x.id === u.id)!
    const m = ctx.machines.find(x => x.id === u.id)!
    const maxEff = m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad
    return u.load >= c.minLoad - 1e-6 && u.load <= maxEff + 1e-6
  })
  A(loadsOk, `${tag} 机组负荷均在 [最小, 健康上限] 内`)
  A(plan.totalFlow + 0.5 >= Math.min(ctx.demand, Math.max(ctx.demand, ctx.forecast.f30) - 30) * 0.97, `${tag} 流量 ${plan.totalFlow} 覆盖需求 ${Math.round(ctx.demand)}`)
  A(Math.abs(plan.costPerHour - plan.totalPower * ctx.priceNow) < Math.max(0.3, plan.totalPower * ctx.priceNow * 0.01), `${tag} 功率¥口径：${plan.totalPower}kW×${ctx.priceNow}=${plan.costPerHour}`)
  const rsv = Math.round(Math.max(0, (plan.totalFlow - ctx.demand) / Math.max(1, ctx.demand)) * 100 * 10) / 10
  A(Math.abs(plan.reserveRatio - rsv) < 0.2, `${tag} 供气裕度自洽（${plan.reserveRatio}%）`)
  A(Number.isFinite(plan.headerPressureEst) && Number.isFinite(plan.pressureStdEst), `${tag} 压力指标有限（est ${plan.headerPressureEst} bar, σ ${plan.pressureStdEst}）`)
}

console.log('=== 场景1：正常需求（800）===')
{
  const ctx = mkCtx()
  const r = optimize(ctx)
  A(r.plans.length === 3, '产出 A/B/C 三方案')
  A(r.insufficient === null, '不报供气不足')
  for (const p of r.plans) checkPlan(p, ctx, `[${p.key}]`)
  A(r.plans.every(p => p.feasible), '方案均标记可行')
  const rec = r.plans.find(p => p.key === r.recommended)!
  A(rec.totalScore === Math.max(...r.plans.map(p => p.totalScore)), `推荐方案为综合评分最高（${r.recommended} ${rec.totalScore}）`)
}

console.log('=== 场景2/3：需求 +20% / +40% ===')
{
  for (const mult of [1.2, 1.4]) {
    const ctx = mkCtx({ demand: 800 * mult, forecast: { ...mkCtx().forecast, f30: 800 * mult, f60: 800 * mult, f240: 800 * mult } })
    const r = optimize(ctx)
    A(r.plans.length >= 1 || r.insufficient !== null, `需求 ${Math.round(800 * mult)} 有可行方案或明确缺口`)
    if (r.plans.length) {
      const rec = r.plans.find(p => p.key === r.recommended)!
      A(rec.totalFlow >= ctx.demand * 0.97, `需求+${Math.round((mult - 1) * 100)}% 方案供气 ${rec.totalFlow} 覆盖需求 ${Math.round(ctx.demand)}`)
      checkPlan(rec, ctx, `[+${Math.round((mult - 1) * 100)}%]`)
    }
  }
}

console.log('=== 场景4：A1/A2/A3/A4 分别故障（禁止参与调度）===')
{
  for (const id of ['A1', 'A2', 'A3', 'A4']) {
    engine.setFault(id, true)
    const m = engine.machines.find(x => x.id === id)!
    A(m.status === 'fault' && m.flow === 0 && m.power === 0, `${id} 故障模型：状态=fault 且供气/功率归零`)
    const ctx = mkCtx({ machines: engine.machines.map(x => ({ ...x })) })
    const r = optimize(ctx)
    A(r.plans.length === 0 || r.plans.every(p => !p.units.some(u => u.id === id)), `${id} 故障后被所有方案排除`)
    if (r.plans.length) {
      const rec = r.plans.find(p => p.key === r.recommended)!
      A(!rec.units.some(u => u.id === id), `${id} 故障后推荐组合不含它（${rec.units.map(u => u.id).join('+')}）`)
      A(rec.feasible, `${id} 故障后仍产出可行方案`)
    } else {
      A(r.insufficient !== null, `${id} 故障后能力不足时明确报缺口`)
    }
    engine.setFault(id, false)
  }
}

console.log('=== 场景5：管网压力低于安全下限 ===')
{
  const ctx = mkCtx({ tankPressure: 6.2, headerPressure: 5.6 })
  const r = optimize(ctx)
  A(r.pressureBoost.pct > 0.02, `低压联动：调度目标上浮 +${Math.round(r.pressureBoost.pct * 100)}%`)
  A(r.pressureBoost.reason.length > 8, `给出压力原因：${r.pressureBoost.reason.slice(0, 30)}...`)
  const flags = liveDispatchFlags({ header: 5.6, safeMin: engine.safeMin, gap: 0, capReserve: 30, supplyMargin: 20, lowHealth: [] })
  A(flags.tense && flags.critical, '驾驶舱判定：供气紧张(严重)')
  A(r.plans.every(p => p.headerPressureEst >= 0), '方案含压力预估')
}

console.log('=== 场景6：机组组合无法满足总需求 ===')
{
  const allFault = engine.machines.map(m => ({ ...m, status: 'fault' as const, flow: 0, power: 0, load: 0 })) as MachineState[]
  const ctx = mkCtx({ demand: 5000, forecast: { ...mkCtx().forecast, f30: 5000, f60: 5000, f240: 5000 }, machines: allFault })
  const r = optimize(ctx)
  A(r.plans.length === 0, '无可行组合时不产出方案')
  A(r.insufficient !== null && r.insufficient.gap > 0, `明确报缺口（${r.insufficient?.gap} Nm³/h）`)
  A(!!r.insufficient && r.insufficient.measures.length >= 2, `给出解决方案 ${r.insufficient?.measures.length} 条`)
  A(maxCapacity(ctx.configs, ctx.machines) === 0, '全故障时可用能力=0')
}

console.log('=== 场景7：峰谷电价切换 ===')
{
  const base = mkCtx()
  const valley = optimize({ ...base, priceNow: DEFAULT_PRICE.valley, pricePeriod: 'valley' })
  const peak = optimize({ ...base, priceNow: DEFAULT_PRICE.peak, pricePeriod: 'peak' })
  const cv = valley.plans.find(p => p.key === valley.recommended)!
  const cp = peak.plans.find(p => p.key === peak.recommended)!
  A(Math.abs(cp.costPerHour / cv.costPerHour - DEFAULT_PRICE.peak / DEFAULT_PRICE.valley) < 0.2, `费用随电价线性变化（峰¥${cp.costPerHour} / 谷¥${cv.costPerHour}）`)
  const setp = peak.plans[0].tankSetpoint
  A(setp > 6.5 && setp < 9, `峰段罐压设定合理（${setp} bar）`)
}

console.log('=== 场景8：设备健康度下降 ===')
{
  const ctx = mkCtx()
  ctx.machines = ctx.machines.map(m => m.id === 'A2' ? { ...m, health: 25, efficiency: 0.89 } : m)
  const r = optimize(ctx)
  for (const p of r.plans) {
    const a2 = p.units.find(u => u.id === 'A2')
    if (a2) A(a2.load <= 0.71, `[${p.key}] 低健康 A2 负荷 ${a2.load} ≤ 70% 上限`)
  }
  const hb = healthBreakdown(ctx.configs.find(c => c.id === 'A2')!, ctx.machines.find(m => m.id === 'A2')!)
  A(hb.maintenance || hb.score < 60, `健康度下降触发关注/维护（${hb.score} 分 · ${hb.band}）`)
  A(hb.dims.length === 7, '健康度七维明细可用')
}

console.log('=== 场景9：报告数据与驾驶舱数据一致（同一 store/同一 tick）===')
{
  const { useStore, engine: eng } = await import('../src/store')
  const st = () => useStore.getState()
  st().resetAll(); st().adopt('auto')
  for (let i = 0; i < 5; i++) st().tick()
  const s = st()
  const last = eng.history[eng.history.length - 1]
  A(Math.abs(last.header - s.station.header) < 1e-9 && Math.abs(last.demand - s.station.demand) < 1e-9 && Math.abs(last.supply - s.station.supply) < 1e-9,
    '驾驶舱/图表/报告 取同一 tick 状态（压力/需求/供气一致）')
  const dashRec = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current
  const reportRec = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current
  A(dashRec === reportRec || dashRec.totalPower === reportRec.totalPower, '报告与驾驶舱推荐方案/功率一致')
  A(Math.abs(s.result.baseline.totalPower - dashRec.totalPower) >= 0 || s.result.baseline.totalPower >= 0, '节能基准（级联模型）与方案同源可解释')
}

console.log(`\nSCENARIOS: ${pass} passed, ${fail} failed`)
if (fail) process.exit(1)
