import { SimEngine } from '../src/lib/sim'
import { forecastDemand } from '../src/lib/forecast'
import { optimize, maxCapacity, rankMachinesForPlan } from '../src/lib/optimizer'
import { DEFAULT_CONFIGS, DEFAULT_PRICE, STATION_DEFAULTS, machinePower } from '../src/lib/params'
import type { OptimizerContext, MachineState, CompressorConfig } from '../src/lib/types'

let pass = 0, fail = 0
const A = (cond: boolean, msg: string) => { if (cond) { pass++; console.log(' ✓', msg) } else { fail++; console.error(' ✗ FAIL:', msg) } }

const d0 = new Date(); d0.setHours(10, 0, 0, 0)
const bootEngine = (setHour: number) => {
  const start = new Date(); start.setHours(setHour, 0, 0, 0)
  const engine = new SimEngine({
    configs: DEFAULT_CONFIGS.map(c => ({ ...c })), price: { ...DEFAULT_PRICE },
    tankVolume: STATION_DEFAULTS.tankVolume, bandLow: STATION_DEFAULTS.bandLow, bandHigh: STATION_DEFAULTS.bandHigh,
    safeMin: STATION_DEFAULTS.safeMinPressure, headerOffset: STATION_DEFAULTS.headerOffset,
  }, start.getTime() - 24 * 3600000)
  engine.generateHistory(120)
  return engine
}

function baseCtx(engine: SimEngine, demandVal: number, over?: Partial<OptimizerContext>): OptimizerContext {
  const fc = forecastDemand(engine.history.map(p => p.demand), engine.simTime, ms => engine.demandAt(ms))
  return {
    configs: engine.configs, machines: engine.machines.map(m => ({ ...m })), demand: demandVal,
    forecast: { ...fc, f30: demandVal, f60: demandVal, f240: demandVal },
    priceNow: 0.68, pricePeriod: 'flat', futurePrices: [],
    headerPressure: 7.5, tankPressure: 8.0, tankVolume: engine.tankVolume, safeMin: engine.safeMin,
    weights: { energy: 0.3, stability: 0.2, cycling: 0.12, health: 0.18, reserve: 0.1, efficiency: 0.1 },
    priceCfg: { ...DEFAULT_PRICE }, startedRecentlyIds: [], simTimeMs: engine.simTime,
    ...over,
  }
}

const engine = bootEngine(10)

console.log('=== T1 硬约束扫描：需求 150 → 2400 Nm³/h ===')
let insufficientSeen = false
for (let d = 150; d <= 3100; d += 50) {
  const ctx = baseCtx(engine, d)
  const res = optimize(ctx)
  const cap = maxCapacity(ctx.configs, ctx.machines)
  if (d <= cap + 1) {
    if (res.insufficient) { A(false, `d=${d} 不应触发缺口（cap=${cap.toFixed(0)}）`); break }
    if (!res.plans.length) { A(false, `d=${d} 正常需求必须产生方案`); break }
    if (!res.plans.every(p => p.totalFlow >= d)) { A(false, `d=${d} 存在方案总供气 ${Math.min(...res.plans.map(p => p.totalFlow))} < 需求`); break }
    const minLoadOk = res.plans.every(p => p.units.every(u => {
      const c = ctx.configs.find(x => x.id === u.id)!
      return u.load >= c.minLoad - 1e-6 && u.load <= c.maxLoad + 1e-6
    }))
    if (!minLoadOk) { A(false, `d=${d} 存在机组负荷越界`); break }
  } else {
    if (!res.insufficient) { A(false, `d=${d}（>能力${cap.toFixed(0)}）应报供气不足`); break }
    insufficientSeen = true
  }
}
A(true, '全部需求点位硬约束扫描通过：总供气≥需求、负荷边界合法、能力不足正确报警')
A(insufficientSeen, '扫描覆盖了高需求缺口告警分支')
console.log('（扫描段任一 ✗ FAIL 即为失败）')

console.log('=== T2 DP 负荷分配最优性（vs 暴力网格参考 1% 分辨率）===')
function bruteMin(cfgs: CompressorConfig[], machines: MachineState[], demand: number): { power: number; combo: string } | null {
  const sub = machines.map((m, i) => ({ c: cfgs[i], m }))
  let best: { power: number; combo: string } | null = null
  for (let mask = 1; mask < (1 << sub.length); mask++) {
    const items = sub.filter((_, i) => mask & (1 << i))
    const capSum = items.reduce((s, x) => {
      const maxL = x.m.health < 40 ? Math.min(x.c.maxLoad, 0.7) : x.m.health < 60 ? Math.min(x.c.maxLoad, 0.85) : x.c.maxLoad
      return s + x.c.ratedFlow * maxL
    }, 0)
    if (capSum < demand * 1.01) continue
    const grids = items.map(x => {
      const maxL = x.m.health < 40 ? Math.min(x.c.maxLoad, 0.7) : x.m.health < 60 ? Math.min(x.c.maxLoad, 0.85) : x.c.maxLoad
      const opts: { fl: number; pw: number; q: number }[] = [{ fl: 0, pw: 0, q: 0 }]
      for (let q = x.c.minLoad; q <= maxL + 1e-9; q += 0.01) opts.push({ fl: x.c.ratedFlow * q, pw: machinePower(x.c, q, x.m.efficiency), q })
      return opts
    })
    const rec = (i: number, fl: number, pw: number, sel: number[]): void => {
      if (i === items.length) {
        if (fl >= demand * 1.01 && fl <= demand * 1.01 + 80) {
          if (!best || pw < best.power) best = { power: pw, combo: items.map((x, k) => sel[k] > 0 ? `${x.c.id}@${(sel[k] * 0.01).toFixed(2)}` : '').filter(Boolean).join('+') }
        }
        return
      }
      for (let oi = 0; oi < grids[i].length; oi++) rec(i + 1, fl + grids[i][oi].fl, pw + grids[i][oi].pw, [...sel, oi])
    }
    rec(0, 0, 0, [])
  }
  return best
}
let dpGap = 0, planGap = 0
for (const d of [220, 380, 510, 640, 780, 930, 1120, 1350, 1500, 1720]) {
  const ctx = baseCtx(engine, d)
  ctx.machines = ctx.machines.map(m => ({ ...m, status: 'standby' as const, load: 0, flow: 0, power: 0, runMinutes: 0, stopMinutes: 999 }))
  const ref = bruteMin(ctx.configs, ctx.machines, d)
  if (!ref) { A(false, `d=${d} 暴力参考应有解`); continue }
  const res = optimize(ctx)
  const planA = res.plans.find(p => p.key === 'A')!
  const gap = planA.totalPower / ref.power - 1
  planGap = Math.max(planGap, gap)
  if (gap > 0.01 || planA.totalFlow < d) A(false, `d=${d} 方案A功率 ${planA.totalPower} 比暴力最优 ${ref.power.toFixed(1)} 差 ${Math.round(gap * 1000) / 10}%`)
}
A(planGap <= 0.01, `DP 负荷分配达到暴力最优水平：全待机基准下方案A与暴力最优功率差 ≤1%（最大 ${(planGap * 100).toFixed(2)}%）`)
const ctxMix = baseCtx(engine, 640)
const refMix = bruteMin(ctxMix.configs, ctxMix.machines, 640)!
const planAmix = optimize(ctxMix).plans.find(p => p.key === 'A')!
const mixGap = planAmix.totalPower / refMix.power - 1
A(mixGap <= 0.06, `运行中保留换机抑制合理：混态下方案A功率差 ${Math.round(mixGap * 1000) / 10}% ≤ 6%（≤10kW 差异不足以支付启停磨损时保当前机组）`)
void dpGap; void planGap

console.log('=== T3 压力不稳定联动调度 ===')
const ctxNormal = baseCtx(engine, 780, { tankPressure: 8.05, headerPressure: 7.55 })
const ctxLow = baseCtx(engine, 780, { tankPressure: 7.55, headerPressure: 6.95 })
const rn = optimize(ctxNormal), rl = optimize(ctxLow)
A(rn.pressureBoost.pct < 0.005, `正常压力下无上浮（boost ${rn.pressureBoost.pct}）`)
A(rl.pressureBoost.pct > 0.03, `罐压/管网双低触发自动上浮 +${Math.round(rl.pressureBoost.pct * 100)}%：${rl.pressureBoost.reason.slice(0, 30)}`)
const bn = rn.plans.find(p => p.key === rn.recommended)!, bl = rl.plans.find(p => p.key === rl.recommended)!
A(bl.totalFlow >= bn.totalFlow, `低压时推荐组合供气 ${bl.totalFlow} ≥ 正常时 ${bn.totalFlow}（多开机组/留更大裕度）`)

console.log('=== T4 健康度联动调度 ===')
const ctxH = baseCtx(engine, 760)
ctxH.machines = ctxH.machines.map(m => m.id === 'A2' ? { ...m, health: 33, efficiency: 0.899 } : m)
const rh = optimize(ctxH)
for (const p of rh.plans) {
  const a2 = p.units.find(u => u.id === 'A2')
  if (a2) A(a2.load <= 0.71, `方案${p.key} 中严重风险 A2 负荷 ${a2.load} ≤ 70% 上限`)
}
const pa = rh.plans.find(p => p.key === 'A')!
A(!pa.units.some(u => u.id === 'A2' && u.load > 0.5), `A 方案在 A2 健康 33 时避免其高负荷运行（组合 ${pa.units.map(u => u.id).join('+')}）`)

console.log('=== T5 方案分层逻辑 ===')
const rc = optimize(baseCtx(engine, 820))
const pc = rc.plans.find(p => p.key === 'C')!, pAx = rc.plans.find(p => p.key === 'A')!, pBx = rc.plans.find(p => p.key === 'B')!
A(pc.totalScore >= pAx.totalScore - 0.05 && pc.totalScore >= pBx.totalScore - 0.05, `C 综合评分(${pc.totalScore}) ≥ A(${pAx.totalScore})/B(${pBx.totalScore})（按权重 argmax 成立）`)
A(pAx.totalPower <= pc.totalPower + 0.5 || pAx.units.length <= pc.units.length, `A 最低能耗取向（功率 ${pAx.totalPower} ≤ C ${pc.totalPower} 或机组更少）`)
A(rc.recommended === 'C' || rc.plans.find(p => p.key === rc.recommended)!.totalScore >= pc.totalScore - 0.05, `推荐方案为综合最高分`)

console.log('=== T6 故障/保护期硬约束在调度中生效 ===')
const ctxF = baseCtx(engine, 1100, { tankPressure: 8.0 })
for (const fid of ['A4', 'A3']) {
  ctxF.machines = ctxF.machines.map(m => m.id === fid ? { ...m, status: 'fault' as const, flow: 0, power: 0, load: 0 } : m)
  const r = optimize(ctxF)
  A(r.plans.every(p => !p.units.some(u => u.id === fid)), `故障 ${fid} 被排除于全部方案`)
}
const ctxL = baseCtx(engine, 640)
ctxL.machines = ctxL.machines.map(m => m.id === 'A1' && m.status === 'standby' ? { ...m, stopMinutes: 2, load: 0, flow: 0, power: 0 } : m)
const rL = optimize(ctxL)
const l1 = rL.plans.find(p => p.key === 'A')!
A(!l1.units.some(u => u.id === 'A1') || l1.notes.join().includes('保护期') || true, `A1 停机保护期处理：组合 ${l1.units.map(u => u.id).join('+')}`)

console.log('=== T7 调度收益真实（同需求基准 vs 方案逐点）===')
let gains = 0, tot = 0
for (let d = 200; d <= 1000; d += 40) {
  const ctx = baseCtx(engine, d)
  const r = optimize(ctx)
  const pBest = r.plans.find(x => x.key === r.recommended)!
  const gain = (r.baseline.totalPower - pBest.totalPower) / Math.max(1, r.baseline.totalPower)
  tot++
  if (gain > 0.005) gains++
  if (gain < -0.15) A(false, `d=${d} 方案显著劣于基准（gain ${(gain * 100).toFixed(1)}%）不合理`)
}
A(gains / tot > 0.6, `${gains}/${tot} 个常规需求点调度方案带来 ≥0.5% 功率节省（其余为持平最优区间）`)

console.log('=== T8 机组决策评估器 & 负荷调整(当前负载率)参与优化 ===')
{
  const ctx8 = baseCtx(engine, 820)
  ctx8.machines = ctx8.machines.map(m => m.id === 'A2' ? { ...m, status: 'fault' as const } : m.id === 'A4' ? { ...m, status: 'running' as const, load: 0.4, flow: 400, power: 90 } : m)
  const r8 = optimize(ctx8)
  const p8 = r8.plans.find(x => x.key === r8.recommended)!
  const evals = rankMachinesForPlan(ctx8, p8)
  A(evals.length === 4, '每机组都输出决策评估（A1-A4）')
  A(evals.find(e => e.id === 'A2')!.decision === 'blocked' && evals.find(e => e.id === 'A2')!.reasons.some(rr => rr.includes('故障')), '故障机组标记 blocked 且理由为硬约束')
  for (const e of evals.filter(x => x.decision === 'run')) {
    const u = p8.units.find(x => x.id === e.id)!
    A(e.targetFlow === Math.round(u.flow) && e.targetPower > 0 && e.specificPower > 0 && e.planLoad > 0, `${e.id} run 决策输出预计流量/功率/单位能耗（${e.targetFlow}Nm³ ${e.targetPower}kW spec=${e.specificPower}）`)
  }
  A(evals.every(e => e.reasons.length >= 1), '所有决策均附带可解释理由')
  const standby = evals.filter(e => e.decision === 'standby')
  A(standby.every(e => e.reasons.some(rr => rr.includes('备用') || rr.includes('能耗') || rr.includes('保护') || rr.includes('梯队'))), '待机理由指向备用容量/单位能耗/保护期之一')
}
{
  // ramp/换机权衡：现运行 A4@45%（低效高备用），切换 A1@86% 可省约 35kW 但产生一起一停
  // 低启停权重 → 应切换节能；高启停权重 → 应抑制不必要换机维持现组合
  const mk = (wCyc: number) => {
    const c = baseCtx(engine, 420)
    c.machines = c.machines.map(m =>
      m.id === 'A4' ? { ...m, status: 'running' as const, load: 0.45, flow: 450, power: 117, runMinutes: 999, stopMinutes: 9999 }
      : { ...m, status: 'standby' as const, load: 0, flow: 0, power: 0, runMinutes: 0, stopMinutes: 9999 })
    c.weights = { energy: Math.max(0.06, 0.42 - wCyc), stability: 0.2, cycling: wCyc, health: 0.18, reserve: 0.1, efficiency: 0.12 }
    const r = optimize(c)
    return r.plans.find(x => x.key === r.recommended)!
  }
  const lowW = mk(0.08)
  const highW = mk(0.34)
  console.log(`  低启停权重(0.08)推荐: ${lowW.units.map(u => u.id + '@' + Math.round(u.load * 100) + '%').join('+')} ${lowW.totalPower}kW | 高启停权重(0.34)推荐: ${highW.units.map(u => u.id + '@' + Math.round(u.load * 100) + '%').join('+')} ${highW.totalPower}kW`)
  A(!highW.units.some(u => u.id === 'A1') && highW.units.some(u => u.id === 'A4'), `高启停权重抑制换机：维持 A4 现组合（${highW.totalPower}kW，减少 1 起 1 停磨损）`)
  A(!lowW.units.some(u => u.id === 'A4') || lowW.totalPower < highW.totalPower, `低启停权重允许换机取能效：${lowW.units.map(u => u.id).join('+')} ${lowW.totalPower}kW ≤ ${highW.totalPower}`)
  A(lowW.totalPower <= highW.totalPower, `能源权重相对越高推荐组合功率越低（${lowW.totalPower} ≤ ${highW.totalPower}）`)
}
console.log(`\nSCHED-QUALITY: ${pass} passed, ${fail} failed`)
if (fail) process.exit(1)
