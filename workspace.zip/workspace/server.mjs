import http from 'node:http'
import { stat } from 'node:fs/promises'
import { createReadStream } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.join(__dirname, 'dist')
const PORT = Number(process.env.PORT || 5173)
const HOST = process.env.HOST || '0.0.0.0'

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.map': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
}

function sendFile(res, filePath, size, req) {
  const ext = path.extname(filePath).toLowerCase()
  const type = MIME[ext] || 'application/octet-stream'
  const headers = {
    'Content-Type': type,
    'Content-Length': size,
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=31536000, immutable',
  }
  if (req.method === 'HEAD') { res.writeHead(200, headers); return res.end() }
  res.writeHead(200, headers)
  createReadStream(filePath).pipe(res)
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', 'http://localhost')
    let pathname = decodeURIComponent(url.pathname)
    if (pathname === '/') pathname = '/index.html'

    const filePath = path.normalize(path.join(ROOT, pathname))
    if (!filePath.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden') }

    let info = null
    try { info = await stat(filePath) } catch { info = null }

    if (info && info.isDirectory()) {
      const idx = path.join(filePath, 'index.html')
      try { const si = await stat(idx); return sendFile(res, idx, si.size, req) } catch { res.writeHead(404); return res.end('Not Found') }
    }
    if (info && info.isFile()) return sendFile(res, filePath, info.size, req)

    if (!path.extname(pathname)) {
      const idx = path.join(ROOT, 'index.html')
      try { const si = await stat(idx); return sendFile(res, idx, si.size, req) } catch { /* fallthrough */ }
    }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
    res.end('Not Found')
  } catch {
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' })
    res.end('Internal Server Error')
  }
})

server.listen(PORT, HOST, () => {
  console.log(`[AirMind] production static server listening on http://${HOST}:${PORT} (root=${ROOT})`)
})
