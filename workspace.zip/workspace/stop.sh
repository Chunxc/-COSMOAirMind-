#!/usr/bin/env bash
#
# AirMind 停止脚本
#   - 使用 ss 提取占用固定端口（默认 5173）的 PID 并 kill
#   - 不使用 fuser / lsof，不使用 2>/dev/null 吞错
#   - 未运行也返回 0
#
set -u

PORT="${PORT:-5173}"
PID_FILE="$(cd "$(dirname "$0")" && pwd)/logs/app.pid"

get_pids() {
  ss -ltnp 2>&1 | awk -v p=":${PORT}" '$0 ~ p {
    if (match($0, /pid=[0-9]+/)) print substr($0, RSTART + 4, RLENGTH - 4)
  }' | sort -u
}

PIDS="$(get_pids)"

if [ -z "$PIDS" ]; then
  echo "AirMind 未运行（端口 ${PORT} 无监听进程）"
  rm -f "$PID_FILE"
  exit 0
fi

echo "停止 AirMind（端口 ${PORT}）进程：$(echo "$PIDS" | tr '\n' ' ')"

for pid in $PIDS; do
  if [ -d "/proc/$pid" ]; then
    kill "$pid" || true
  fi
done

# 等待进程退出
i=1
while [ "$i" -le 20 ]; do
  alive=0
  for pid in $PIDS; do
    if [ -d "/proc/$pid" ]; then alive=1; fi
  done
  if [ "$alive" = "0" ]; then
    echo "已停止"
    rm -f "$PID_FILE"
    exit 0
  fi
  i=$((i + 1))
  sleep 0.5
done

# 仍未退出则强制结束
for pid in $PIDS; do
  if [ -d "/proc/$pid" ]; then
    echo "进程 $pid 未响应 TERM，执行 KILL"
    kill -9 "$pid" || true
  fi
done

echo "已强制停止"
rm -f "$PID_FILE"
exit 0
