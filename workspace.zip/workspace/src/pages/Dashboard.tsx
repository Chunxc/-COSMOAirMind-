import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore, engine } from '../store'
import { Panel, KPI, EChart, CHART_BASE, C, timeFmt, healthColor, statusLabel } from '../components/ui'
import { explainPlan } from '../lib/explain'
import { baselineSeries } from '../lib/optimizer'
import { liveDispatchFlags } from '../lib/dashboard'

function useSlice(n: number) {
  const tick = useStore(s => s.tickCount)
  void tick
  return engine.history.slice(-n)
}

function SectionTitle({ children, extra }: { children: React.ReactNode; extra?: React.ReactNode }) {
  return (
    <div className="section-head">
      <span className="section-title" style={{ margin: 0 }}>{children}</span>
      {extra && <span className="section-extra">{extra}</span>}
    </div>
  )
}

export default function Dashboard() {
  const s = useStore()
  const navigate = useNavigate()
  const recent = useSlice(180)
  const recPlan = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current
  const explain = useMemo(() => explainPlan(recPlan, s.result.baseline, s.buildCtx(), { ...s.result, plans: [recPlan] }), [s.tickCount, recPlan])
  const savePct = s.adoptedKey === 'baseline' ? 0 : Math.max(0, (s.baselineMetrics.powerNow - s.station.power) / Math.max(1, s.baselineMetrics.powerNow) * 100)
  const predSave = s.result.baseline.totalPower > 0 ? Math.max(0, (s.result.baseline.totalPower - recPlan.totalPower) / s.result.baseline.totalPower * 100) : 0

  const avgHealth = s.machines.reduce((a, m) => a + m.health, 0) / Math.max(1, s.machines.length)
  const minHealthMachine = [...s.machines].sort((a, b) => a.health - b.health)[0]
  const cur = s.result.current
  const utilCur = (() => { const r = s.machines.filter(m => m.status === 'running'); return r.length ? r.reduce((a, m) => a + m.load, 0) / r.length * 100 : 0 })()
  const utilRec = recPlan.units.length ? recPlan.units.reduce((a, u) => a + u.load, 0) / recPlan.units.length * 100 : 0
  const capAll = engine.configs.reduce((a, c) => {
    const m = s.machines.find(x => x.id === c.id)
    if (!m || m.status === 'fault' || m.status === 'maintenance') return a
    const cap = m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad
    return a + c.ratedFlow * cap
  }, 0)
  const expandReserve = Math.max(0, (capAll - s.station.demand) / Math.max(1, s.station.demand) * 100)
  const demand = s.station.demand
  const header = s.station.header
  const supplyMargin = recPlan.reserveRatio
  const capReserve = expandReserve
  const histMinHeader = recent.length ? Math.min(...recent.map(p => p.header)) : header
  const gapNm3 = s.result.insufficient?.gap ?? 0
  const lowHealth = s.machines.filter(m => m.status !== 'fault' && m.status !== 'maintenance' && m.health < 40).map(m => m.id)
  const flags = liveDispatchFlags({ header, safeMin: engine.safeMin, gap: gapNm3, capReserve, supplyMargin, lowHealth })
  const liveReasons = flags.reasons
  const tense = flags.tense
  const critical = flags.critical
  const alertActive = (id: string): boolean => {
    if (id.startsWith('header-critical')) return header < engine.safeMin
    if (id.startsWith('header-low')) return header < engine.safeMin + 0.4
    if (id === 'gap') return gapNm3 > 0 || !!s.result.insufficient
    if (id.startsWith('temp-')) { const m = s.machines.find(x => x.id === id.slice(5)); return !!m && m.temp > 100 }
    if (id.startsWith('health-')) { const m = s.machines.find(x => x.id === id.slice(7)); return !!m && m.health < 40 }
    if (id.startsWith('maint-')) return s.maintenance.some(r => id.endsWith(r.id))
    if (id === 'pre-dispatch') return !!s.preDispatch?.escalate
    return false
  }
  const liveAlerts = s.alerts.filter(a => alertActive(a.id))
  const histAlerts = s.alerts.filter(a => !alertActive(a.id))

  const demandOpt = useMemo(() => ({
    ...CHART_BASE,
    tooltip: CHART_BASE.tooltip,
    grid: { ...CHART_BASE.grid, top: 26 },
    legend: { ...CHART_BASE.legend, data: ['用气需求', '实际供气', '未来预测'] },
    xAxis: { type: 'time', ...CHART_BASE.AXIS, axisLabel: { ...CHART_BASE.AXIS.axisLabel, formatter: (v: number) => timeFmt(v) } },
    yAxis: { type: 'value', name: 'Nm³/h', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS },
    series: [
      { name: '用气需求', type: 'line', showSymbol: false, data: recent.map(p => [p.t, p.demand.toFixed(0)]), lineStyle: { color: C.demand, width: 1.6 }, areaStyle: { color: 'rgba(246,183,60,0.07)' } },
      { name: '实际供气', type: 'line', showSymbol: false, data: recent.map(p => [p.t, p.supply.toFixed(0)]), lineStyle: { color: C.supply, width: 1.6 } },
      { name: '未来预测', type: 'line', showSymbol: false, data: s.forecast.horizon.slice(0, 60).map((h, i) => [h, s.forecast.values[i].toFixed(0)]), lineStyle: { color: '#4a9eff', width: 1.6, type: 'dashed' } },
    ],
  }), [s.tickCount])

  const pressureOpt = useMemo(() => ({
    ...CHART_BASE,
    legend: { ...CHART_BASE.legend, data: ['管网压力', '罐压'] },
    xAxis: { type: 'time', ...CHART_BASE.AXIS, axisLabel: { ...CHART_BASE.AXIS.axisLabel, formatter: (v: number) => timeFmt(v) } },
    yAxis: { type: 'value', min: 5.6, max: 10.8, name: 'bar', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS },
    series: [
      { name: '安全下限', type: 'line', data: [], markLine: { silent: true, symbol: 'none', label: { formatter: `安全下限 ${engine.safeMin}`, color: '#f4586a', fontSize: 10 }, lineStyle: { color: '#f4586a', type: 'dashed', width: 1 }, data: [{ yAxis: engine.safeMin }] } },
      { name: '管网压力', type: 'line', showSymbol: false, data: recent.map(p => [p.t, p.header.toFixed(2)]), lineStyle: { color: C.header, width: 1.8 } },
      { name: '罐压', type: 'line', showSymbol: false, data: recent.map(p => [p.t, p.tank.toFixed(2)]), lineStyle: { color: C.tank, width: 1.4 } },
    ],
  }), [s.tickCount])

  const blSeries = baselineSeries(recent.map(p => p.demand), engine.configs, engine.machines, (_i, t) => {
    const h = new Date(t).getHours()
    return h >= 10 && h < 12 || h >= 14 && h < 19 ? engine.price.peak : h >= 7 && h < 10 || h >= 19 && h < 23 ? engine.price.flat : engine.price.valley
  }, recent[0]?.t ?? engine.simTime)
  const powerOpt = useMemo(() => ({
    ...CHART_BASE,
    legend: { ...CHART_BASE.legend, data: ['实际功率', '级联基准功率'] },
    xAxis: { type: 'time', ...CHART_BASE.AXIS, axisLabel: { ...CHART_BASE.AXIS.axisLabel, formatter: (v: number) => timeFmt(v) } },
    yAxis: { type: 'value', name: 'kW', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS },
    series: [
      { name: '实际功率', type: 'line', showSymbol: false, data: recent.map(p => [p.t, p.power.toFixed(0)]), lineStyle: { color: C.power, width: 1.8 }, areaStyle: { color: 'rgba(74,158,255,0.1)' } },
      { name: '级联基准功率', type: 'line', showSymbol: false, data: recent.map((p, i) => [p.t, blSeries.power[i]?.toFixed(0) ?? '-']), lineStyle: { color: C.base, width: 1.2, type: 'dashed' } },
    ],
  }), [s.tickCount])

  const unitOpt = useMemo(() => ({
    ...CHART_BASE,
    legend: { ...CHART_BASE.legend, data: engine.configs.map(c => c.id) },
    xAxis: { type: 'time', ...CHART_BASE.AXIS, axisLabel: { ...CHART_BASE.AXIS.axisLabel, formatter: (v: number) => timeFmt(v) } },
    yAxis: { type: 'value', max: 1.05, name: '负荷率', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS, axisLabel: { ...CHART_BASE.AXIS.axisLabel, formatter: (v: number) => `${Math.round(v * 100)}%` } },
    series: engine.configs.map((c, i) => ({ name: c.id, type: 'line', showSymbol: false, data: recent.map(p => [p.t, p.perLoad[c.id] ?? 0]), lineStyle: { width: 1.5, color: [C.green, C.blue, C.violet, C.cyan][i] } })),
  }), [s.tickCount])

  const statusText = tense ? '供气紧张' : s.adoptedKey === 'baseline' ? '传统压控' : 'AI 协同调度'
  const statusColor = tense ? (critical ? 'var(--red)' : 'var(--amber)') : 'var(--green)'

  return (
    <div className="anim-in" style={{ display: 'grid', gap: 14 }}>
      <SectionTitle extra={<span className="hint">数据源：仿真数字孪生 · 每 tick（1 分钟）实时刷新 · 与核心调度同一套优化器</span>}>空压站总览</SectionTitle>

      {(liveAlerts.length > 0 || histAlerts.length > 0) && (
        <div className="grid" style={{ gap: 6 }}>
          {liveAlerts.map(a => (
            <div key={a.id} className={`alert-line ${a.level}`} style={{ alignItems: 'center' }}>
              <span className={`badge ${a.level === 'critical' ? 'danger' : a.level === 'warning' ? 'warn' : 'info'}`}>当前告警</span>
              <span style={{ flex: 1, fontSize: 12 }}>{a.message}</span>
              <span className="t">{timeFmt(a.t)}</span>
            </div>
          ))}
          {histAlerts.slice(0, 4).map(a => (
            <div key={a.id} className="alert-line" style={{ alignItems: 'center', opacity: 0.72 }}>
              <span className="badge standby">历史告警</span>
              <span style={{ flex: 1, fontSize: 12 }}>{a.message}</span>
              <span className="t">{timeFmt(a.t)} · 已恢复</span>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-auto">
        <KPI label="空压站总状态" value={<span style={{ fontSize: 18, color: statusColor }}>{statusText}</span>}
          accent={tense ? (critical ? 'danger' : 'warn') : 'ok'}
          delta={tense ? liveReasons[0] : `运行 ${s.machines.filter(m => m.status === 'running').length}/4 台 · 当前异常 0 · 历史告警 ${histAlerts.length} 条`}
          deltaCls={tense ? (critical ? 'down' : 'flatx') : 'flatx'} />
        <KPI label="当前空气需求" value={Math.round(s.station.demand)} unit="Nm³/h"
          delta={`趋势 ${s.forecast.trend === 'up' ? '↑' : s.forecast.trend === 'down' ? '↓' : '→'} ${Math.abs(s.forecast.trendPct).toFixed(0)}%`}
          deltaCls={s.forecast.trend === 'up' ? 'up' : s.forecast.trend === 'down' ? 'down' : 'flatx'} />
        <KPI label="当前供气量" value={Math.round(s.station.supply)} unit="Nm³/h"
          delta={`供气裕度 ${supplyMargin}% · 可扩备用 ${capReserve.toFixed(0)}%`} deltaCls="flatx" />
        <KPI label="管网压力" value={s.station.header.toFixed(2)} unit="bar"
          accent={s.station.header < engine.safeMin ? 'danger' : s.station.header < engine.safeMin + 0.4 ? 'warn' : 'ok'}
          delta={`罐压 ${s.station.tank.toFixed(2)} bar · 安全下限 ${engine.safeMin} · 近3h最低 ${histMinHeader.toFixed(2)}(历史)`} />
        <KPI label="总功率" value={Math.round(s.station.power)} unit="kW"
          delta={`级联基准 ${Math.round(s.baselineMetrics.powerNow)} kW`} deltaCls="flatx" />
        <KPI label="当前能耗" value={s.station.supply > 1 ? (s.station.power / s.station.supply).toFixed(3) : '-'} unit="kW/Nm³/h"
          delta={`级联基准 ${s.result.baseline.specificPower.toFixed(3)}（同口径同电价）`} deltaCls="flatx" />
        <KPI label="设备健康度" value={avgHealth.toFixed(0)} unit="分均"
          delta={`最低 ${minHealthMachine.id} ${Math.round(minHealthMachine.health)} 分 · 维护提醒 ${s.maintenance.length}`}
          deltaCls={s.maintenance.length ? 'down' : 'flatx'} />
        <KPI label="AI 推荐运行组合" value={<span style={{ fontSize: 18, color: 'var(--cyan)' }}>{recPlan.units.map(u => u.id).join('+') || '保底'}</span>}
          delta={`评分 ${recPlan.totalScore} · 满足需求 ${recPlan.totalFlow >= demand ? '✓' : '✗'} · 供气 ${recPlan.totalFlow} Nm³/h`} deltaCls="flatx" />
        <KPI label="未来 1 小时需求预测" value={Math.round(s.forecast.f60)} unit="Nm³/h"
          delta={`峰值 ${Math.round(s.forecast.peak)} · 置信度 ${Math.round(s.forecast.confidence * 100)}%`}
          deltaCls={s.forecast.trend === 'up' ? 'up' : 'flatx'} />
        <KPI label="当前节能效果" value={(s.adoptedKey === 'baseline' ? predSave : savePct).toFixed(1)} unit="%"
          accent={s.adoptedKey !== 'baseline' && savePct > 4 ? 'ok' : undefined}
          delta={s.adoptedKey === 'baseline' ? `级联基准 ${s.result.baseline.totalPower}kW → AI ${recPlan.totalPower}kW（-${predSave.toFixed(1)}%）` : `累计节电 ${Math.max(0, s.savings.kwh).toFixed(1)} kWh · ¥${s.savings.yuan.toFixed(1)}`}
          deltaCls={s.adoptedKey === 'baseline' ? 'flatx' : 'up'} />
      </div>

      <div className="grid dash-main">
        <div className="grid grid-2">
          <Panel title="实时需求 / 供气 / 短期预测" sub="近 3 小时 → 未来 1 小时" pad={false}>
            <EChart option={demandOpt} height={210} style={{ padding: '4px 8px 8px' }} />
          </Panel>
          <Panel title="管网 / 罐压力曲线" sub="近 3 小时" pad={false}>
            <EChart option={pressureOpt} height={210} style={{ padding: '4px 8px 8px' }} />
          </Panel>
          <Panel title="负荷率协同曲线" sub="四机组" pad={false}>
            <EChart option={unitOpt} height={200} style={{ padding: '4px 8px 8px' }} />
          </Panel>
          <Panel title="功率曲线：实际 vs 级联基准" pad={false}>
            <EChart option={powerOpt} height={200} style={{ padding: '4px 8px 8px' }} />
          </Panel>
        </div>

        <div className="grid" style={{ gap: 12, alignContent: 'start' }}>
          {(s.preDispatch?.escalate || s.maintenance.length > 0) && (
            <div className="grid" style={{ gap: 8 }}>
              {s.preDispatch?.escalate && (
                <div className="alert-line warning" style={{ alignItems: 'center' }}>
                  <span className="badge warn">预测提前提示</span>
                  <span style={{ flex: 1, fontSize: 11.5 }}>{s.preDispatch.reason}</span>
                  <button className="btn ghost" style={{ padding: '3px 8px', fontSize: 11 }} onClick={() => navigate('/forecast')}>看预测</button>
                </div>
              )}
              {s.maintenance.length > 0 && (
                <div className="alert-line warning" style={{ alignItems: 'center' }}>
                  <span className="badge danger">维护提醒</span>
                  <span style={{ flex: 1, fontSize: 11.5 }}>{s.maintenance[0].message}{s.maintenance.length > 1 ? ` 等 ${s.maintenance.length} 项` : ''}</span>
                  <button className="btn ghost" style={{ padding: '3px 8px', fontSize: 11 }} onClick={() => navigate('/health')}>看健康</button>
                </div>
              )}
            </div>
          )}
          <Panel title="AI 当前调度建议" right={<button className="btn" onClick={() => navigate('/scheduling')}>调度详情 →</button>} style={{ borderColor: 'rgba(34,211,238,0.4)' }}>
            <div style={{ textAlign: 'center', padding: '2px 0 6px' }}>
              <div className="hint">{s.result.plans.length ? '推荐机组组合' : '无可执行组合（供气不足）'}</div>
              <div className="num" style={{ fontSize: 26, fontWeight: 750, color: 'var(--cyan)', margin: '6px 0' }}>
                {recPlan.units.length ? recPlan.units.map(u => u.id).join(' + ') : '保供降级'}
              </div>
              <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
                {recPlan.units.map(u => <span key={u.id} className="badge info">{u.id} @ {Math.round(u.load * 100)}%</span>)}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, textAlign: 'left' }}>
                <div className="panel kpi" style={{ padding: '8px 10px' }}><div className="label">预计节能</div><div className="value" style={{ fontSize: 17, color: 'var(--green)' }}>{predSave.toFixed(1)}%</div></div>
                <div className="panel kpi" style={{ padding: '8px 10px' }}><div className="label">预计节省</div><div className="value" style={{ fontSize: 17, color: 'var(--amber)' }}>¥{Math.max(0, s.result.baseline.costPerHour - recPlan.costPerHour).toFixed(0)}<small>/h</small></div></div>
                <div className="panel kpi" style={{ padding: '8px 10px' }}><div className="label">风险等级</div><div className="value" style={{ fontSize: 17, color: recPlan.risk > 55 ? 'var(--red)' : recPlan.risk > 32 ? 'var(--amber)' : 'var(--green)' }}>{recPlan.risk > 55 ? '高' : recPlan.risk > 32 ? '中' : '低'}</div></div>
                <div className="panel kpi" style={{ padding: '8px 10px' }}><div className="label">供气裕度 / 可扩备用</div><div className="value" style={{ fontSize: 15 }}>{recPlan.reserveRatio}% <small>/ {capReserve.toFixed(0)}%</small></div></div>
              </div>
              <div className="ai-reco">
                <b style={{ color: 'var(--cyan)' }}>{explain.headline}</b>
                <div style={{ marginTop: 4, color: 'var(--dim)' }}>节能来源：级联基准 {s.result.baseline.totalPower} kW → AI 方案 {recPlan.totalPower} kW（-{predSave.toFixed(1)}%），单位能耗 {s.result.baseline.specificPower} → {recPlan.specificPower} kW/(Nm³/h)。</div>
                <div style={{ marginTop: 3, color: 'var(--dim)' }}>{explain.body[1]}</div>
              </div>
              <button className="btn primary lg" style={{ width: '100%', marginTop: 10 }} disabled={s.result.plans.length === 0} onClick={() => useStore.getState().adopt('auto')}>{s.result.plans.length ? '采用 AI 方案并自动执行' : '当前无可行方案，请先恢复机组能力'}</button>
            </div>
          </Panel>
        </div>
      </div>

      <SectionTitle extra={<span className="hint">点击机组卡片查看健康度与七维诊断</span>}>设备区域 · A1 - A4</SectionTitle>
      <div className="grid grid-auto device-grid">
        {s.machines.map((m, i) => {
          const c = engine.configs[i]
          const suggested = recPlan.units.find(u => u.id === m.id)
          const cells = [
            { k: '运行状态', v: statusLabel(m.status), color: m.status === 'running' ? 'var(--green)' : m.status === 'fault' ? 'var(--red)' : m.status === 'maintenance' ? 'var(--amber)' : 'var(--dim)' },
            { k: '负载率', v: `${Math.round(m.load * 100)}%`, color: 'var(--text)' },
            { k: '流量', v: `${m.flow.toFixed(0)}`, color: 'var(--text)' },
            { k: '功率', v: `${m.power.toFixed(0)}kW`, color: 'var(--text)' },
            { k: '健康度', v: `${Math.round(m.health)}`, color: healthColor(m.health) },
            { k: '启停次数', v: `${m.startsTotal}`, color: 'var(--text)' },
          ]
          return (
            <div key={m.id} className={`device-card ${suggested ? 'active' : ''}`} onClick={() => navigate('/health')}>
              <div className="device-head">
                <div className={`mchip ${m.status}`}>{m.id}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 6 }}>
                    <b style={{ fontSize: 13, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.name}</b>
                    <span className={`badge ${m.status}`}>{statusLabel(m.status)}</span>
                  </div>
                  <div className="bar" style={{ marginTop: 6 }}>
                    <i style={{ width: `${m.load * 100}%`, background: m.status === 'running' ? (m.load > 0.94 ? 'var(--red)' : 'var(--green)') : 'var(--dim2)' }} />
                  </div>
                </div>
                {suggested && <span className="badge info">建议运行</span>}
              </div>
              <div className="device-stats">
                {cells.map(cc => (
                  <div key={cc.k}><div className="k">{cc.k}</div><div className="v num" style={{ color: cc.color }}>{cc.v}</div></div>
                ))}
              </div>
              {suggested ? (
                <div className="hint" style={{ marginTop: 6, color: 'var(--cyan)' }}>方案预计：{suggested.flow} Nm³/h · {suggested.power} kW @ {Math.round(suggested.load * 100)}%</div>
              ) : m.status === 'running' ? (
                <div className="hint" style={{ marginTop: 6 }}>方案预计：停机退出（消除空载损耗）</div>
              ) : null}
            </div>
          )
        })}
      </div>

      <SectionTitle extra={<><button className="btn ghost" style={{ padding: '3px 10px', fontSize: 11.5 }} onClick={() => navigate('/scheduling')}>方案对比 →</button><button className="btn ghost" style={{ padding: '3px 10px', fontSize: 11.5, marginLeft: 6 }} onClick={() => navigate('/report')}>生成报告 →</button></>}>调度区域 · 当前方案 vs AI 优化方案</SectionTitle>
      <Panel pad={false}>
        <div className="dispatch-compare">
          <div style={{ gridColumn: '1 / -1', color: 'var(--dim)', fontSize: 11, marginBottom: 2 }}>
            计算基准：定频机组「压带启停 + 满载/空载」级联模型（含 1.12 切换损耗系数）· 电价 {s.priceNow.toFixed(2)} 元/kWh（{s.pricePeriod === 'peak' ? '峰' : s.pricePeriod === 'flat' ? '平' : '谷'}段）· 口径：同一时刻需求 {Math.round(demand)} Nm³/h · 数据为仿真值
          </div>
          <div className="dc-col">
            <div className="dc-title" style={{ color: 'var(--dim)' }}>当前方案（现场实况）</div>
            <div className="dc-combo num">{cur.units.map(u => `${u.id}@${Math.round(u.load * 100)}%`).join('+') || '—'}</div>
            <div className="dc-rows">
              <div><span>总功率</span><b className="num">{cur.totalPower} kW</b></div>
              <div><span>单位能耗</span><b className="num">{(cur.specificPower || 0).toFixed(3)}</b></div>
              <div><span>小时电费</span><b className="num">¥{cur.costPerHour}</b></div>
              <div><span>压力波动σ</span><b className="num">{cur.pressureStdEst} bar</b></div>
              <div><span>供气裕度</span><b className="num">{cur.reserveRatio}%</b></div>
              <div><span>可扩备用容量</span><b className="num">{expandReserve.toFixed(0)}%</b></div>
              <div><span>设备利用率</span><b className="num">{utilCur.toFixed(0)}%</b></div>
            </div>
          </div>
          <div className="dc-arrow">
            <div className="dc-badge">节能比例 <b>{predSave.toFixed(1)}%</b></div>
            <div className="dc-arrowline">→</div>
            <div className="dc-sub">压力变化 <b>{(cur.pressureStdEst - recPlan.pressureStdEst).toFixed(3)}</b> bar<br />供气裕度 <b>{recPlan.reserveRatio}%</b></div>
          </div>
          <div className="dc-col ai">
            <div className="dc-title" style={{ color: 'var(--cyan)' }}>AI 优化方案（{s.adoptedKey === 'baseline' ? '待采用' : '执行中'}）</div>
            <div className="dc-combo num" style={{ color: 'var(--cyan)' }}>{recPlan.units.map(u => `${u.id}@${Math.round(u.load * 100)}%`).join('+') || '保底'}</div>
            <div className="dc-rows">
              <div><span>总功率</span><b className="num" style={{ color: 'var(--cyan)' }}>{recPlan.totalPower} kW</b></div>
              <div><span>单位能耗</span><b className="num" style={{ color: 'var(--cyan)' }}>{recPlan.specificPower.toFixed(3)}</b></div>
              <div><span>小时电费</span><b className="num" style={{ color: 'var(--cyan)' }}>¥{recPlan.costPerHour}</b></div>
              <div><span>压力波动σ</span><b className="num" style={{ color: 'var(--cyan)' }}>{recPlan.pressureStdEst} bar</b></div>
              <div><span>供气裕度</span><b className="num" style={{ color: 'var(--cyan)' }}>{recPlan.reserveRatio}%</b></div>
              <div><span>可扩备用容量</span><b className="num" style={{ color: 'var(--cyan)' }}>{expandReserve.toFixed(0)}%</b></div>
              <div><span>设备利用率</span><b className="num" style={{ color: 'var(--cyan)' }}>{utilRec.toFixed(0)}%</b></div>
            </div>
          </div>
        </div>
      </Panel>
    </div>
  )
}
