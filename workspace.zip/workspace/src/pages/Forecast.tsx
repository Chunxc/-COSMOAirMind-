import { useMemo } from 'react'
import { useStore } from '../store'
import { engine } from '../store'
import { EChart, Panel, KPI, CHART_BASE, C } from '../components/ui'

export default function ForecastPage() {
  const s = useStore()
  const t = useStore(x => x.tickCount)
  const f = s.forecast

  const opt = useMemo(() => {
    const hist = engine.history.filter(p => p.t >= engine.simTime - 12 * 3600000)
    return {
      ...CHART_BASE,
      legend: { ...CHART_BASE.legend, data: ['历史需求', '预测需求', '预测区间'] },
      grid: { ...CHART_BASE.grid, top: 34, bottom: 40 },
      dataZoom: [
        { type: 'inside', xAxisIndex: 0 },
        { type: 'slider', height: 16, bottom: 6, borderColor: 'rgba(56,189,248,0.2)', fillerColor: 'rgba(56,189,248,0.08)', textStyle: { color: '#7d92ab', fontSize: 9 } },
      ],
      xAxis: { type: 'time', ...CHART_BASE.AXIS },
      yAxis: { type: 'value', name: 'Nm³/h', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS },
      series: [
        { name: '历史需求', type: 'line', showSymbol: false, data: hist.map(p => [p.t, p.demand.toFixed(1)]), lineStyle: { color: C.base, width: 1.4 }, areaStyle: { color: 'rgba(125,146,171,0.06)' },
          markLine: { silent: true, symbol: 'none', label: { formatter: '当前', color: '#22d3ee', fontSize: 10 }, lineStyle: { color: '#22d3ee', type: 'dashed' }, data: [{ xAxis: engine.simTime }] } },
        { name: '预测需求', type: 'line', showSymbol: false, data: f.horizon.map((h, i) => [h, f.values[i].toFixed(1)]), lineStyle: { color: C.demand, width: 2 } },
        {
          name: '预测区间', type: 'line', showSymbol: false, stack: 'band', data: f.horizon.map((h, i) => [h, (f.upper[i] - f.lower[i]).toFixed(1)]),
          lineStyle: { opacity: 0 }, areaStyle: { color: 'rgba(246,183,60,0.08)' }, tooltip: { show: false },
        },
        {
          name: 'bandbase', type: 'line', showSymbol: false, data: f.horizon.map((h, i) => [h, f.lower[i].toFixed(1)]),
          lineStyle: { opacity: 0 }, stack: 'band', silent: true, tooltip: { show: false },
        },
      ],
    }
  }, [t])

  return (
    <div className="anim-in grid" style={{ gap: 12 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12 }}>
        <Panel><div className="kpi" style={{ background: 'transparent' }}>
          <div className="label">当前需求</div><div className="value">{Math.round(s.station.demand)}<small>Nm³/h</small></div>
        </div></Panel>
        <Panel><div className="kpi" style={{ background: 'transparent' }}>
          <div className="label">未来 30 分钟</div><div className="value" style={{ color: 'var(--cyan)' }}>{Math.round(f.f30)}</div>
        </div></Panel>
        <Panel><div className="kpi" style={{ background: 'transparent' }}>
          <div className="label">未来 1 小时</div><div className="value" style={{ color: 'var(--amber)' }}>{Math.round(f.f60)}</div>
        </div></Panel>
        <Panel><div className="kpi" style={{ background: 'transparent' }}>
          <div className="label">未来 4 小时均值</div><div className="value">{Math.round(f.f240)}</div>
        </div></Panel>
        <Panel><div className="kpi" style={{ background: 'transparent' }}>
          <div className="label">需求趋势</div><div className="value" style={{ color: f.trend === 'up' ? 'var(--red)' : f.trend === 'down' ? 'var(--green)' : 'var(--dim)' }}>
            {f.trend === 'up' ? '↑ 上升' : f.trend === 'down' ? '↓ 下降' : '→ 平稳'}</div>
          <div className="delta flatx">未来1h vs 当前 {f.trendPct >= 0 ? '+' : ''}{f.trendPct.toFixed(1)}%</div>
        </div></Panel>
        <Panel><div className="kpi" style={{ background: 'transparent' }}>
          <div className="label">预测置信度</div><div className="value">{Math.round(f.confidence * 100)}<small>%</small></div>
          <div className="delta flatx">峰值 {Math.round(f.peak)} / 谷值 {Math.round(f.trough)} Nm³/h</div>
        </div></Panel>
      </div>

      {s.preDispatch ? (
        <Panel style={{ borderColor: s.preDispatch.escalate ? 'rgba(246,183,60,0.5)' : 'var(--line)' }}>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <span className={`badge ${s.preDispatch.escalate ? 'warn' : 'info'}`} style={{ fontSize: 12 }}>
              {s.preDispatch.escalate ? '预测上升 · 建议提前增机' : '预测调度提示'}
            </span>
            <div style={{ flex: 1, fontSize: 12.5, lineHeight: 1.7 }}>{s.preDispatch.reason}</div>
            {s.preDispatch.escalate && (
              <div style={{ textAlign: 'right', minWidth: 150 }}>
                <div className="num" style={{ color: 'var(--amber)', fontSize: 16, fontWeight: 700 }}>{s.preDispatch.inMinutes} min 内</div>
                <div className="hint">缺口 {s.preDispatch.supplyGap} Nm³/h · 建议启动 <b style={{ color: 'var(--cyan)' }}>{s.preDispatch.recommendStarts.join('、') || '备用机组'}</b></div>
              </div>
            )}
          </div>
        </Panel>
      ) : (
        <Panel style={{ borderColor: 'rgba(45,212,160,0.3)' }}>
          <div className="hint">当前运行机组可调能力足以覆盖未来 4 小时预测需求（峰值 {Math.round(f.peak)} Nm³/h），暂无需提前增机 —— 预测结果已作为调度目标输入。</div>
        </Panel>
      )}
      <Panel title="用气负荷预测：过去 12 小时 → 未来 4 小时" sub={`${f.method}（预测为估计值，非实测）`} pad={false}>
        <EChart option={opt} height={340} style={{ padding: '6px 8px 10px' }} />
      </Panel>

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr 1fr', gap: 12 }}>
        <Panel title="未来需求快照（调度器输入）">
          <table className="dt num">
            <thead><tr><th>时间点</th><th>预测需求</th><th>90%区间</th></tr></thead>
            <tbody>
              {[30, 60, 120, 240].map(k => (
                <tr key={k}>
                  <td>+{k} 分钟</td>
                  <td style={{ color: 'var(--cyan)' }}>{Math.round(f.values[k - 1])} Nm³/h</td>
                  <td style={{ color: 'var(--dim)' }}>{Math.round(f.lower[k - 1])} - {Math.round(f.upper[k - 1])}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="hint" style={{ marginTop: 8 }}>
            调度器以 max(当前需求×1.01, 30min预测, 0.97×60min预测) 为目标供气量做组合优化；趋势↑时自动提高罐压设定（预充能）。
          </div>
        </Panel>
        <Panel title="预测方法说明">
          <div className="hint" style={{ lineHeight: 2 }}>
            <div><b style={{ color: 'var(--cyan)' }}>1. Holt 双指数平滑</b>：对最近 240 分钟数据估计水平项与趋势项，捕捉负荷的惯性走势。</div>
            <div><b style={{ color: 'var(--cyan)' }}>2. 日内基线曲线</b>：班制负荷模式（夜班低谷 / 早班爬坡 / 双高峰 / 午间回落）作为远端收敛目标。</div>
            <div><b style={{ color: 'var(--cyan)' }}>3. 加权融合</b>：近端由趋势主导（e^(-k/55) 衰减），远端收敛到日内模式，兼顾响应性与规律性。</div>
            <div><b style={{ color: 'var(--cyan)' }}>4. 置信区间</b>：由平滑残差 σ 外扩 1.65σ，随步长增大而展宽，供备用容量计算使用。</div>
          </div>
        </Panel>
        <Panel title="对调度的影响（自动联动）">
          <div className="hint" style={{ lineHeight: 2 }}>
            <div>{f.trend === 'up'
              ? `预测上涨 ${f.trendPct.toFixed(0)}%：AI 提前锁定更多机组组合，避免罐压触底后再被动启机（滞后且抖动）。`
              : f.trend === 'down'
              ? `预测下降 ${Math.abs(f.trendPct).toFixed(0)}%：AI 优先安排大机组退出，减少空载等待损耗，并将启停动作后置到负荷真正回落时。`
              : '负荷平稳：调度重心从「保供」转向「节能与设备轮换保护」。'}</div>
            <div>调度评分中的「未来需求保障」维度直接读取 30/60/240 分钟预测值 —— 预测越准，越敢少开机、多省电。</div>
            <div>预测波动大时，备用容量目标自动上浮（见约束校验页）。</div>
          </div>
        </Panel>
      </div>

    </div>
  )
}
