import { useStore, engine } from '../store'
import { Panel, statusLabel } from '../components/ui'

export default function Sandbox() {
  const s = useStore()
  const rec = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current
  const tankPct = Math.max(0, Math.min(1, (s.station.tank - 5.2) / (10 - 5.2)))
  const demandPct = Math.min(1, s.station.demand / 1400)
  const supplyFlow = Math.max(0.25, s.station.supply / 1600)

  const M = s.machines
  return (
    <div className="anim-in grid" style={{ gap: 12 }}>
      <Panel title="空压站数字孪生 · 调度沙盘" sub="流量=管径与流速动画 · 颜色=设备状态 · 光晕=AI 推荐"
        right={<>
          <button className="btn ghost" onClick={() => useStore.getState().injectDemandShock(20, 22, '用气需求 +20%')}>模拟需求 +20%</button>
          <button className="btn ghost" onClick={() => useStore.getState().injectDemandShock(40, 25, '用气需求 +40%')}>模拟需求 +40%</button>
          <button className="btn danger" onClick={() => useStore.getState().toggleFault('A2')}>模拟 A2 故障</button>
          <button className="btn ghost" onClick={() => useStore.getState().triggerTankDrop()}>罐压骤降</button>
        </>}>
        <svg viewBox="0 0 940 396" style={{ width: '100%', display: 'block' }}>
          <defs>
            <linearGradient id="tankG" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.75" />
              <stop offset="100%" stopColor="#155e9c" stopOpacity="0.85" />
            </linearGradient>
            <linearGradient id="pipeG" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#4a9eff" stopOpacity="0.25" />
            </linearGradient>
            <filter id="glow"><feGaussianBlur stdDeviation="3" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
          </defs>

          {/* 压缩机 */}
          {M.map((m, i) => {
            const y = 34 + i * 86
            const col = m.status === 'running' ? '#2dd4a0' : m.status === 'fault' ? '#f4586a' : m.status === 'maintenance' ? '#f6b73c' : '#50637a'
            const inPlan = rec.units.some(u => u.id === m.id)
            const planU = rec.units.find(u => u.id === m.id)
            return (
              <g key={m.id} onClick={() => useStore.getState().updateConfig(m.id, {})} style={{ cursor: 'pointer' }}>
                <rect x={14} y={y} width={132} height={66} rx={10}
                  fill="#0a1522" stroke={inPlan ? '#22d3ee' : '#16283f'} strokeWidth={inPlan ? 2 : 1}
                  filter={inPlan ? 'url(#glow)' : undefined} />
                <text x={28} y={y + 24} fill={col} fontSize={16} fontWeight={700} fontFamily="var(--mono)">A{i + 1}</text>
                <text x={66} y={y + 24} fill="#7d92ab" fontSize={10}>{engine.configs.find(c => c.id === `A${i + 1}`)!.ratedFlow} Nm³/h</text>
                {/* 状态灯 + 风扇 */}
                <circle cx={132} cy={y + 18} r={5} fill={col} opacity={m.status === 'fault' ? 1 : 0.9}>
                  {m.status === 'running' && <animate attributeName="opacity" values="0.5;1;0.5" dur="1.6s" repeatCount="indefinite" />}
                  {m.status === 'fault' && <animate attributeName="opacity" values="1;0.2;1" dur="0.8s" repeatCount="indefinite" />}
                </circle>
                <g transform={`translate(40, ${y + 46})`}>
                  <circle r={11} fill="none" stroke={col} strokeWidth={1.4} opacity={0.5} />
                  <g>{m.status === 'running' && <animateTransform attributeName="transform" type="rotate" from="0" to="360" dur={`${1.7 - (m.load || 0.1)}s`} repeatCount="indefinite" />}
                    {[0, 120, 240].map(a => <path key={a} d="M0 0 L2 -8 A8 8 0 0 1 7 -5 Z" fill={col} opacity={m.status === 'running' ? 0.85 : 0.25} transform={`rotate(${a})`} />)}
                  </g>
                </g>
                <text x={62} y={y + 44} fill="#d9e5f2" fontSize={12} fontFamily="var(--mono)">{Math.round((m.load || 0) * 100)}%</text>
                <text x={62} y={y + 57} fill="#7d92ab" fontSize={10} fontFamily="var(--mono)">{Math.round(m.power)} kW</text>
                <text x={112} y={y + 44} fill="#7d92ab" fontSize={10} fontFamily="var(--mono)">H{Math.round(m.health)}</text>
                <text x={108} y={y + 57} fill={col} fontSize={10}>{statusLabel(m.status)}</text>
                {/* 进气 */}
                <path d={`M2 ${y + 34} L14 ${y + 34}`} stroke="#31506e" strokeWidth={2} markerEnd="" />
                <text x={-4} y={y + 30} fill="#31506e" fontSize={8}>进气</text>
                {/* 出口管道 -> 汇管 */}
                {m.status === 'running'
                  ? <line x1={146} y1={y + 33} x2={146} y2={200} stroke="url(#pipeG)" strokeWidth={4}>
                    </line>
                  : <line x1={146} y1={y + 33} x2={146} y2={200} stroke="#16283f" strokeWidth={2} strokeDasharray="3 5" />}
                {m.status === 'running' && (
                  <line x1={146} y1={y + 33} x2={146} y2={200} stroke="#22d3ee" strokeWidth={2.2} className="flow-anim" opacity={0.8} style={{ transform: 'scaleY(-1)', transformOrigin: '146px 116px' }} />
                )}
                {inPlan && m.status !== 'running' && <text x={146} y={y - 4} fill="#22d3ee" fontSize={10}>AI: {Math.round((planU?.load ?? 0) * 100)}%</text>}
                {inPlan && m.status === 'running' && <rect x={14} y={y} width={132} height={66} rx={10} fill="none" stroke="#22d3ee" strokeDasharray="5 4" strokeWidth={1}>
                  <animate attributeName="stroke-dashoffset" from="0" to="-18" dur="1.2s" repeatCount="indefinite" />
                </rect>}
              </g>
            )
          })}

          {/* 汇管 */}
          <line x1={168} y1={200} x2={258} y2={200} stroke="#1c3a55" strokeWidth={10} strokeLinecap="round" />
          <line x1={168} y1={200} x2={258} y2={200} stroke="#22d3ee" strokeWidth={3} className="flow-anim" opacity={0.9}
            style={{ animationDuration: `${1.4 - supplyFlow}s` }} />
          <text x={178} y={186} fill="#7d92ab" fontSize={11}>储气汇管</text>
          <text x={178} y={216} fill="#d9e5f2" fontSize={11} fontFamily="var(--mono)">{Math.round(s.station.supply)} Nm³/h</text>

          {/* 储气罐 */}
          <g transform="translate(280,60)">
            <rect x={0} y={0} width={90} height={250} rx={26} fill="#0a1522" stroke="#16283f" strokeWidth={1.6} />
            <clipPath id="tankClip"><rect x={4} y={4} width={82} height={242} rx={22} /></clipPath>
            <rect x={4} y={4 + (242 - 242 * tankPct)} width={82} height={242 * tankPct} rx={10}
              fill="url(#tankG)" clipPath="url(#tankClip)" className="tank-gauge" />
            <text x={45} y={-12} fill="#7d92ab" fontSize={11} textAnchor="middle">储气罐 10m³</text>
            <text x={45} y={130} fill="#fff" fontSize={19} fontWeight={700} textAnchor="middle" fontFamily="var(--mono)" opacity={0.92}>{s.station.tank.toFixed(2)}</text>
            <text x={45} y={150} fill="#bfe9f7" fontSize={11} textAnchor="middle">bar</text>
            <text x={45} y={272} fill={s.station.tank < engine.safeMin + 0.6 ? '#f6b73c' : '#7d92ab'} fontSize={10} textAnchor="middle">工作带 {engine.bandLow}-{engine.bandHigh} · 下限 {engine.safeMin}</text>
          </g>

          {/* 罐到管网 */}
          <line x1={370} y1={185} x2={470} y2={185} stroke="#1c3a55" strokeWidth={10} strokeLinecap="round" />
          <line x1={370} y1={185} x2={470} y2={185} stroke="#9d7cf5" strokeWidth={3} className="flow-anim" opacity={0.85}
            style={{ animationDuration: `${1.6 - demandPct}s` }} />

          {/* 管网压力节点 */}
          <g transform="translate(470,132)">
            <rect x={0} y={0} width={150} height={106} rx={12} fill="#0a1522" stroke="#16283f" />
            <text x={12} y={22} fill="#7d92ab" fontSize={11}>管网（Header）</text>
            <text x={12} y={50} fill={s.station.header < engine.safeMin ? '#f4586a' : '#22d3ee'} fontSize={21} fontWeight={700} fontFamily="var(--mono)">{s.station.header.toFixed(2)}<tspan fontSize={11} fill="#7d92ab"> bar</tspan></text>
            <text x={12} y={72} fill="#d9e5f2" fontSize={11} fontFamily="var(--mono)">需求 {Math.round(s.station.demand)} Nm³/h</text>
            <text x={12} y={90} fill="#7d92ab" fontSize={10} fontFamily="var(--mono)">预测+30min {Math.round(s.forecast.f30)}</text>
            {s.station.header < engine.safeMin + 0.4 && (
              <text x={118} y={26} fill="#f4586a" fontSize={11}>⚠ 低压</text>
            )}
          </g>

          {/* 分支到车间 */}
          <line x1={620} y1={185} x2={690} y2={185} stroke="#1c3a55" strokeWidth={8} />
          {[60, 170, 280].map((y, i) => (
            <g key={i}>
              <line x1={690} y1={185} x2={758} y2={y + 50} stroke="#16283f" strokeWidth={5} />
              <line x1={690} y1={185} x2={758} y2={y + 50} stroke="#2dd4a0" strokeWidth={1.8} className="flow-anim flow-slow" opacity={0.75 - i * 0.12}
                style={{ animationDuration: `${1.5 - demandPct * 0.8}s` }} />
              <g transform={`translate(758,${y + 18})`}>
                <rect width={168} height={70} rx={10} fill="#0a1522" stroke="#16283f" />
                <path d={`M14 52 L14 26 L30 26 L30 52 M30 38 L44 38 L44 52 M44 30 L58 30 L58 52`} stroke={i === 0 ? '#f6b73c' : '#31506e'} strokeWidth={1.6} fill="none" />
                <text x={70} y={26} fill="#7d92ab" fontSize={10.5}>{['装配车间', '涂装车间', '包装维修'][i]}</text>
                <text x={70} y={44} fill="#d9e5f2" fontSize={11} fontFamily="var(--mono)">{Math.round(s.station.demand * [0.45, 0.32, 0.23][i])} Nm³/h</text>
              </g>
            </g>
          ))}

          {/* 供需指示 */}
          <g transform="translate(14, 372)">
            <text fill="#7d92ab" fontSize={11}>
              供 {Math.round(s.station.supply)} vs 需 {Math.round(s.station.demand)} Nm³/h
            </text>
            <text x={230} fill={s.station.supply >= s.station.demand ? '#2dd4a0' : '#f4586a'} fontSize={11} fontWeight={700}>
              {s.station.supply >= s.station.demand ? '● 供大于求，罐压蓄能' : '● 供不应求，罐压释放'}
            </text>
            <text x={470} fill="#7d92ab" fontSize={11}>
              AI 推荐组合：{rec.units.map(u => `${u.id}@${Math.round(u.load * 100)}%`).join(' + ') || '保供降级'} · 评分 {rec.totalScore}
            </text>
          </g>
        </svg>
      </Panel>

      <div style={{ display: 'grid', gridTemplateColumns: '1.25fr 1fr 1fr', gap: 12 }}>
        <Panel title="手动调控台" sub="调整后点击「AI 重新调度」" style={{ borderColor: 'rgba(34,211,238,0.35)' }}>
          <div style={{ display: 'grid', gap: 10 }}>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span>空气需求量</span>
                <b className="num" style={{ color: 'var(--cyan)' }}>{Math.round(s.demandOverride ?? s.station.demand)} Nm³/h {s.demandOverride != null && <span className="badge warn" style={{ marginLeft: 4 }}>手动</span>}</b>
              </div>
              <input type="range" min={150} max={2600} step={10} value={Math.round(s.demandOverride ?? s.station.demand)}
                onChange={e => useStore.getState().setDemandOverride(parseInt(e.target.value, 10))} />
              {s.demandOverride != null && <button className="btn ghost" style={{ padding: '1px 8px', fontSize: 10.5 }} onClick={() => useStore.getState().setDemandOverride(null)}>恢复自动</button>}
            </div>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span>目标罐压设定</span>
                <b className="num" style={{ color: 'var(--cyan)' }}>{(s.tankSetpointOverride ?? rec.tankSetpoint).toFixed(2)} bar {s.tankSetpointOverride != null && <span className="badge warn" style={{ marginLeft: 4 }}>手动</span>}</b>
              </div>
              <input type="range" min={7.0} max={8.8} step={0.05} value={s.tankSetpointOverride ?? rec.tankSetpoint}
                onChange={e => useStore.getState().setTankSetpointOverride(parseFloat(e.target.value))} />
              {s.tankSetpointOverride != null && <button className="btn ghost" style={{ padding: '1px 8px', fontSize: 10.5 }} onClick={() => useStore.getState().setTankSetpointOverride(null)}>恢复自动</button>}
            </div>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span>电价</span>
                <b className="num" style={{ color: 'var(--cyan)' }}>¥{(s.priceOverride ?? s.priceNow).toFixed(2)}/kWh {s.priceOverride != null && <span className="badge warn" style={{ marginLeft: 4 }}>手动</span>}</b>
              </div>
              <input type="range" min={0.2} max={1.5} step={0.01} value={s.priceOverride ?? s.priceNow}
                onChange={e => useStore.getState().setPriceOverride(parseFloat(e.target.value))} />
              {s.priceOverride != null && <button className="btn ghost" style={{ padding: '1px 8px', fontSize: 10.5 }} onClick={() => useStore.getState().setPriceOverride(null)}>恢复自动</button>}
            </div>
            <div>
              <div className="hint" style={{ marginBottom: 4 }}>设备状态手动设置</div>
              <div style={{ display: 'grid', gap: 5 }}>
                {s.machines.map(m => (
                  <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11.5 }}>
                    <b className="num" style={{ width: 24 }}>{m.id}</b>
                    <span className={`badge ${m.status}`} style={{ width: 52, justifyContent: 'center' }}>{statusLabel(m.status)}</span>
                    <div style={{ display: 'flex', gap: 3, marginLeft: 'auto' }}>
                      <button className={`btn ghost`} style={{ padding: '1px 7px', fontSize: 10.5, color: m.status !== 'fault' && m.status !== 'maintenance' ? 'var(--cyan)' : undefined }} onClick={() => useStore.getState().setMachineMode(m.id, 'auto')}>自动</button>
                      <button className="btn danger" style={{ padding: '1px 7px', fontSize: 10.5 }} onClick={() => useStore.getState().setMachineMode(m.id, 'fault')}>故障</button>
                      <button className="btn amber" style={{ padding: '1px 7px', fontSize: 10.5 }} onClick={() => useStore.getState().setMachineMode(m.id, 'maintenance')}>检修</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <button className="btn primary lg" style={{ width: '100%' }} onClick={() => useStore.getState().rescheduleNow()}>AI 重新调度</button>
            <div className="hint">使用与核心调度完全一致的算法与数据（同一 optimizer / engine）：目标负荷、罐压设定、组合评分即时刷新。</div>
          </div>
        </Panel>

        <Panel title="方案对比 A / B / AI" sub="AI=综合最优(C)">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            {(['A', 'B', 'C'] as const).map(k => {
              const p = s.result.plans.find(x => x.key === k)
              if (!p) return <div key={k} className="hint">—</div>
              const isAI = k === 'C'
              return (
                <div key={k} style={{ padding: '8px 9px', borderRadius: 8, border: `1px solid ${isAI ? 'rgba(34,211,238,0.5)' : 'var(--line)'}`, background: isAI ? 'rgba(34,211,238,0.06)' : 'var(--panel2)' }}>
                  <div style={{ fontSize: 11.5, fontWeight: 600, color: isAI ? 'var(--cyan)' : 'var(--dim)' }}>{isAI ? 'AI 综合最优' : `方案${k}`}</div>
                  <div className="num" style={{ fontSize: 12, color: 'var(--cyan)', margin: '4px 0', minHeight: 32 }}>{p.units.map(u => `${u.id}@${Math.round(u.load * 100)}`).join('+') || '保底'}</div>
                  <table className="num" style={{ fontSize: 10.5, width: '100%' }}>
                    <tbody>
                      <tr><td style={{ color: 'var(--dim)' }}>功率</td><td style={{ textAlign: 'right' }}>{p.totalPower}kW</td></tr>
                      <tr><td style={{ color: 'var(--dim)' }}>单位能耗</td><td style={{ textAlign: 'right' }}>{p.specificPower.toFixed(3)}</td></tr>
                      <tr><td style={{ color: 'var(--dim)' }}>备用</td><td style={{ textAlign: 'right' }}>{p.reserveRatio}%</td></tr>
                      <tr><td style={{ color: 'var(--dim)' }}>评分</td><td style={{ textAlign: 'right', color: 'var(--green)' }}>{p.totalScore}</td></tr>
                    </tbody>
                  </table>
                  <button className={`btn ${s.adoptedKey === (isAI ? 'auto' : k) ? 'primary' : 'ghost'}`} style={{ width: '100%', marginTop: 6, padding: '2px', fontSize: 10.5 }} onClick={() => useStore.getState().adopt(isAI ? 'auto' : k)}>{s.adoptedKey === (isAI ? 'auto' : k) ? '执行中' : '采用'}</button>
                </div>
              )
            })}
          </div>
        </Panel>

        <Panel title="调度前后对比" sub="现场当前 → AI 方案">
          <table className="dt num" style={{ fontSize: 11.5 }}>
            <thead><tr><th>指标</th><th>调度前</th><th>调度后</th><th>变化</th></tr></thead>
            <tbody>
              {(() => {
                const cur = s.result.current
                const utilCur = (() => { const r = s.machines.filter(m => m.status === 'running'); return r.length ? r.reduce((a, m) => a + m.load, 0) / r.length * 100 : 0 })()
                const utilRec = rec.units.length ? rec.units.reduce((a, u) => a + u.load, 0) / rec.units.length * 100 : 0
                const rows = [
                  { n: '总功率', b: `${cur.totalPower} kW`, a: `${rec.totalPower} kW`, good: rec.totalPower <= cur.totalPower },
                  { n: '单位能耗', b: `${(cur.specificPower || 0).toFixed(3)}`, a: `${rec.specificPower.toFixed(3)}`, good: rec.specificPower <= (cur.specificPower || 9) },
                  { n: '压力稳定性σ', b: `${cur.pressureStdEst} bar`, a: `${rec.pressureStdEst} bar`, good: rec.pressureStdEst <= cur.pressureStdEst },
                  { n: '备用容量', b: `${cur.reserveRatio}%`, a: `${rec.reserveRatio}%`, good: rec.reserveRatio >= cur.reserveRatio },
                  { n: '设备利用率', b: `${utilCur.toFixed(0)}%`, a: `${utilRec.toFixed(0)}%`, good: utilRec >= 55 && utilRec <= 95 },
                ]
                return rows.map(r => (
                  <tr key={r.n}>
                    <td style={{ color: 'var(--dim)' }}>{r.n}</td>
                    <td>{r.b}</td>
                    <td style={{ color: 'var(--cyan)' }}>{r.a}</td>
                    <td style={{ color: r.good ? 'var(--green)' : 'var(--amber)' }}>{r.good ? '✓ 优' : '!'}</td>
                  </tr>
                ))
              })()}
            </tbody>
          </table>
          <div className="hint" style={{ marginTop: 8 }}>调度前=现场实际运行工况，调度后=AI 推荐方案。所有数值取自同一 optimizer 实时输出。</div>
        </Panel>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        <Panel title="调度链路">
          <div className="hint" style={{ lineHeight: 2.2 }}>
            <div>1️⃣ 采集：四机组工况 + 罐压/管网压力 + 需求计量（每 tick 仿真 1 分钟）</div>
            <div>2️⃣ 预测：Holt 趋势 × 日内模式 → 未来 4h 需求曲线</div>
            <div>3️⃣ 评估：六维健康度 + 滚动窗口异常检测</div>
            <div>4️⃣ 优化：组合枚举 → DP 负荷分配 → 多目标评分（三方案）</div>
            <div>5️⃣ 下发：推荐方案目标负荷 → 机组执行，罐压设定联动电价</div>
            <div>6️⃣ 反馈：实际供需失衡 → PI 微调负荷（沙盘上流量动画实时变化）</div>
          </div>
          <button className="btn primary" style={{ width: '100%', marginTop: 8 }} onClick={() => useStore.getState().adopt('auto')}>
            让 AI 接管沙盘
          </button>
        </Panel>
        <Panel title="实时对照：AI 计划 vs 现场执行">
          <table className="dt num" style={{ fontSize: 11.5 }}>
            <thead><tr><th>机组</th><th>现场</th><th>AI 计划</th><th>状态</th></tr></thead>
            <tbody>
              {s.machines.map(m => {
                const planU = rec.units.find(u => u.id === m.id)
                const dev = planU ? Math.abs((m.loaded ? m.load : 0) - planU.load) : (m.status === 'running' ? 1 : 0)
                return (
                  <tr key={m.id}>
                    <td><b>{m.id}</b></td>
                    <td>{m.status === 'running' ? `${Math.round(m.load * 100)}%` : statusLabel(m.status)}</td>
                    <td style={{ color: 'var(--cyan)' }}>{planU ? `${Math.round(planU.load * 100)}%` : '停机'}</td>
                    <td>{m.status === 'fault' ? <span className="badge danger">已隔离</span> : dev < 0.12 ? <span className="badge ok">一致</span> : <span className="badge warn"> ramping…</span>}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          <div className="hint" style={{ marginTop: 8 }}>现场按级联压力控制自启停；采用 AI 后执行计划负荷（ramping 表示正在爬坡对齐）。</div>
        </Panel>
        <Panel title="快速事件（点击注入沙盘）">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <button className="btn ghost" onClick={() => useStore.getState().injectDemandShock(20, 22, '需求 +20%')}>需求 +20%</button>
            <button className="btn ghost" onClick={() => useStore.getState().injectDemandShock(40, 25, '需求 +40%')}>需求 +40%</button>
            {['A1', 'A2', 'A3', 'A4'].map(id => {
              const f = s.machines.find(m => m.id === id)!.status === 'fault'
              return <button key={id} className={`btn ${f ? 'amber' : 'danger'}`} onClick={() => useStore.getState().toggleFault(id)}>{f ? `恢复 ${id}` : `${id} 故障`}</button>
            })}
            <button className="btn ghost" onClick={() => useStore.getState().triggerTankDrop()}>罐压骤降 -0.75</button>
            <button className="btn ghost" onClick={() => useStore.getState().triggerForcePeak()}>电价进峰段</button>
            <button className="btn ghost" style={{ gridColumn: '1/3' }} onClick={() => useStore.getState().clearEvents()}>清除事件冲击</button>
          </div>
          <div className="divider" />
          <div className="hint">故障注入后：设备变红并被移出调度集合 → 优化器在下一个 tick 自动重算组合（观察「AI 计划」列变化与评分更新）。</div>
        </Panel>
      </div>
    </div>
  )
}
