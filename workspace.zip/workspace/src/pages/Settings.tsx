import { useStore, engine } from '../store'
import { Panel, healthColor } from '../components/ui'
import type { PlanScores } from '../lib/types'

const WEIGHT_LABELS: { key: keyof PlanScores; label: string; desc: string }[] = [
  { key: 'energy', label: '能源成本', desc: '电费与单位能耗的权重' },
  { key: 'stability', label: '压力稳定性', desc: '供求裕度与压力波动的权重' },
  { key: 'cycling', label: '启停控制', desc: '启动/停机次数的惩罚权重' },
  { key: 'health', label: '设备健康', desc: '低健康机组高负荷的惩罚权重' },
  { key: 'reserve', label: '备用容量', desc: '组合外可扩能力的权重' },
  { key: 'efficiency', label: '运行效率', desc: '负荷落在高效区的权重' },
]

export default function Settings() {
  const s = useStore()

  return (
    <div className="anim-in grid" style={{ gap: 12 }}>
      <Panel title="空压机机组参数（实时生效，参与物理仿真与调度优化）" sub="额定/负荷/成本类参数可修改；健康度与效率为动态计算值">
        <table className="dt">
          <thead>
            <tr><th>机组</th><th>额定流量 Nm³/h</th><th>额定功率 kW</th><th>最小负荷</th><th>最大负荷</th><th>基准效率</th><th>启停成本 ¥</th><th>最小运行 min</th><th>最小停机 min</th><th>健康度(实时)</th><th>状态操作</th></tr>
          </thead>
          <tbody>
            {engine.configs.map(c => {
              const m = s.machines.find(x => x.id === c.id)!
              return (
                <tr key={c.id}>
                  <td><b style={{ color: 'var(--cyan)' }}>{c.id}</b></td>
                  <td><NumCell v={c.ratedFlow} step={10} onChange={v => useStore.getState().updateConfig(c.id, { ratedFlow: v })} w={72} /></td>
                  <td><NumCell v={c.ratedPower} step={5} onChange={v => useStore.getState().updateConfig(c.id, { ratedPower: v })} w={64} /></td>
                  <td><NumCell v={c.minLoad} step={0.05} min={0.1} max={0.6} onChange={v => useStore.getState().updateConfig(c.id, { minLoad: v })} w={64} /></td>
                  <td><NumCell v={c.maxLoad} step={0.05} min={0.7} max={1.1} onChange={v => useStore.getState().updateConfig(c.id, { maxLoad: v })} w={64} /></td>
                  <td><NumCell v={c.baseEff} step={0.005} min={0.8} max={1.05} onChange={v => useStore.getState().updateConfig(c.id, { baseEff: v })} w={64} /></td>
                  <td><NumCell v={c.startCost} step={1} min={0} onChange={v => useStore.getState().updateConfig(c.id, { startCost: v })} w={56} /></td>
                  <td><NumCell v={c.minRunTime} step={1} min={0} max={60} onChange={v => useStore.getState().updateConfig(c.id, { minRunTime: v })} w={56} /></td>
                  <td><NumCell v={c.minStopTime} step={1} min={0} max={60} onChange={v => useStore.getState().updateConfig(c.id, { minStopTime: v })} w={56} /></td>
                  <td className="num" style={{ color: healthColor(m.health) }}>{Math.round(m.health)}</td>
                  <td>
                    {m.status === 'fault'
                      ? <button className="btn amber" onClick={() => useStore.getState().toggleFault(c.id)}>解除故障</button>
                      : m.status === 'maintenance'
                      ? <button className="btn" onClick={() => useStore.getState().toggleMaintenance(c.id)}>结束检修</button>
                      : <div style={{ display: 'flex', gap: 4 }}>
                        <button className="btn danger" style={{ padding: '3px 7px', fontSize: 11 }} onClick={() => useStore.getState().toggleFault(c.id)}>故障</button>
                        <button className="btn ghost" style={{ padding: '3px 7px', fontSize: 11 }} onClick={() => useStore.getState().toggleMaintenance(c.id)}>检修</button>
                      </div>}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        <div className="hint" style={{ marginTop: 8 }}>修改后调度优化器与仿真物理模型在下一个 tick 即使用新参数；健康度由系统根据温度/启停/负荷/异常动态计算，不可手改（符合真实工况）。</div>
      </Panel>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
        <Panel title="峰谷电价配置">
          <div className="grid" style={{ gap: 10, gridTemplateColumns: '1fr 1fr 1fr' }}>
            {(['valley', 'flat', 'peak'] as const).map(k => (
              <div key={k}>
                <label className="f">{k === 'valley' ? '谷价 (元/kWh)' : k === 'flat' ? '平价 (元/kWh)' : '峰价 (元/kWh)'}</label>
                <NumCell v={s.priceCfg[k]} step={0.01} min={0.1} max={2} onChange={v => useStore.getState().updatePrice({ [k]: v })} />
              </div>
            ))}
          </div>
          <div className="divider" />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <label className="f">峰段时段（小时区间）</label>
              <input type="text" defaultValue={s.priceCfg.peakHours.map(hrRanges).join(',')} onBlur={e => {
                const r = parseRanges(e.target.value)
                if (r) useStore.getState().updatePrice({ peakHours: r })
              }} />
            </div>
            <div>
              <label className="f">平段时段（小时区间）</label>
              <input type="text" defaultValue={s.priceCfg.flatHours.map(hrRanges).join(',')} onBlur={e => {
                const r = parseRanges(e.target.value)
                if (r) useStore.getState().updatePrice({ flatHours: r })
              }} />
            </div>
          </div>
          <div className="hint" style={{ marginTop: 8, lineHeight: 1.8 }}>
            未定义时段自动视为谷段。调度器在组合评分与储气罐设定中同时考虑「当前电价」与「未来6小时电价」：谷价末期自动蓄能（罐压↑），峰价初期释放储气少开机。
            <button className="btn ghost" style={{ padding: '2px 8px', fontSize: 11 }} onClick={() => useStore.getState().triggerForcePeak()}>强制峰价1小时</button>
          </div>
        </Panel>

        <Panel title="调度评分权重（综合最优方案的决策偏好）">
          {WEIGHT_LABELS.map(wl => (
            <div key={wl.key} style={{ marginBottom: 11 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span>{wl.label} <span className="hint" style={{ marginLeft: 6 }}>{wl.desc}</span></span>
                <b className="num" style={{ color: 'var(--cyan)' }}>{s.weights[wl.key].toFixed(2)}</b>
              </div>
              <input type="range" min={0} max={0.6} step={0.02} value={s.weights[wl.key]}
                onChange={e => useStore.getState().updateWeights({ [wl.key]: parseFloat(e.target.value) })} />
            </div>
          ))}
          <div className="hint">权重实时生效：观察「智能调度」页方案C的组合、负荷与评分如何随你的偏好变化 —— 例如健康权重拉到 0.4，低健康机组将自动让位。</div>
        </Panel>

        <Panel title="仿真与系统">
          <div className="grid" style={{ gap: 12 }}>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                <span>仿真速度（1× = 1 秒 ≈ 仿真 {Math.round(s.speed * 57)} 秒）</span><b className="num">{s.speed}×</b>
              </div>
              <input type="range" min={0.2} max={6} step={0.2} value={s.speed} onChange={e => useStore.getState().setSpeed(parseFloat(e.target.value))} />
            </div>
            <div className="btn-row">
              <button className={`btn ${s.running ? 'ghost' : 'primary'} `} onClick={() => useStore.getState().setRunning(!s.running)}>{s.running ? '暂停仿真' : '继续仿真'}</button>
              <button className="btn primary" onClick={() => useStore.getState().startDemo('quick')}>▶ 30 秒极速演示</button>
              <button className="btn ghost" onClick={() => useStore.getState().startDemo('full')}>▶ 完整演示（3 分钟）</button>
              {s.demo.running && <button className="btn danger" onClick={() => useStore.getState().stopDemo()}>结束演示</button>}
            </div>
            <div className="divider" />
            <div className="hint" style={{ lineHeight: 1.9 }}>
              <div><b style={{ color: 'var(--cyan)' }}>一键演示</b>：自动播放「正常生产 → 需求上涨预测 → AI重调度 → A2故障 → 检测隔离 → 自动优化 → 新方案执行 → 节能汇总」八阶段闭环，页面自动切换至对应视图。</div>
              <div><b style={{ color: 'var(--amber)' }}>重置系统</b>：恢复出厂设备参数与健康度基线，切换到传统压控并清空事件。</div>
            </div>
            <button className="btn danger" onClick={() => useStore.getState().resetAll()}>重置全部参数与场景</button>
          </div>
        </Panel>
      </div>

      <Panel title="技术架构与开源方法参考">
        <div className="hint" style={{ lineHeight: 2, columnCount: 2, columnGap: 28 }}>
          <div><b style={{ color: 'var(--cyan)' }}>数据层</b>：自研工业时序仿真引擎 —— 班制需求曲线（凌晨低谷/双高峰）× AR1 有色噪声 × 泊松冲击尖峰；定频机组压带启停 + 满载/空载能耗模型；储气罐等温气体动力学（供失衡 → 罐压积分 → 管网压降链）；温度一阶惯性 + 磨损耦合。</div>
          <div><b style={{ color: 'var(--cyan)' }}>预测层</b>：Holt 双指数平滑（水平+趋势）与日内基线模式加权混合，残差分位数置信带。（方法参照 statsmodels/Holt-Winters 与 sktime 的经典工程实践）</div>
          <div><b style={{ color: 'var(--cyan)' }}>优化层</b>：机组枚举（n≤4 全可行子集）→ 动态规划最优负荷分配（离散负荷网格最小功率）→ 六维目标评分（能耗/稳定/启停/健康/备用/效率），峰谷电价感知的罐压设定。可解释、确定性、毫秒级。（思路参照 PyPSA 机组承诺、openEMS 调度器的经典结构）</div>
          <div><b style={{ color: 'var(--cyan)' }}>健康层</b>：运行磨损/启停疲劳/温度史/高负荷占比/异常事件/效率衰减六因子动态扣分模型；滚动窗口 z-score 异常检测（思路参照 Yahoo EagleS 与 Facebook/Kats 的工业时序实践）。</div>
          <div><b style={{ color: 'var(--cyan)' }}>智能体层</b>：规则化 NLG 调度解释器（引用实时结果）+ 意图驱动的 What-if 问答引擎，回答前克隆现场状态做假设推演。</div>
          <div><b style={{ color: 'var(--cyan)' }}>技术栈</b>：React 18 + TypeScript + Vite + Zustand + ECharts。无后端依赖，全链路可离线演示。</div>
        </div>
      </Panel>
    </div>
  )
}

function NumCell({ v, onChange, step = 1, min, max, w }: { v: number; onChange: (v: number) => void; step?: number; min?: number; max?: number; w?: number }) {
  return (
    <input type="number" value={v} step={step} min={min} max={max}
      style={{ width: w ?? 80 }}
      onChange={e => { const n = parseFloat(e.target.value); if (!Number.isNaN(n)) onChange(n) }} />
  )
}

function hrRanges(r: [number, number]): string { return `${r[0]}-${r[1]}` }

function parseRanges(text: string): [number, number][] | null {
  const parts = text.split(/[,，]/).map(x => x.trim()).filter(Boolean)
  const out: [number, number][] = []
  for (const p of parts) {
    const m = p.match(/^(\d{1,2})\s*-\s*(\d{1,2})$/)
    if (!m) return null
    out.push([parseInt(m[1]), parseInt(m[2])])
  }
  return out.length ? out : null
}
