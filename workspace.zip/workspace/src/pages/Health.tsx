import { useMemo } from 'react'
import { useStore, engine } from '../store'
import { Panel, EChart, CHART_BASE, C, healthColor, healthBand, statusLabel, ScoreDial } from '../components/ui'
import { healthBreakdown, dispatchCostFactor } from '../lib/health'

export default function Health() {
  const s = useStore()
  const t = useStore(x => x.tickCount)
  const rec = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current

  const hist = engine.history.slice(-720).slice(-720)

  const trendOpt = useMemo(() => ({
    ...CHART_BASE,
    legend: { ...CHART_BASE.legend, data: engine.configs.map(c => c.id) },
    xAxis: { type: 'time', ...CHART_BASE.AXIS },
    yAxis: { type: 'value', min: 30, max: 100, name: '健康度', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS },
    series: engine.configs.map((c, i) => ({
      name: c.id, type: 'line', showSymbol: false,
      data: hist.map(p => [p.t, p.health[c.id]?.toFixed(1)]),
      lineStyle: { width: 1.6, color: [C.green, C.blue, C.violet, C.cyan][i] },
    })),
  }), [t])

  const loadOpt = useMemo(() => ({
    ...CHART_BASE,
    legend: { ...CHART_BASE.legend, data: ['平均负荷率', '管网压力'] },
    xAxis: { type: 'time', ...CHART_BASE.AXIS },
    yAxis: [
      { type: 'value', min: 0, max: 1, ...CHART_BASE.AXIS, axisLabel: { ...CHART_BASE.AXIS.axisLabel, formatter: (v: number) => `${Math.round(v * 100)}%` } },
      { type: 'value', min: 6, max: 9.5, ...CHART_BASE.AXIS, splitLine: { show: false } },
    ],
    series: [
      {
        name: '平均负荷率', type: 'line', showSymbol: false, yAxisIndex: 0,
        data: hist.map(p => {
          const running = engine.configs.filter(c => (p.perLoad[c.id] ?? 0) > 0.1)
          const v = running.length ? running.reduce((sum, c) => sum + (p.perLoad[c.id] ?? 0), 0) / running.length : 0
          return [p.t, v.toFixed(3)]
        }),
        lineStyle: { color: C.cyan, width: 1.5 },
      },
      { name: '管网压力', type: 'line', showSymbol: false, yAxisIndex: 1, data: hist.map(p => [p.t, p.header.toFixed(2)]), lineStyle: { color: C.violet, width: 1.2, opacity: 0.8 } },
    ],
  }), [t])

  return (
    <div className="anim-in grid" style={{ gap: 12 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {s.machines.map(m => {
          const c = engine.configs.find(x => x.id === m.id)!
          const inPlan = rec.units.some(u => u.id === m.id)
          const loadU = rec.units.find(u => u.id === m.id)
          const hoursYear = m.hoursTotal
          return (
            <Panel key={m.id} title={c.name} right={<span className={`badge ${m.status}`}>{statusLabel(m.status)}</span>}>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <ScoreDial score={Math.round(m.health)} size={96} />
                <div style={{ flex: 1, fontSize: 12, lineHeight: 2, fontFamily: 'var(--mono)' }}>
                  <div><span style={{ color: 'var(--dim)' }}>健康区间</span> <b style={{ color: healthColor(m.health) }}>{healthBand(m.health)}</b></div>
                  <div><span style={{ color: 'var(--dim)' }}>效率系数</span> <b>{Math.round(m.efficiency * 100)}%</b></div>
                  <div><span style={{ color: 'var(--dim)' }}>排气温度</span> <b style={{ color: m.temp > 95 ? 'var(--red)' : 'inherit' }}>{Math.round(m.temp)}℃</b></div>
                  <div><span style={{ color: 'var(--dim)' }}>24h 异常</span> <b style={{ color: m.anomalies24h > 2 ? 'var(--amber)' : 'inherit' }}>{m.anomalies24h} 次</b></div>
                </div>
              </div>
              <div className="divider" />
              <div style={{ fontSize: 12, lineHeight: 2.1 }} className="num">
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>累计运行</span><span>{(hoursYear / 1000).toFixed(1)}k h</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>累计启停</span><span>{m.startsTotal} 次</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>高负荷运行(本轮)</span><span>{Math.round(m.highLoadMinutes)} min</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>本负荷 / 功率</span><span>{Math.round(m.load * 100)}% · {Math.round(m.power)}kW</span></div>
              </div>
              <div className="bar" style={{ marginTop: 8 }}>
                <i style={{ width: `${m.load * 100}%`, background: m.load > 0.9 ? 'var(--red)' : 'var(--green)' }} />
              </div>
              <div className="hint" style={{ marginTop: 8, lineHeight: 1.8 }}>
                调度映射：健康度 {Math.round(m.health)} 分 → 负荷上限 <b style={{ color: 'var(--cyan)' }}>{Math.round((m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad) * 100)}%</b>
                {inPlan ? ` · 本轮方案中分配 ${Math.round((loadU?.load ?? 0) * 100)}%` : ''}
              </div>
            </Panel>
          )
        })}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 12 }}>
        <Panel title="健康度 12 小时演变" sub="磨损随高负荷运行与启停累积，待机缓慢恢复" pad={false}>
          <EChart option={trendOpt} height={250} style={{ padding: '4px 8px 6px' }} />
        </Panel>
        <Panel title="站级负荷率与压力相关性" pad={false}>
          <EChart option={loadOpt} height={250} style={{ padding: '4px 8px 6px' }} />
        </Panel>
      </div>

      {s.maintenance.length > 0 && (
        <Panel title="维护提醒" sub="基于健康度趋势与异常实时生成" style={{ borderColor: 'rgba(246,183,60,0.45)' }}>
          <div style={{ display: 'grid', gap: 6 }}>
            {s.maintenance.map((r, i) => (
              <div key={i} className={`alert-line ${r.level === 'critical' ? 'critical' : 'warning'}`}>
                <span className={`badge ${r.level === 'critical' ? 'danger' : 'warn'}`}>{r.id}</span>
                <span style={{ flex: 1 }}>{r.message}</span>
              </div>
            ))}
          </div>
        </Panel>
      )}

      <Panel title="健康度评分模型（七维实时明细 + 调度成本系数）" sub="运行时间/启停/温度/功率/负载率/效率/异常 — 结果真实参与多机协同调度">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
          {s.machines.map((m, i) => {
            const cfg = engine.configs[i]
            const hb = healthBreakdown(cfg, m)
            const costFactor = dispatchCostFactor(m)
            const inPlan = rec.units.some(u => u.id === m.id)
            return (
              <div key={m.id} style={{ borderLeft: `3px solid ${healthColor(m.health)}`, paddingLeft: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, alignItems: 'baseline' }}>
                  <b>{m.id}</b>
                  <span className="num" style={{ color: healthColor(m.health) }}>{Math.round(m.health)} 分 · {hb.band}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10.5, marginBottom: 6 }}>
                  <span style={{ color: 'var(--dim)' }}>调度成本系数</span>
                  <b className="num" style={{ color: costFactor > 1.08 ? 'var(--red)' : costFactor > 1.02 ? 'var(--amber)' : 'var(--green)' }}>×{costFactor.toFixed(3)}</b>
                </div>
                {hb.dims.map(d => (
                  <div key={d.key} style={{ marginBottom: 5 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10.5, color: 'var(--dim)' }}>
                      <span>{d.label} <span style={{ color: 'var(--dim2)' }}>{(d.weight * 100).toFixed(0)}%</span></span>
                      <span className="num">{d.score}</span>
                    </div>
                    <div className="bar" style={{ height: 5 }}>
                      <i style={{ width: `${d.score}%`, background: d.score > 75 ? 'var(--green)' : d.score > 55 ? 'var(--amber)' : 'var(--red)' }} />
                    </div>
                  </div>
                ))}
                <div className="hint" style={{ marginTop: 4 }}>
                  {inPlan ? <span style={{ color: 'var(--cyan)' }}>本轮推荐方案中运行</span> : '本轮作为备用'}
                  {hb.advice[0] ? ` · ${hb.advice[0]}` : ''}
                </div>
              </div>
            )
          })}
        </div>
        <div className="hint" style={{ marginTop: 12 }}>
          健康度不是展示牌：七维动态合成后，低于 60 分自动降低调度负荷上限（85%），低于 40 分压到 70%；
          同时按“健康度→调度成本系数”放大其单位能耗代价（健康越差系数越高，最高约 ×1.35），使多机协同调度主动回避低健康设备的长期高负荷运行 —— 在「节能」与「护机」之间平衡（权重可在系统设置调整）。
        </div>
      </Panel>
    </div>
  )
}
