import { useState } from 'react'
import { useStore, engine } from '../store'
import { healthColor, healthBand, timeFmt } from '../components/ui'
import { explainPlan, compareVsBaseline, explainSixQuestions } from '../lib/explain'
import { baselineSeries } from '../lib/optimizer'

export default function Report() {
  const s = useStore()
  const [generated, setGenerated] = useState<{ time: number } | null>(null)
  const rec = s.result.plans.find(p => p.key === s.result.recommended) ?? s.result.current
  const ctx = s.buildCtx()
  const explain = explainPlan(rec, s.result.baseline, ctx, s.result)
  const six = explainSixQuestions(rec, s.result.baseline, ctx, s.result)
  const cmp = compareVsBaseline(rec, s.result.baseline, ctx)
  const last120 = engine.history.slice(-120)
  const bl = baselineSeries(last120.map(p => p.demand), engine.configs, engine.machines, () => ctx.priceNow, last120[0]?.t ?? 0)
  const winAiP = last120.reduce((a, p) => a + p.power, 0) / Math.max(1, last120.length)
  const winBlP = bl.power.reduce((a, b) => a + b, 0) / Math.max(1, bl.power.length)
  const winKwh = Math.max(0, winBlP - (s.adoptedKey === 'baseline' ? winBlP : winAiP)) * 2
  const dayKwh = winKwh / 120 * 1440
  const riskMachines = s.machines.filter(m => m.health < 75).sort((a, b) => a.health - b.health)
  const avgHealth = s.machines.reduce((a, m) => a + m.health, 0) / Math.max(1, s.machines.length)
  const capAll = engine.configs.reduce((a, c) => {
    const m = s.machines.find(x => x.id === c.id)
    if (!m || m.status === 'fault' || m.status === 'maintenance') return a
    const cap = m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad
    return a + c.ratedFlow * cap
  }, 0)
  const now = generated ? new Date(generated.time) : new Date(engine.simTime)
  const priceLabel = ctx.pricePeriod === 'peak' ? '峰' : ctx.pricePeriod === 'flat' ? '平' : '谷'

  return (
    <div className="anim-in" style={{ maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', gap: 10, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <button className="btn primary lg" onClick={() => setGenerated({ time: engine.simTime })}>
          {generated ? '重新生成报告（数据已刷新）' : '一键生成调度报告'}
        </button>
        {generated && <button className="btn ghost" onClick={() => window.print()}>导出 / 打印</button>}
        <span className="hint">报告字段全部由系统实时数据动态计算，生成瞬间快照；采用 AI 方案运行一段时间后生成可得到真实节费统计。</span>
      </div>

      <div className="report-print panel" style={{ padding: '26px 32px' }}>
        <div className="report-cover">
          <div style={{ fontSize: 22, fontWeight: 750, letterSpacing: 0.5 }}>AirMind 空压站智能调度运行报告</div>
          <div style={{ color: 'var(--dim)', fontSize: 12.5, marginTop: 6 }}>
            空压站多机协同智能调度智能体 · 2026 卡奥斯智能应用开发者大赛（赛题 02）· 本报告基于仿真数据生成
          </div>
          <div style={{ color: 'var(--dim)', fontSize: 12, marginTop: 4 }}>
            生成时间 {now.getFullYear()}-{pad(now.getMonth() + 1)}-{pad(now.getDate())} {pad(now.getHours())}:{pad(now.getMinutes())}
            · 数据窗口 最近 2 小时（仿真分钟级） · 调度模式 {s.adoptedKey === 'baseline' ? '传统压控（AI 顾问）' : `AI 接管（${s.adoptedKey === 'auto' ? '自动' : '锁定' + s.adoptedKey}）`}
          </div>
          <div className="report-kpis">
            <div><span>预计节能率</span><b className="num" style={{ color: 'var(--green)' }}>{Math.abs(cmp.deltaPowerPct).toFixed(1)}%</b></div>
            <div><span>小时节省</span><b className="num" style={{ color: 'var(--amber)' }}>¥{Math.max(0, cmp.saveYuanPerHour).toFixed(1)}</b></div>
            <div><span>AI 方案评分</span><b className="num" style={{ color: 'var(--cyan)' }}>{rec.totalScore}</b></div>
            <div><span>压力稳定性改善</span><b className="num" style={{ color: 'var(--cyan)' }}>{cmp.pressureImprovePct}%</b></div>
            <div><span>备用容量</span><b className="num">{rec.reserveRatio}%</b></div>
            <div><span>设备平均健康度</span><b className="num" style={{ color: healthColor(avgHealth) }}>{avgHealth.toFixed(0)}</b></div>
          </div>
        </div>

        <h3>一、当前运行状态</h3>
        <table>
          <tbody>
            <tr><th>当前用气需求</th><td>{Math.round(s.station.demand)} Nm³/h</td><th>当前供气量</th><td>{Math.round(s.station.supply)} Nm³/h</td></tr>
            <tr><th>管网压力</th><td>{s.station.header.toFixed(2)} bar（安全下限 {engine.safeMin}）</td><th>储气罐压力</th><td>{s.station.tank.toFixed(2)} bar</td></tr>
            <tr><th>总功率</th><td>{Math.round(s.station.power)} kW</td><th>当前能耗</th><td>{s.station.supply > 1 ? (s.station.power / s.station.supply).toFixed(3) : '-'} kW/(Nm³/h)</td></tr>
            <tr><th>小时电费</th><td>¥{rec.costPerHour}（{priceLabel}价 ¥{ctx.priceNow}/kWh）</td><th>运行机组</th><td>{s.machines.filter(m => m.status === 'running').map(m => m.id).join('+') || '无'}</td></tr>
          </tbody>
        </table>

        <h3>二、需求预测</h3>
        <table>
          <thead><tr><th></th><th>30 分钟</th><th>1 小时</th><th>4 小时（均值）</th><th>峰值 / 谷值</th><th>趋势</th><th>置信度</th></tr></thead>
          <tbody>
            <tr>
              <th>预测需求 Nm³/h</th>
              <td>{Math.round(s.forecast.f30)}</td><td>{Math.round(s.forecast.f60)}</td><td>{Math.round(s.forecast.f240)}</td>
              <td>{Math.round(s.forecast.peak)} / {Math.round(s.forecast.trough)}</td>
              <td>{s.forecast.trend === 'up' ? '上升' : s.forecast.trend === 'down' ? '下降' : '平稳'}（{s.forecast.trendPct >= 0 ? '+' : ''}{s.forecast.trendPct.toFixed(1)}%）</td>
              <td>{Math.round(s.forecast.confidence * 100)}%</td>
            </tr>
          </tbody>
        </table>
        {s.preDispatch && <div className="hint" style={{ marginTop: 4 }}>预测调度提示：{s.preDispatch.reason}</div>}

        <h3>三、设备健康度</h3>
        <table>
          <thead><tr><th>机组</th><th>状态</th><th>健康度</th><th>评级</th><th>温度</th><th>效率</th><th>24h异常</th><th>累计启停</th></tr></thead>
          <tbody>
            {s.machines.map(m => (
              <tr key={m.id}>
                <td><b>{m.id}</b></td>
                <td>{{ running: '运行', standby: '待机', fault: '故障', maintenance: '检修' }[m.status]}</td>
                <td className="num" style={{ color: healthColor(m.health) }}>{Math.round(m.health)}</td>
                <td>{healthBand(m.health)}</td>
                <td>{Math.round(m.temp)}℃</td>
                <td>{Math.round(m.efficiency * 100)}%</td>
                <td>{m.anomalies24h} 次</td>
                <td>{m.startsTotal}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {s.maintenance.length > 0 && (
          <ul style={{ marginTop: 6 }}>
            {s.maintenance.map((r, i) => <li key={i} className="num">{r.message}</li>)}
          </ul>
        )}

        <h3>四、当前调度方案</h3>
        <table>
          <thead><tr><th>机组组合</th><th>总功率</th><th>单位能耗</th><th>小时电费</th><th>压力σ预估</th><th>备用容量</th><th>评分</th></tr></thead>
          <tbody>
            <tr>
              <td>{s.result.current.units.map(u => `${u.id}@${Math.round(u.load * 100)}%`).join(' + ') || '—'}</td>
              <td>{s.result.current.totalPower} kW</td><td>{s.result.current.specificPower || '—'}</td>
              <td>¥{s.result.current.costPerHour}</td><td>{s.result.current.pressureStdEst} bar</td>
              <td>{s.result.current.reserveRatio}%</td><td>{s.result.current.totalScore}</td>
            </tr>
          </tbody>
        </table>

        <h3>五、AI 优化方案</h3>
        <table>
          <thead><tr><th>机组组合</th><th>总功率</th><th>单位能耗</th><th>小时电费</th><th>压力σ预估</th><th>备用容量</th><th>评分</th></tr></thead>
          <tbody>
            <tr style={{ background: 'rgba(34,211,238,0.06)' }}>
              <td><b>{rec.units.map(u => `${u.id}@${Math.round(u.load * 100)}%`).join(' + ') || '保供降级'}</b></td>
              <td><b className="num">{rec.totalPower} kW</b></td><td>{rec.specificPower}</td>
              <td>¥{rec.costPerHour}</td><td>{rec.pressureStdEst} bar</td>
              <td>{rec.reserveRatio}%</td><td><b style={{ color: 'var(--green)' }}>{rec.totalScore}</b></td>
            </tr>
          </tbody>
        </table>

        <h3>六、调度前后能耗对比</h3>
        <table>
          <thead><tr><th>方案</th><th>机组组合</th><th>总功率</th><th>单位能耗</th><th>小时电费</th><th>启停动作</th></tr></thead>
          <tbody>
            <tr><td>当前运行工况</td><td>{s.result.current.units.map(u => u.id).join('+') || '—'}</td><td>{s.result.current.totalPower} kW</td><td>{s.result.current.specificPower || '—'}</td><td>¥{s.result.current.costPerHour}</td><td>—</td></tr>
            <tr><td>传统级联基准</td><td>{s.result.baseline.units.map(u => u.id).join(' + ')}</td><td>{s.result.baseline.totalPower} kW</td><td>{s.result.baseline.specificPower}</td><td>¥{s.result.baseline.costPerHour}</td><td>频繁（估 {s.baselineMetrics.estSwitchesPerDay}/日）</td></tr>
            <tr style={{ background: 'rgba(34,211,238,0.06)' }}><td><b>AI 优化方案</b></td><td>{rec.units.map(u => u.id).join(' + ') || '保底'}</td><td><b>{rec.totalPower} kW</b></td><td>{rec.specificPower}</td><td>¥{rec.costPerHour}</td><td>{rec.startActions} 起 / {rec.stopActions} 停</td></tr>
            <tr><th>优化效果</th><td colSpan={5}>功率 {cmp.deltaPowerPct <= 0 ? '下降' : '上升'} {Math.abs(cmp.deltaPowerPct).toFixed(1)}% · 单位能耗 {cmp.deltaSpecPct <= 0 ? '下降' : '上升'} {Math.abs(cmp.deltaSpecPct).toFixed(1)}% · 小时电费 {Math.max(0, cmp.saveYuanPerHour).toFixed(1)} 元 vs 基准 {s.result.baseline.costPerHour} 元</td></tr>
          </tbody>
        </table>

        <h3>七、压力稳定性</h3>
        <table>
          <tbody>
            <tr><th>管网压力（当前）</th><td>{s.station.header.toFixed(2)} bar</td><th>安全下限</th><td>{engine.safeMin} bar</td></tr>
            <tr><th>压力波动 σ（级联 → AI）</th><td>{s.result.baseline.pressureStdEst} → {rec.pressureStdEst} bar</td><th>稳定性改善</th><td style={{ color: 'var(--cyan)' }}>{cmp.pressureImprovePct}%</td></tr>
            <tr><th>运行后管网压力预估</th><td>{rec.headerPressureEst} bar</td><th>判定</th><td>{rec.headerPressureEst > engine.safeMin + 0.2 ? '压力安全，裕度充足' : '压力偏紧，以保供优先'}</td></tr>
          </tbody>
        </table>

        <h3>八、备用容量</h3>
        <table>
          <tbody>
            <tr><th>当前方案供气裕度</th><td>{s.result.current.reserveRatio}%</td><th>AI 方案供气裕度</th><td>{rec.reserveRatio}%</td></tr>
            <tr><th>可扩备用容量</th><td style={{ color: 'var(--cyan)' }}>{Math.max(0, Math.round((capAll - s.station.demand) / Math.max(1, s.station.demand) * 100))}%（相对当前需求）</td><th>全网可调度能力</th><td>{Math.round(capAll)} Nm³/h（含健康限流）</td></tr>
            <tr><th>方案供气</th><td>{rec.totalFlow} Nm³/h</td><th>判定</th><td>{rec.reserveRatio >= 8 ? '供气裕度与可扩备用充足，可吸收常规需求波动' : '供气裕度偏低，若需求继续上涨需立即增机（可扩备用仍有余量）'}</td></tr>
          </tbody>
        </table>

        <h3>九、AI 调度原因</h3>
        <p style={{ margin: '6px 0' }}><b style={{ color: 'var(--cyan)' }}>{explain.headline}</b></p>
        <ol style={{ margin: '4px 0', paddingLeft: 20 }}>
          {explain.reasons.map((r, i) => <li key={i} style={{ color: 'var(--dim)' }}>{r}</li>)}
        </ol>
        <div className="hint" style={{ marginTop: 6 }}>系统对本次调度给出结构化六问解释：</div>
        <table>
          <tbody>
            {six.map((qa, i) => (
              <tr key={i}><th style={{ width: 190 }}>{qa.q}</th><td>{qa.a}</td></tr>
            ))}
          </tbody>
        </table>

        <h3>十、故障 / 事件记录</h3>
        {s.events.length === 0 ? (
          <div className="hint">本次运行窗口无故障或人工事件，全部由需求随机波动与班制曲线驱动。</div>
        ) : (
          <table>
            <thead><tr><th>时间</th><th>事件</th><th>说明</th></tr></thead>
            <tbody>
              {s.events.slice(0, 10).map(e => (
                <tr key={e.id}>
                  <td className="num">{timeFmt(e.t)}</td>
                  <td><span className={`badge ${e.type === 'fault' ? 'danger' : e.type === 'recover' ? 'ok' : e.type === 'tank' ? 'warn' : e.type === 'price' ? 'purple' : 'info'}`}>{e.label}</span></td>
                  <td>{e.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {s.planLog.length > 0 && (
          <>
            <div className="hint" style={{ marginTop: 8 }}>机组组合变更记录（最近）：</div>
            <table>
              <thead><tr><th>时间</th><th>触发</th><th>变更</th></tr></thead>
              <tbody>
                {s.planLog.slice(0, 8).map((l, i) => (
                  <tr key={i}><td className="num">{timeFmt(l.t)}</td><td>{l.trigger}</td><td className="num">{l.from} → {l.to}{l.scoreTo > 0 ? `（评分 ${l.scoreTo}）` : ''}</td></tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        <h3>十一、节能效果总结</h3>
        <table>
          <tbody>
            <tr><th>功率降幅</th><td style={{ color: 'var(--green)' }}>{Math.abs(cmp.deltaPowerPct).toFixed(1)}%</td><th>单位产气能耗降幅</th><td style={{ color: 'var(--green)' }}>{Math.abs(cmp.deltaSpecPct).toFixed(1)}%</td></tr>
            <tr><th>小时节省电费</th><td style={{ color: 'var(--amber)' }}>¥{Math.max(0, cmp.saveYuanPerHour).toFixed(1)}</td><th>估算日节电</th><td style={{ color: 'var(--amber)' }}>{Math.round(dayKwh)} 度/天（外推）</td></tr>
            <tr><th>会话累计节电</th><td>{s.savings.kwh.toFixed(1)} kWh</td><th>会话累计省费</th><td>¥{s.savings.yuan.toFixed(1)}</td></tr>
            <tr><th>压力稳定性提升</th><td style={{ color: 'var(--cyan)' }}>{cmp.pressureImprovePct}%</td><th>减少不必要启停</th><td>{s.adoptedKey === 'baseline' ? `预计 ${s.baselineMetrics.estSwitchesPerDay} → 近零` : `${Math.max(0, s.baselineMetrics.estSwitchesPerDay - (s.savings.aiSwitches + s.machines.length))} 次/天`}</td></tr>
          </tbody>
        </table>

        <h3>十二、风险与设备建议</h3>
        <ul>
          {riskMachines.length ? riskMachines.map(m => (
            <li key={m.id}>{m.id} 健康度 {Math.round(m.health)}（{healthBand(m.health)}）：{m.health < 40 ? '严重风险，负荷上限已压至70%，建议48小时内停机检修；' : m.health < 60 ? '风险区间，建议本周安排冷却与滤芯保养；' : '注意区间，加强振动/温度监测；'}{m.temp > 92 ? ` 当前排气温度 ${Math.round(m.temp)}℃ 偏高。` : ''}</li>
          )) : <li>四台机组健康度均在 75 分以上，无强制干预建议。</li>}
          {explain.warnings.map((w, i) => <li key={i} className="num">{w}</li>)}
          {s.result.insufficient && <li className="num">供气能力不足：缺口 {s.result.insufficient.gap} Nm³/h，需执行降级措施（恢复检修机 / 限气 / 强制启机）。</li>}
        </ul>

        <h3>十三、结论</h3>
        <p><b>
          {s.adoptedKey === 'baseline'
            ? `在需求 ${Math.round(s.station.demand)} Nm³/h、电价${priceLabel}段的当前工况下，AI 推荐「${rec.units.map(u => u.id).join('+')}」组合（评分 ${rec.totalScore}），较级联运行降低功率 ${Math.abs(cmp.deltaPowerPct).toFixed(1)}%、小时电费 ¥${Math.max(0, cmp.saveYuanPerHour).toFixed(1)}/h，压力波动预期下降 ${cmp.pressureImprovePct}%，建议尽快采纳执行。`
            : `AI 调度接管期间实测节电 ${s.savings.kwh.toFixed(1)} kWh、省费 ¥${s.savings.yuan.toFixed(1)}（会话累计）；预测驱动的预启动使组合保持在 ${rec.reserveRatio}% 备用裕度内，设备健康与能效实现双目标平衡。`}
        </b>{riskMachines.length > 0 && ` 另请关注 ${riskMachines[0].id} 的检修排期。`}</p>

        <div className="hint" style={{ marginTop: 24, textAlign: 'right' }}>
          AirMind v1.0 · 空压站多机协同智能调度智能体 · 2026 卡奥斯智能应用开发者大赛（赛题 02）· 本报告基于仿真数据生成
        </div>
      </div>
    </div>
  )
}

function pad(n: number): string { return String(n).padStart(2, '0') }
