import { ReactNode, useEffect, useMemo, useRef, useState } from 'react'
import { useStore, engine } from '../store'
import type { ChatMsg } from '../store'
import { Panel } from '../components/ui'
import { explainPlan, explainSixQuestions } from '../lib/explain'

const QUICKS = [
  '为什么现在启动A3？',
  '如果需求增加20%怎么办？',
  '哪台设备最应该优先维护？',
  '为什么不开A4？',
  '为什么推荐这个机组组合？',
  '未来1小时会不会缺气？',
  '如果A2故障怎么办？',
  '现在的方案能省多少钱？',
  '如果需求突然增加30%怎么办？',
  '哪台设备健康度最低？',
  '现在适合启动A4吗？',
  '未来6小时电价怎么走？',
]

function renderMd(text: string): ReactNode {
  const lines = text.split('\n')
  return lines.map((line, i) => {
    if (!line.trim()) return <div key={i} style={{ height: 6 }} />
    if (/^- /.test(line.trim())) {
      return <div key={i} style={{ paddingLeft: 12 }}>{inline(line.trim().slice(2))}</div>
    }
    return <div key={i}>{inline(line)}</div>
  })
}

function inline(line: string): ReactNode {
  const parts = line.split(/\*\*(.+?)\*\*/g)
  return parts.map((p, j) => (j % 2 === 1 ? <b key={j} style={{ color: '#22d3ee' }}>{p}</b> : <span key={j}>{p}</span>))
}

export default function Assistant() {
  const chat = useStore(s => s.chat)
  const send = useStore(s => s.chatSend)
  const station = useStore(s => s.station)
  const machines = useStore(s => s.machines)
  const result = useStore(s => s.result)
  const adoptedKey = useStore(s => s.adoptedKey)
  const tickCount = useStore(s => s.tickCount)
  const strategyKey = adoptedKey === 'auto' ? result.recommended : adoptedKey
  const rec = result.plans.find(p => p.key === strategyKey) ?? result.current
  const ctxNow = useMemo(() => useStore.getState().buildCtx(), [tickCount])
  const six = useMemo(() => explainSixQuestions(rec, result.baseline, ctxNow, result), [tickCount, rec])
  const expl = useMemo(() => explainPlan(rec, result.baseline, ctxNow, result), [tickCount, rec])
  const [input, setInput] = useState('')
  const [thinking, setThinking] = useState(false)
  const scroller = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: 'smooth' })
  }, [chat.length, thinking])

  const submit = (q?: string) => {
    const text = (q ?? input).trim()
    if (!text || thinking) return
    setThinking(true)
    setTimeout(() => {
      send(text)
      setInput('')
      setThinking(false)
    }, 380)
  }

  const context = useMemo(() => ({
    demand: station.demand,
    forecast30: result.plans.length ? engine.demandNow : station.demand,
    combo: rec.units.map(u => `${u.id}@${Math.round(u.load * 100)}%`).join(' + ') || '保供降级',
    power: station.power,
    header: station.header,
    tank: station.tank,
    score: rec.totalScore,
    mode: adoptedKey === 'baseline' ? '传统压控' : `AI·${adoptedKey === 'auto' ? '自动' : adoptedKey}`,
  }), [station, rec, adoptedKey])

  return (
    <div className="anim-in grid" style={{ gridTemplateColumns: '1fr 300px', gap: 12, height: 'calc(100vh - 250px)', minHeight: 560 }}>
      <Panel title="AI 调度助手" sub="回答实时引用：需求/预测/压力/机组/健康度/电价/当前方案/优化结果" pad={false}
        style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <div ref={scroller} className="chat-scroll" style={{ flex: 1, padding: '14px 14px 6px' }}>
          {chat.map((m: ChatMsg, i) => (
            <div key={i} className={`msg ${m.role}`}>{renderMd(m.text)}</div>
          ))}
          {thinking && <div className="msg ai" style={{ opacity: 0.6 }}>正在读取空压站实时数据并推理…</div>}
        </div>
        <div style={{ padding: '10px 14px 14px', borderTop: '1px solid var(--line)' }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
            {QUICKS.slice(0, 6).map(q => <div key={q} className="qcard" onClick={() => submit(q)}>{q}</div>)}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input value={input} onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && submit()}
              placeholder="向 AirMind 提问，例如：如果A3故障，还能撑住吗？" style={{ flex: 1 }} />
            <button className="btn primary" onClick={() => submit()}>发送</button>
          </div>
        </div>
      </Panel>

      <div className="grid" style={{ gap: 10, alignContent: 'start' }}>
        <Panel title="调度策略切换" sub="切换后方案与下方解释同步变化">
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            <button className={`btn ${adoptedKey === 'auto' ? 'primary' : 'ghost'}`} onClick={() => useStore.getState().adopt('auto')}>综合最优（AI自动）</button>
            <button className={`btn ${adoptedKey === 'A' ? 'primary' : 'ghost'}`} onClick={() => useStore.getState().adopt('A')}>最低能耗</button>
            <button className={`btn ${adoptedKey === 'B' ? 'primary' : 'ghost'}`} onClick={() => useStore.getState().adopt('B')}>最高稳定性</button>
          </div>
          <div className="hint" style={{ marginTop: 8 }}>当前策略：<b style={{ color: 'var(--cyan)' }}>{rec.name}</b> · 组合 {rec.units.map(u => u.id).join('+') || '保底'} · 评分 {rec.totalScore}</div>
        </Panel>

        <Panel title="调度六问（当前策略实时解释）">
          <div style={{ display: 'grid', gap: 7, maxHeight: 300, overflowY: 'auto', paddingRight: 4 }}>
            <div style={{ fontSize: 12, color: 'var(--cyan)', fontWeight: 600 }}>{expl.headline}</div>
            {six.map((qa, i) => (
              <div key={i} style={{ fontSize: 11.8, lineHeight: 1.7, paddingBottom: 6, borderBottom: '1px solid rgba(56,189,248,0.07)' }}>
                <div style={{ color: 'var(--amber)' }}>{qa.q}</div>
                <div style={{ color: 'var(--dim)' }}>{qa.a}</div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="助手当前引用的实时上下文">
          <div className="num" style={{ fontSize: 12, lineHeight: 2 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>调度模式</span><b style={{ color: 'var(--cyan)' }}>{context.mode}</b></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>当前需求</span><b>{Math.round(context.demand)} Nm³/h</b></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>推荐组合</span><b>{context.combo}</b></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>总功率</span><b>{Math.round(context.power)} kW</b></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>管网 / 罐压</span><b>{context.header.toFixed(2)} / {context.tank.toFixed(2)}</b></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>方案评分</span><b style={{ color: 'var(--green)' }}>{context.score}</b></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--dim)' }}>机组状态</span><b>{machines.map(m => `${m.id}${m.status === 'running' ? '运行' : m.status === 'fault' ? '故障' : m.status === 'maintenance' ? '检修' : '待机'}`).join(' · ')}</b></div>
          </div>
        </Panel>
        <Panel title="全部快捷提问">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            {QUICKS.map(q => <div key={q} className="qcard" onClick={() => submit(q)}>{q}</div>)}
          </div>
        </Panel>
        <Panel title="能力说明">
          <ul className="hint" style={{ margin: 0, paddingLeft: 16, lineHeight: 2 }}>
            <li>调度解释：任意方案的组合理由、负荷分配依据</li>
            <li>What-if 推演：模拟故障/冲击后的重调度结果（不破坏现场）</li>
            <li>保供评估：缺口、触限时间、恢复措施</li>
            <li>经济测算：实时电费、节能收益、年化外推</li>
            <li>设备顾问：健康度、启停保护、检修建议</li>
          </ul>
        </Panel>
      </div>
    </div>
  )
}
