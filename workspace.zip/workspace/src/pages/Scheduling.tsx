import { useMemo, useState } from 'react'
import type { SchedulePlan } from '../lib/types'
import { useStore, engine } from '../store'
import { Panel, KPI, EChart, CHART_BASE, C, timeFmt, ScoreDial, RadarScores } from '../components/ui'
import { explainPlan, compareVsBaseline, explainSixQuestions } from '../lib/explain'
import { baselineSeries, rankMachinesForPlan } from '../lib/optimizer'
import type { MachineEval } from '../lib/optimizer'

export default function Scheduling() {
  const s = useStore()
  const [tab, setTab] = useState<'plans' | 'compare' | 'explain' | 'constraints'>('plans')
  const strategyKey = s.adoptedKey === 'auto' ? s.result.recommended : s.adoptedKey
  const rec = s.result.plans.find(p => p.key === strategyKey) ?? s.result.current
  const explain = useMemo(() => explainPlan(rec, s.result.baseline, s.buildCtx(), s.result), [s.tickCount, rec])
  const six = useMemo(() => explainSixQuestions(rec, s.result.baseline, s.buildCtx(), s.result), [s.tickCount, rec])
  const cmp = compareVsBaseline(rec, s.result.baseline, s.buildCtx())
  const recent = engine.history.slice(-90)
  const blF = baselineSeries(recent.map(p => p.demand), engine.configs, engine.machines, () => 1, recent[0]?.t ?? 0)

  const constraintRows = useMemo(() => {
    if (!rec) return []
    const capOk = rec.totalFlow >= s.station.demand
    const rows: { name: string; ok: boolean | 'warn'; detail: string }[] = [
      { name: '总供气能力 ≥ 预测需求', ok: capOk, detail: `${rec.totalFlow.toFixed(0)} ≥ ${Math.max(s.station.demand, s.forecast.f30).toFixed(0)} Nm³/h（含30min预测）` },
      { name: `管网压力 ≥ 安全下限 ${engine.safeMin} bar`, ok: s.station.header >= engine.safeMin + 0.35 ? true : s.station.header >= engine.safeMin ? 'warn' : false, detail: `当前 ${s.station.header.toFixed(2)} bar，方案预估 ${rec.headerPressureEst} bar` },
      { name: '单台负荷不超设备上限', ok: rec.units.every(u => { const c = engine.configs.find(x => x.id === u.id)!; const m = s.machines.find(x => x.id === u.id)!; const capH = m.health < 40 ? 0.7 : m.health < 60 ? 0.85 : c.maxLoad; return u.load <= capH + 0.001 }), detail: rec.units.map(u => `${u.id} ${Math.round(u.load * 100)}%`).join(' · ') },
      { name: '故障/检修设备不参与调度', ok: s.machines.every(m => (m.status === 'fault' || m.status === 'maintenance') ? !rec.units.some(u => u.id === m.id) : true), detail: s.machines.filter(m => m.status === 'fault' || m.status === 'maintenance').map(m => `${m.id}(${m.status === 'fault' ? '故障' : '检修'})`).join(' / ') || '无故障检修设备' },
      { name: '严重风险设备限制高负荷', ok: rec.units.every(u => { const m = s.machines.find(x => x.id === u.id)!; return !(m.health < 40 && u.load > 0.71) }), detail: s.machines.filter(m => m.health < 40).length ? '低健康度机组负荷上限 70%' : '暂无进入严重区间的机组' },
      { name: '最小启停时间约束', ok: (() => { const stops = s.machines.filter(m => m.status === 'running' && !rec.units.some(u => u.id === m.id)); return stops.every(m => m.runMinutes >= engine.configs.find(c => c.id === m.id)!.minRunTime) })(), detail: (() => {
        const lockout = s.machines.filter(m => m.status === 'standby' && m.stopMinutes < engine.configs.find(c => c.id === m.id)!.minStopTime)
        return lockout.length ? `${lockout.map(m => `${m.id}(剩${Math.round(engine.configs.find(c => c.id === m.id)!.minStopTime - m.stopMinutes)}min)`).join(' · ')} 保护期禁启` : '无机组处于启停保护冲突'
      })() },
      { name: '保留合理备用容量', ok: rec.reserveRatio >= 8 ? true : 'warn', detail: `备用容量 ${rec.reserveRatio}%（建议 ≥8%）` },
      { name: '未来需求保障（4h）', ok: rec.supplyCapacity >= s.forecast.f240 * 0.9, detail: `方案能力 ${rec.supplyCapacity.toFixed(0)} vs 4h预测峰值 ${s.forecast.peak.toFixed(0)} Nm³/h` },
    ]
    return rows
  }, [rec, s.tickCount])

  const trendOpt = useMemo(() => {
    const t0 = recent[0]?.t ?? Date.now()
    void t0
    const aiMode = s.adoptedKey !== 'baseline'
    return {
      ...CHART_BASE,
      legend: { ...CHART_BASE.legend, data: ['级联基准功率', aiMode ? 'AI 方案功率（实时）' : '实际功率（压控级联）', '用气需求'] },
      xAxis: { type: 'time', ...CHART_BASE.AXIS, axisLabel: { ...CHART_BASE.AXIS.axisLabel, formatter: (v: number) => timeFmt(v) } },
      yAxis: [{ type: 'value', name: 'kW', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS }, { type: 'value', name: 'Nm³/h', nameTextStyle: { color: '#7d92ab', fontSize: 10 }, ...CHART_BASE.AXIS, splitLine: { show: false } }],
      series: [
        { name: '级联基准功率', type: 'line', showSymbol: false, data: recent.map((p, i) => [p.t, blF.power[i]?.toFixed(0)]), lineStyle: { color: C.base, type: 'dashed', width: 1.4 } },
        { name: aiMode ? 'AI 方案功率（实时）' : '实际功率（压控级联）', type: 'line', showSymbol: false, data: recent.map(p => [p.t, p.power.toFixed(0)]), lineStyle: { color: aiMode ? C.green : C.demand, width: 2 } },
        { name: '用气需求', type: 'line', yAxisIndex: 1, showSymbol: false, data: recent.map(p => [p.t, p.demand.toFixed(0)]), lineStyle: { color: C.blue, width: 1.2, opacity: 0.7 } },
      ],
    }
  }, [s.tickCount, rec, s.adoptedKey])

  const barOpt = useMemo(() => {
    const items = [
      { name: '总功率 kW', base: s.result.baseline.totalPower, ai: rec.totalPower },
      { name: '单位能耗', base: +(s.result.baseline.specificPower * 1000).toFixed(0), ai: +(rec.specificPower * 1000).toFixed(0) },
      { name: '小时电费 ¥', base: s.result.baseline.costPerHour, ai: rec.costPerHour },
      { name: '压力波动σ×100', base: +(s.result.baseline.pressureStdEst * 100).toFixed(1), ai: +(rec.pressureStdEst * 100).toFixed(1) },
      { name: '日启停次数', base: s.baselineMetrics.estSwitchesPerDay, ai: s.savings.aiSwitches + s.machines.length },
    ]
    return {
      ...CHART_BASE,
      legend: { ...CHART_BASE.legend, data: ['AI 优化前', 'AI 优化后'] },
      tooltip: { ...CHART_BASE.tooltip, formatter: (ps: { dataIndex: number; name: string; value: number[]; seriesName: string }[]) => {
        const p = ps[0]
        return `${p.name}<br/>${ps.map(x => `${x.seriesName}: ${x.value}`).join('<br/>')}`
      } },
      xAxis: { type: 'category', data: items.map(i => i.name), ...CHART_BASE.AXIS },
      yAxis: { type: 'value', ...CHART_BASE.AXIS },
      series: [
        { name: 'AI 优化前', type: 'bar', barWidth: 16, itemStyle: { color: 'rgba(125,146,171,0.5)' }, data: items.map(i => i.base) },
        { name: 'AI 优化后', type: 'bar', barWidth: 16, itemStyle: { color: C.cyan }, data: items.map(i => i.ai) },
      ],
    }
  }, [s.tickCount, rec])

  const planCard = (key: 'A' | 'B' | 'C') => {
    const p = s.result.plans.find(x => x.key === key)
    if (!p) return null
    const isRec = s.result.recommended === key
    const isSel = s.adoptedKey === key || (s.adoptedKey === 'auto' && isRec)
    return (
      <div key={key} className={`panel plan-card ${isSel ? 'sel' : ''}`} onClick={() => useStore.getState().adopt(key)}>
        <div className="panel-h">
          <span>{p.name}{isRec && <span className="badge purple" style={{ marginLeft: 8 }}>推荐</span>}</span>
          <span className="sub">{isSel ? '执行中' : '点击采用'}</span>
        </div>
        <div className="panel-b">
          <div style={{ display: 'flex', gap: 12 }}>
            <ScoreDial score={p.totalScore} size={86} />
            <div style={{ flex: 1, fontSize: 12 }}>
              <div className="hint" style={{ marginBottom: 6 }}>{p.objective}</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 7 }}>
                {p.units.map(u => <span key={u.id} className={`badge ${u.load >= p.units[0]?.load ? 'running' : 'running'}`}>{u.id} @ {Math.round(u.load * 100)}%</span>)}
              </div>
              <table style={{ fontSize: 11.5, width: '100%' }} className="num">
                <tbody>
                  <tr><td style={{ color: 'var(--dim)' }}>总功率 / 电费</td><td className="num" style={{ textAlign: 'right' }}>{p.totalPower} kW · ¥{p.costPerHour}/h</td></tr>
                  <tr><td style={{ color: 'var(--dim)' }}>供气 / 备用</td><td>{p.totalFlow} · 备用{p.reserveRatio}%</td></tr>
                  <tr><td style={{ color: 'var(--dim)' }}>启停动作</td><td>{p.startActions} 起 / {p.stopActions} 停</td></tr>
                  <tr><td style={{ color: 'var(--dim)' }}>评分对比推荐</td><td style={{ color: p.totalScore >= rec.totalScore ? 'var(--green)' : 'var(--dim)' }}>{(p.totalScore - rec.totalScore >= 0 ? '+' : '')}{(p.totalScore - rec.totalScore).toFixed(1)} 分</td></tr>
                </tbody>
              </table>
            </div>
            <RadarScores scores={p.scores} />
          </div>
          {p.notes.length > 0 && <div className="hint" style={{ marginTop: 8, borderTop: '1px solid var(--line)', paddingTop: 7 }}>
            {p.notes.map((n, i) => <div key={i}>· {n}</div>)}
          </div>}
        </div>
      </div>
    )
  }

  return (
    <div className="anim-in">
      {s.result.insufficient && (
        <Panel style={{ marginBottom: 12, borderColor: 'rgba(244,88,106,0.5)' }}>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <span className="badge danger" style={{ fontSize: 13, animation: 'blink 1s infinite' }}>供气能力不足</span>
            <div style={{ flex: 1 }}>
              <div>缺口 <b className="num" style={{ color: 'var(--red)' }}>{s.result.insufficient.gap} Nm³/h</b>，罐压预计 <b className="num">{s.result.insufficient.minutesToLimit}</b> 分钟后跌破安全下限</div>
              {s.result.insufficient.measures.map((m, i) => <div key={i} className="hint">推荐措施{i + 1}：{m}</div>)}
            </div>
          </div>
        </Panel>
      )}

      <div className="tabbar">
        {[['plans', '组合方案对比'], ['explain', 'AI 调度解释'], ['compare', '优化前后对比'], ['constraints', '约束与校验']].map(([k, l]) => (
          <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k as typeof tab)}>{l}</button>
        ))}
      </div>

      {tab === 'plans' && (
        <>
          {s.result.pressureBoost?.pct > 0.001 && (
            <div className="alert-line warning" style={{ marginBottom: 10 }}>
              <span style={{ color: 'var(--amber)' }}>⚡ 压力联动</span>
              <span style={{ flex: 1 }}>{s.result.pressureBoost.reason}：调度目标产气量已自动上浮 <b className="num">+{Math.round(s.result.pressureBoost.pct * 100)}%</b>，优先保住管网压力安全带</span>
            </div>
          )}
          <BeforeAfterBar rec={rec} />
          <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center' }}>
            <span className="hint">当前执行模式：</span>
            <button className={`btn ghost ${s.adoptedKey === 'auto' ? '' : ''}`} onClick={() => useStore.getState().adopt('auto')} style={s.adoptedKey === 'auto' ? { borderColor: 'var(--cyan)', color: 'var(--cyan)' } : {}}>AI 自动跟随推荐</button>
            <button className="btn ghost" onClick={() => useStore.getState().adopt('A')} style={s.adoptedKey === 'A' ? { borderColor: 'var(--cyan)', color: 'var(--cyan)' } : {}}>锁定方案A</button>
            <button className="btn ghost" onClick={() => useStore.getState().adopt('B')} style={s.adoptedKey === 'B' ? { borderColor: 'var(--cyan)', color: 'var(--cyan)' } : {}}>锁定方案B</button>
            <button className="btn ghost" onClick={() => useStore.getState().adopt('C')} style={s.adoptedKey === 'C' ? { borderColor: 'var(--cyan)', color: 'var(--cyan)' } : {}}>锁定方案C</button>
            <button className="btn amber" onClick={() => useStore.getState().adopt('baseline')} style={s.adoptedKey === 'baseline' ? { borderColor: 'var(--amber)', color: 'var(--amber)' } : {}}>回退传统压控</button>
            <span className="hint" style={{ marginLeft: 'auto' }}>调度每 tick（{Math.round(1050 / s.speed)}ms = 仿真 1 分钟）自动重算：需求 · 预测 · 健康度 · 电价 · 事件全部联动</span>
          </div>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {planCard('A')}
            {planCard('B')}
            {planCard('C')}
          </div>
          <div className="grid" style={{ gridTemplateColumns: '1.55fr 1fr', gap: 12, marginTop: 12 }}>
            <Panel title="功率与需求走势（基准 vs AI）" pad={false}>
              <EChart option={trendOpt} height={238} style={{ padding: '4px 8px 8px' }} />
            </Panel>
            <MachineDecision plan={rec} />
          </div>
        </>
      )}

      {tab === 'explain' && (
        <>
        <div className="hint" style={{ marginBottom: 8 }}>当前解释对应策略：<b style={{ color: 'var(--cyan)' }}>{rec.name}</b>（{s.adoptedKey === 'auto' ? 'AI 自动跟随综合最优' : `已锁定方案 ${s.adoptedKey}`}）。在上方「组合方案对比」切换方案后，此处解释与六问同步更新。</div>
        <div className="grid" style={{ gridTemplateColumns: '1.4fr 1fr', gap: 12 }}>
          <Panel title={`AI 调度解释 · ${rec.name}`} sub="以下所有数字均取自当前系统实时计算">
            <div style={{ fontSize: 13, lineHeight: 1.9 }}>
              <div style={{ color: 'var(--cyan)', fontWeight: 700, marginBottom: 6 }}>{explain.headline}</div>
              {explain.body.map((b, i) => <p key={i} style={{ margin: '6px 0' }}>{b}</p>)}
              <div className="divider" />
              <div className="section-title">调度原因</div>
              <ol style={{ margin: 0, paddingLeft: 18, lineHeight: 2, color: 'var(--dim)' }}>
                {explain.reasons.map((r, i) => <li key={i}>{r}</li>)}
              </ol>
              <div className="divider" />
              <div className="section-title">调度六问（当前策略「{rec.name.split('·')[0].trim()}」，数据实时生成）</div>
              <div style={{ display: 'grid', gap: 8 }}>
                {six.map((qa, i) => (
                  <div key={i} style={{ padding: '8px 12px', background: 'var(--panel2)', border: '1px solid var(--line)', borderRadius: 8 }}>
                    <div style={{ color: 'var(--cyan)', fontWeight: 600, fontSize: 12.5 }}>{i + 1}. {qa.q}</div>
                    <div style={{ marginTop: 4, fontSize: 12.5, lineHeight: 1.75 }}>{qa.a}</div>
                  </div>
                ))}
              </div>
            </div>
          </Panel>
          <div className="grid" style={{ gap: 12, alignContent: 'start' }}>
            <Panel title="风险提示">
              {explain.warnings.length ? explain.warnings.map((w, i) => (
                <div key={i} style={{ padding: '7px 10px', marginBottom: 6, border: '1px solid rgba(246,183,60,0.35)', borderRadius: 7, fontSize: 12, color: 'var(--amber)' }}>⚠ {w}</div>
              )) : <span className="hint">本方案无显著风险，压力/健康/备用指标均在安全带内。</span>}
            </Panel>
            <Panel title="方案构成明细">
              <table className="dt">
                <thead><tr><th>机组</th><th>负荷</th><th>流量</th><th>功率</th><th>健康度</th></tr></thead>
                <tbody>
                  {rec.units.map(u => {
                    const m = s.machines.find(x => x.id === u.id)!
                    return (
                      <tr key={u.id}>
                        <td className="num"><b>{u.id}</b></td>
                        <td className="num">{Math.round(u.load * 100)}%</td>
                        <td className="num">{u.flow} Nm³/h</td>
                        <td className="num">{u.power} kW</td>
                        <td className="num" style={{ color: m.health >= 75 ? 'var(--green)' : m.health >= 60 ? 'var(--amber)' : 'var(--red)' }}>{Math.round(m.health)}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
              {rec.units.length === 0 && <span className="hint">无可用机组组合（全部处于保护/故障），触发保供降级。</span>}
            </Panel>
            <Panel title="负荷分配甘特">
              <div style={{ fontFamily: 'var(--mono)', fontSize: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
                {rec.units.map(u => (
                  <div key={u.id}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}><span>{u.id}</span><span className="num">{u.flow} / {engine.configs.find(c => c.id === u.id)?.ratedFlow} Nm³/h</span></div>
                    <div className="bar"><i style={{ width: `${u.load * 100}%`, background: u.load > 0.9 ? 'var(--red)' : u.load > 0.7 ? 'var(--green)' : 'var(--cyan)' }} /></div>
                  </div>
                ))}
              </div>
            </Panel>
          </div>
        </div>
        </>
      )}

      {tab === 'compare' && (
        <div className="grid" style={{ gap: 12 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            <KPI label="节能率（较级联基准）" value={`${Math.abs(cmp.deltaPowerPct).toFixed(1)}`} unit="%" delta={`${cmp.baselinePower} → ${cmp.planPower} kW`} deltaCls="up" accent="ok" />
            <KPI label="单位产气能耗下降" value={`${Math.abs(cmp.deltaSpecPct).toFixed(1)}`} unit="%" delta={`${s.result.baseline.specificPower} → ${rec.specificPower} kW/(Nm³/h)`} deltaCls="up" />
            <KPI label="预计节省电费" value={`${cmp.saveYuanPerHour > 0 ? cmp.saveYuanPerHour.toFixed(1) : '0'}`} unit="¥/h" delta={`¥${s.result.baseline.costPerHour} → ¥${rec.costPerHour}/h（当前${s.pricePeriod === 'peak' ? '峰' : s.pricePeriod === 'flat' ? '平' : '谷'}价）`} deltaCls="up" />
            <KPI label="压力波动改善" value={`${cmp.pressureImprovePct}`} unit="%" delta={`σ ${s.result.baseline.pressureStdEst} → ${rec.pressureStdEst} bar`} deltaCls="up" />
            <KPI label="启停优化" value={`${Math.max(0, s.baselineMetrics.estSwitchesPerDay - (s.savings.aiSwitches + s.machines.length))}`} unit="次/天" delta={`级联 ${s.baselineMetrics.estSwitchesPerDay} → AI 接管 ${s.savings.aiSwitches}（本会话）`} deltaCls="up" />
            <KPI label="高风险运行时长" value={rec.units.filter(u => { const m = s.machines.find(x => x.id === u.id)!; return m.health < 60 && u.load > 0.75 }).length === 0 ? '0' : '>0'} unit="h"
              delta="低健康度机组高负荷暴露（方案已按约束压缩其负荷）" deltaCls="up" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: 12 }}>
            <Panel title="AI优化前 vs AI优化后" pad={false}>
              <EChart option={barOpt} height={280} style={{ padding: '6px 8px 10px' }} />
            </Panel>
            <Panel title="对比明细">
              <table className="dt">
                <thead><tr><th>指标</th><th>级联基准</th><th>AI 方案</th><th>变化</th></tr></thead>
                <tbody className="num">
                  {[
                    ['总功率 (kW)', s.result.baseline.totalPower.toFixed(0), rec.totalPower.toFixed(0), `${cmp.deltaPowerPct}%`],
                    ['总流量 (Nm³/h)', s.station.demand.toFixed(0), rec.totalFlow.toFixed(0), '+'],
                    ['单位能耗 (kW/Nm³)', s.result.baseline.specificPower.toFixed(3), rec.specificPower.toFixed(3), `${cmp.deltaSpecPct}%`],
                    ['压力波动σ (bar)', s.result.baseline.pressureStdEst.toFixed(2), rec.pressureStdEst.toFixed(2), `-${cmp.pressureImprovePct}%`],
                    ['日启停 (次)', s.baselineMetrics.estSwitchesPerDay, s.machines.length + s.savings.aiSwitches, '减少'],
                    ['高风险运行 (台次)', '难以约束', rec.infeasibleHealthUnits.length ? rec.infeasibleHealthUnits.join('') : '0', '已保护'],
                    ['小时电费 (¥)', s.result.baseline.costPerHour.toFixed(1), rec.costPerHour.toFixed(1), cmp.saveYuanPerHour > 0 ? `-${cmp.saveYuanPerHour.toFixed(1)}` : '+'],
                    ['备用容量 (%)', '12~45 波动', `${rec.reserveRatio}`, '稳定'],
                  ].map((r, i) => (
                    <tr key={i}><td style={{ color: 'var(--dim)' }}>{r[0]}</td><td>{r[1]}</td><td style={{ color: 'var(--cyan)' }}>{r[2]}</td><td style={{ color: 'var(--green)' }}>{r[3]}</td></tr>
                  ))}
                </tbody>
              </table>
              <div className="hint" style={{ margin: '10px 0' }}>基准 = 定频机组「压力带启停 + 满载/空载」运行模型的动态推演：需求决定开机台数，余量放空载/启停消化 —— 这是未装 AI 调度空压站的典型能效水平。</div>
              <div style={{ textAlign: 'right' }}>
                <button className="btn primary" onClick={() => useStore.getState().adopt('auto')}>采用综合最优，开始累计真实节能</button>
              </div>
            </Panel>
          </div>
        </div>
      )}

      {tab === 'constraints' && (
        <div className="grid" style={{ gridTemplateColumns: '1.2fr 1fr', gap: 12 }}>
          <Panel title="调度硬/软约束校验">
            <table className="dt">
              <thead><tr><th>约束项</th><th>状态</th><th>数据详情（实时）</th></tr></thead>
              <tbody>
                {constraintRows.map((r, i) => (
                  <tr key={i}>
                    <td>{r.name}</td>
                    <td>{r.ok === true ? <span className="badge ok">满足</span> : r.ok === 'warn' ? <span className="badge warn">关注</span> : <span className="badge danger">违反</span>}</td>
                    <td style={{ color: 'var(--dim)' }}>{r.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Panel>
          <div className="grid" style={{ gap: 12, alignContent: 'start' }}>
            <Panel title="机组启停台账">
              <table className="dt">
                <thead><tr><th>机组</th><th>连续运行</th><th>连续停机</th><th>最小约束</th><th>启停成本</th></tr></thead>
                <tbody className="num">
                  {s.machines.map(m => {
                    const c = engine.configs.find(x => x.id === m.id)!
                    return (
                      <tr key={m.id}>
                        <td><b>{m.id}</b> <span className={`badge ${m.status}`} style={{ marginLeft: 4, fontSize: 10 }}>{m.status === 'running' ? 'run' : m.status === 'standby' ? 'idle' : m.status}</span></td>
                        <td>{Math.round(m.runMinutes)} min</td>
                        <td>{Math.round(m.stopMinutes)} min</td>
                        <td style={{ color: 'var(--dim)' }}>run≥{c.minRunTime} / stop≥{c.minStopTime}</td>
                        <td>¥{c.startCost}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </Panel>
            <Panel title="调度决策日志">
              <div style={{ maxHeight: 220, overflowY: 'auto' }}>
                {s.planLog.length === 0 && <span className="hint">暂无组合变更，AI 保持工况稳定（这本身就是最优：启停次数最少）。</span>}
                {s.planLog.map((l, i) => (
                  <div key={i} style={{ padding: '6px 0', borderBottom: '1px solid rgba(56,189,248,0.06)', fontSize: 12 }}>
                    <span className="num" style={{ color: 'var(--dim2)' }}>{timeFmt(l.t)}</span>{' '}
                    {l.trigger}：<b className="num">{l.from}</b> → <b className="num" style={{ color: 'var(--cyan)' }}>{l.to}</b>
                    {l.scoreTo > 0 && <span className="num" style={{ color: 'var(--dim)' }}>（评分 {l.scoreTo}）</span>}
                  </div>
                ))}
              </div>
            </Panel>
          </div>
        </div>
      )}
    </div>
  )
}

function MachineDecision({ plan }: { plan: SchedulePlan }) {
  const s = useStore()
  void s.tickCount
  const evals: MachineEval[] = useMemo(() => rankMachinesForPlan(s.buildCtx(), plan), [s.tickCount, plan])
  const decLabel: Record<string, [string, string]> = { run: ['投入运行', 'running'], stop: ['计划停机', 'maintenance'], standby: ['备用待机', 'standby'], blocked: ['硬约束隔离', 'fault'] }
  return (
    <Panel title="机组 8 因子决策评估" sub={`需求 ${Math.round(s.station.demand)}→目标 ${plan.totalFlow} Nm³/h · 逐台评估依据实时数据`}>
      <table className="dt num" style={{ fontSize: 11.5 }}>
        <thead>
          <tr><th>机组</th><th>额定</th><th>实测→计划</th><th>预计流量</th><th>预计功率</th><th>单位能耗</th><th>健康</th><th>决策</th></tr>
        </thead>
        <tbody>
          {evals.map(e => (
            <tr key={e.id}>
              <td><b style={{ color: e.decision === 'run' ? 'var(--green)' : e.decision === 'blocked' ? 'var(--red)' : e.decision === 'stop' ? 'var(--amber)' : 'var(--dim)' }}>{e.id}</b></td>
              <td style={{ color: 'var(--dim)' }}>{e.ratedFlow}</td>
              <td>{e.currentLoad}%<span style={{ color: 'var(--dim2)' }}>→</span><b>{e.decision === 'run' ? `${e.planLoad}%` : '—'}</b>
                {e.decision === 'run' && Math.abs(e.ramp) > 0.1 && <span className="badge info" style={{ marginLeft: 4, fontSize: 9.5 }}>±{e.ramp}%</span>}</td>
              <td>{e.targetFlow || 0}</td>
              <td>{e.targetPower || 0}</td>
              <td style={{ color: e.specificPower > 0 && e.specificPower <= plan.specificPower ? 'var(--green)' : 'var(--dim)' }}>{e.specificPower.toFixed(3) || e.hypotheticalSpec.toFixed(3)}</td>
              <td style={{ color: e.health >= 75 ? 'var(--green)' : e.health >= 60 ? 'var(--amber)' : 'var(--red)' }}>{e.health}</td>
              <td><span className={`badge ${decLabel[e.decision][1]}`}>{decLabel[e.decision][0]}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="divider" />
      <div className="hint" style={{ lineHeight: 1.9, fontSize: 11.5 }}>
        {evals.filter(e => e.decision === 'run').slice(0, 3).map(e => (
          <div key={e.id}><b style={{ color: 'var(--green)' }}>{e.id} 入选</b> · {e.reasons[0]}</div>
        ))}
        {evals.filter(e => e.decision === 'standby').slice(0, 2).map(e => (
          <div key={e.id}><b style={{ color: 'var(--dim)' }}>{e.id} 待机原因</b> · {e.reasons[0]}</div>
        ))}
        {evals.filter(e => e.decision === 'stop').slice(0, 2).map(e => (
          <div key={e.id}><b style={{ color: 'var(--amber)' }}>{e.id} 停机收益</b> · {e.reasons[0]}</div>
        ))}
      </div>
    </Panel>
  )
}

function BeforeAfterBar({ rec }: { rec: SchedulePlan }) {
  const s = useStore()
  const cur = s.result.current
  const converged = s.adoptedKey !== 'baseline'
  const dP = cur.totalPower - rec.totalPower
  const dCost = cur.costPerHour - rec.costPerHour
  const dStd = cur.pressureStdEst - rec.pressureStdEst
  const dSpec = cur.specificPower - rec.specificPower
  const cells: { label: string; before: string; after: string; delta: string; good: boolean | null }[] = [
    { label: '总功率', before: `${cur.totalPower} kW`, after: `${rec.totalPower} kW`, delta: `${dP >= 0 ? '▼' : '▲'} ${Math.abs(dP).toFixed(1)} kW`, good: dP >= 0 },
    { label: '单位能耗', before: `${(cur.specificPower || 0).toFixed(3)}`, after: `${rec.specificPower.toFixed(3)}`, delta: `${dSpec >= 0 ? '▼' : '▲'} ${Math.abs(dSpec).toFixed(3)}`, good: dSpec >= 0 },
    { label: '小时电费', before: `¥${cur.costPerHour}`, after: `¥${rec.costPerHour}`, delta: `${dCost >= 0 ? '-' : '+'}¥${Math.abs(dCost).toFixed(1)}`, good: dCost >= 0 },
    { label: '压力波动σ', before: `${cur.pressureStdEst} bar`, after: `${rec.pressureStdEst} bar`, delta: `${dStd >= 0 ? '▼' : '▲'} ${Math.abs(dStd).toFixed(3)}`, good: dStd >= 0 },
    { label: '备用容量', before: `${cur.reserveRatio}%`, after: `${rec.reserveRatio}%`, delta: `${rec.reserveRatio - cur.reserveRatio >= 0 ? '+' : ''}${(rec.reserveRatio - cur.reserveRatio).toFixed(1)}pt`, good: rec.reserveRatio >= cur.reserveRatio },
    { label: '综合评分', before: `${cur.totalScore}`, after: `${rec.totalScore}`, delta: `+${Math.max(0, rec.totalScore - cur.totalScore).toFixed(1)}`, good: rec.totalScore >= cur.totalScore },
    { label: '运行设备数', before: `${cur.units.length} 台`, after: `${rec.units.length} 台`, delta: `${rec.units.length - cur.units.length >= 0 ? '+' : ''}${rec.units.length - cur.units.length} 台`, good: rec.units.length <= cur.units.length },
  ]
  return (
    <div className="panel" style={{ padding: '10px 14px', marginBottom: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
        <b style={{ fontSize: 13 }}>调度前 → 调度后（推荐方案「{rec.units.map(u => u.id).join(' + ') || '保供降级'}」）</b>
        <span className="hint" style={{ flex: 1 }}>
          {converged
            ? 'AI 已接管：现场正按方案负荷执行，前后差值收敛中；下方数值为当前实况 vs 方案目标。'
            : '当前为传统压控运行：下方为「实况基线 vs 采用推荐方案后」的对比预估，点击任一方案卡片即可切换。'}
        </span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
        {cells.map(c => (
          <div key={c.label} style={{ background: 'var(--panel2)', border: '1px solid var(--line)', borderRadius: 8, padding: '8px 10px' }}>
            <div className="hint" style={{ fontSize: 10.5 }}>{c.label}</div>
            <div className="num" style={{ marginTop: 3, fontSize: 12 }}>
              <span style={{ color: 'var(--dim)' }}>{c.before}</span>
              <span style={{ margin: '0 5px', color: 'var(--dim2)' }}>→</span>
              <span style={{ color: 'var(--cyan)' }}>{c.after}</span>
            </div>
            <div className={`num delta ${c.good === null ? 'flatx' : c.good ? 'up' : 'down'}`} style={{ fontSize: 11 }}>{c.delta}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
