import { useMemo } from 'react'
import { useStore } from '../store'
import { Panel, KPI, timeFmt } from '../components/ui'
import { explainReschedule } from '../lib/explain'

interface EventPreset {
  key: string
  label: string
  ico: string
  desc: string
  cls: string
  run: () => void
}

export default function Events() {
  const s = useStore()
  const tickCount = useStore(x => x.tickCount)
  void tickCount
  const pres: EventPreset[] = [
    { key: 'f1', label: 'A1 故障', ico: '✕', desc: '小型机退出（若运行中影响基载）', cls: 'btn danger', run: () => useStore.getState().toggleFault('A1') },
    { key: 'f2', label: 'A2 故障', ico: '✕', desc: '中等机组退出：典型演示场景，观察组合切换', cls: 'btn danger', run: () => useStore.getState().toggleFault('A2') },
    { key: 'f3', label: 'A3 故障', ico: '✕', desc: '主力机组退出：触发最大能力组合（含 A4）', cls: 'btn danger', run: () => useStore.getState().toggleFault('A3') },
    { key: 'f4', label: 'A4 故障', ico: '✕', desc: '最大机组退出：低谷时段影响小，高峰考验组合', cls: 'btn danger', run: () => useStore.getState().toggleFault('A4') },
    { key: 'd20', label: '用气需求 +20%', ico: '▲', desc: '模拟产线提速/新设备投运：触发预测上修与提前启机', cls: 'btn ghost', run: () => useStore.getState().injectDemandShock(20, 22, '用气需求 +20%') },
    { key: 'd40', label: '用气需求 +40%', ico: '⏩', desc: '突发大负荷冲击：检验备用容量与压力防线', cls: 'btn ghost', run: () => useStore.getState().injectDemandShock(40, 25, '用气需求 +40%') },
    { key: 'tank', label: '储气罐压力下降', ico: '▽', desc: '下游泄漏：罐压瞬时 -0.75 bar，AI 切快速补压模式', cls: 'btn amber', run: () => useStore.getState().triggerTankDrop() },
    { key: 'price', label: '电价进入峰段', ico: '¥', desc: '高价时段：调度目标自动转向抑制高价电消耗', cls: 'btn amber', run: () => useStore.getState().triggerForcePeak() },
  ]

  const strategyKey = s.adoptedKey === 'auto' ? s.result.recommended : s.adoptedKey
  const rec = s.result.plans.find(p => p.key === strategyKey) ?? s.result.current
  const ctx = useMemo(() => useStore.getState().buildCtx(), [tickCount])
  const snap = s.lastEventSnapshot
  const expl = useMemo(() => (snap ? explainReschedule(snap, rec, ctx, s.result) : null), [snap, rec, ctx, s.result])

  const eventFlow = snap ? [
    { k: '事件发生', v: `${snap.label} @ ${timeFmt(snap.t)}（触发前组合 ${snap.combo}，功率 ${snap.power} kW）`, ok: true },
    { k: 'AI 检测', v: `读取现场状态：罐压 ${s.station.tank.toFixed(2)} bar、需求 ${Math.round(s.station.demand)} Nm³/h，识别受影响机组与供需偏移`, ok: true },
    { k: '自动重新优化', v: `多机协同调度算法即时重算：组合 ${snap.combo} → ${rec.units.map(u => u.id).join('+') || '保供降级'}`, ok: true },
    { k: '生成新调度方案', v: `总功率 ${snap.power} → ${rec.totalPower} kW · 供气 ${snap.flow} → ${rec.totalFlow} Nm³/h · 评分 ${rec.totalScore}`, ok: rec.feasible },
    { k: '风险分析', v: s.result.insufficient ? `供气缺口 ${s.result.insufficient.gap} Nm³/h（约 ${s.result.insufficient.minutesToLimit} min 触限）` : rec.reserveRatio < 8 ? '备用容量偏低，二次事件风险' : '压力/备用/健康均在安全带', ok: !s.result.insufficient },
    { k: 'AI 解释', v: expl?.headline ?? '', ok: true },
  ] : []

  const isolated = s.machines.filter(m => m.status === 'fault' || m.status === 'maintenance')
  const stillUsed = isolated.filter(m => rec.units.some(u => u.id === m.id))

  return (
    <div className="anim-in grid" style={{ gap: 12 }}>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(8, 1fr)', gap: 10 }}>
        {pres.map(p => (
          <div key={p.key} className="panel" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}><span style={{ marginRight: 6, color: 'var(--cyan)' }}>{p.ico}</span>{p.label}</div>
            <div className="hint" style={{ lineHeight: 1.6, flex: 1 }}>{p.desc}</div>
            <button className={p.cls} onClick={p.run}>注入事件</button>
          </div>
        ))}
      </div>

      <div className="hint" style={{ marginTop: -4 }}>
        点击任一事件后：修改状态 → <b style={{ color: 'var(--cyan)' }}>立即重算</b>空压站状态 → 调用多机协同调度 → 生成新组合 → 对比前后 → AI 解释。
        <button className="btn ghost" style={{ padding: '2px 10px', fontSize: 11, marginLeft: 8 }} onClick={() => useStore.getState().rescheduleNow()}>手动触发即时重算</button>
      </div>

      {s.result.insufficient && (
        <Panel style={{ borderColor: 'rgba(244,88,106,0.5)' }}>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <span className="badge danger" style={{ fontSize: 13, animation: 'blink 1s infinite' }}>供气能力不足风险</span>
            <div style={{ flex: 1, fontSize: 12.5, lineHeight: 1.9 }}>
              缺口 <b className="num" style={{ color: 'var(--red)' }}>{s.result.insufficient.gap} Nm³/h</b>，罐压约 <b className="num">{s.result.insufficient.minutesToLimit}</b> 分钟后跌破安全下限 {ctx.safeMin} bar。<br />
              解决方案：{s.result.insufficient.measures.join('；')}
            </div>
          </div>
        </Panel>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Panel title="AI 自动重调度解释" sub={snap ? `事件「${snap.label}」` : '尚未注入事件'}>
          {expl ? (
            <div style={{ fontSize: 13, lineHeight: 1.9 }}>
              <div style={{ color: 'var(--cyan)', fontWeight: 700, marginBottom: 6 }}>{expl.headline}</div>
              {expl.body.map((b, i) => <p key={i} style={{ margin: '5px 0', color: 'var(--dim)' }}>{b}</p>)}
              <div className="divider" />
              <div className="section-title">为什么需要重新调度</div>
              <ol style={{ margin: 0, paddingLeft: 18, lineHeight: 2, color: 'var(--dim)' }}>
                {expl.reasons.map((r, i) => <li key={i}>{r}</li>)}
              </ol>
              {expl.risk && (
                <div style={{ marginTop: 8, padding: '8px 12px', border: '1px solid rgba(246,183,60,0.4)', borderRadius: 8, color: 'var(--amber)', fontSize: 12.5 }}>
                  ⚠ {expl.risk}
                </div>
              )}
            </div>
          ) : (
            <div className="hint" style={{ padding: '40px 12px', textAlign: 'center', lineHeight: 2 }}>
              尚未注入事件。<br />推荐演示链路：先到驾驶舱「采用 AI 方案」→ 回到本页依次点击「A2 故障」→ 观察自动识别、即时重算、新组合与 AI 解释。
            </div>
          )}
        </Panel>

        <Panel title="事件前后调度对比" sub="压力 / 流量 / 功率 / 能耗 / 备用容量">
          {expl ? (
            <>
              <table className="dt">
                <thead><tr><th>指标</th><th>事件前</th><th>事件后（新方案）</th><th>变化</th></tr></thead>
                <tbody className="num">
                  {expl.changes.map((c, i) => (
                    <tr key={i}>
                      <td style={{ color: 'var(--dim)' }}>{c.metric}</td>
                      <td>{c.before}</td>
                      <td style={{ color: 'var(--cyan)' }}>{c.after}</td>
                      <td style={{ color: c.good ? 'var(--green)' : 'var(--amber)' }}>{c.delta || (c.good ? '✓' : '!')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="divider" />
              <div className="section-title">故障/检修设备隔离校验</div>
              {isolated.length === 0 ? (
                <div className="hint">当前无故障或检修设备。</div>
              ) : (
                <div style={{ display: 'grid', gap: 6 }}>
                  {isolated.map(m => {
                    const used = stillUsed.some(x => x.id === m.id)
                    return (
                      <div key={m.id} className="alert-line" style={{ alignItems: 'center' }}>
                        <span className={`badge ${m.status === 'fault' ? 'danger' : 'maintenance'}`}>{m.id} {m.status === 'fault' ? '故障' : '检修'}</span>
                        <span style={{ flex: 1, fontSize: 12 }}>{used ? '异常：仍在方案中（不应发生）' : '硬约束生效：调度算法已排除，不参与任何机组组合'}</span>
                        <span className={`badge ${used ? 'danger' : 'ok'}`}>{used ? '未隔离' : '已隔离'}</span>
                      </div>
                    )
                  })}
                </div>
              )}
            </>
          ) : (
            <div className="hint" style={{ padding: '40px 12px', textAlign: 'center' }}>注入事件后，此处展示事件前/后全指标对比与故障设备隔离状态。</div>
          )}
        </Panel>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <Panel title="事件响应流程（最近一次注入）" sub="事件 → 检测 → 重算 → 新方案 → 风险 → 解释">
          {snap ? (
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {eventFlow.map((f, i) => (
                <div key={f.k} style={{ display: 'flex', gap: 12 }}>
                  <div style={{ width: 22, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <div style={{ width: 12, height: 12, borderRadius: '50%', border: `2px solid ${f.ok ? 'var(--green)' : 'var(--amber)'}`, background: 'var(--panel)' }} />
                    {i < eventFlow.length - 1 && <div style={{ width: 2, flex: 1, background: 'rgba(56,189,248,0.15)', minHeight: 26 }} />}
                  </div>
                  <div style={{ paddingBottom: 14 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: i === 0 ? 'var(--red)' : 'var(--cyan)' }}>{f.k}</div>
                    <div style={{ fontSize: 12, color: 'var(--dim)', marginTop: 2 }}>{f.v}</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="hint" style={{ padding: '46px 12px', textAlign: 'center' }}>
              尚未注入事件。<br />每个事件都会留下对比快照：事件前的组合 / 功率 / 流量 / 压力 / 备用。
            </div>
          )}
          {snap && (
            <div style={{ marginTop: 8, display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
              <KPI label="事件前功率" value={<span className="num">{snap.power}<small>kW</small></span>} />
              <KPI label="新方案功率" value={<span className="num" style={{ color: 'var(--cyan)' }}>{rec.totalPower}<small>kW</small></span>} />
              <KPI label="事件前备用" value={<span className="num">{snap.reserve}<small>%</small></span>} delta={`现 ${rec.reserveRatio}%`} deltaCls="up" />
              <KPI label="新方案评分" value={<span className="num" style={{ color: 'var(--green)' }}>{rec.totalScore}</span>} delta={`事件前 ${snap.score}`} deltaCls="flatx" />
            </div>
          )}
        </Panel>

        <Panel title="事件时间线" right={<button className="btn ghost" onClick={() => useStore.getState().clearEvents()}>清除冲击</button>}>
          <div style={{ maxHeight: 420, overflowY: 'auto', paddingRight: 4 }}>
            {s.events.length === 0 && <div className="hint">无模拟事件。当前运行全部由基线 + 需求随机波动构成（数据本身含 AR1 噪声、班制曲线与偶发尖峰）。</div>}
            {s.events.map(e => (
              <div key={e.id} className="alert-line" style={{ marginBottom: 6 }} data-type={e.type}>
                <span className={`badge ${e.type === 'fault' ? 'danger' : e.type === 'recover' ? 'ok' : e.type === 'tank' ? 'warn' : e.type === 'price' ? 'purple' : 'info'}`}>{e.label}</span>
                <span style={{ flex: 1 }}>{e.detail}</span>
                <span className="t">{timeFmt(e.t)}</span>
              </div>
            ))}
            <div className="divider" />
            <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6, color: 'var(--dim)' }}>系统告警</div>
            {s.alerts.length === 0 && <div className="hint">暂无活动告警 ✓</div>}
            {s.alerts.map(a => (
              <div key={a.id} className={`alert-line ${a.level}`} style={{ marginBottom: 6 }}>
                <span style={{ color: a.level === 'critical' ? 'var(--red)' : a.level === 'warning' ? 'var(--amber)' : 'var(--cyan)' }}>●</span>
                <span style={{ flex: 1 }}>{a.message}</span>
                <span className="t">{timeFmt(a.t)}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  )
}
