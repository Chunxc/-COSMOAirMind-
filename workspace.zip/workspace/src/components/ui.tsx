import { useEffect, useRef } from 'react'
import * as echartsCore from 'echarts/core'
import { BarChart, LineChart } from 'echarts/charts'
import { GridComponent, LegendComponent, MarkLineComponent, TooltipComponent, DataZoomComponent, MarkAreaComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
echartsCore.use([BarChart, LineChart, GridComponent, LegendComponent, MarkLineComponent, TooltipComponent, DataZoomComponent, MarkAreaComponent, CanvasRenderer])

import type { DemoSummary } from '../store'

export function Panel({ title, sub, right, children, pad = true, style }: {
  title?: React.ReactNode; sub?: React.ReactNode; right?: React.ReactNode;
  children: React.ReactNode; pad?: boolean; style?: React.CSSProperties
}) {
  return (
    <div className="panel" style={style}>
      {(title || right) && (
        <div className="panel-h">
          <span>{title}{sub && <span className="sub" style={{ marginLeft: 8 }}>{sub}</span>}</span>
          <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>{right}</span>
        </div>
      )}
      <div className={pad ? 'panel-b' : ''} style={pad ? undefined : { padding: 0 }}>{children}</div>
    </div>
  )
}

export function KPI({ label, value, unit, delta, deltaCls, accent }: {
  label: React.ReactNode; value: React.ReactNode; unit?: string
  delta?: React.ReactNode; deltaCls?: string; accent?: string
}) {
  return (
    <div className="panel kpi">
      <div className="label">{label}{accent && <span className={`badge ${accent}`} style={{ marginLeft: 'auto' }}>{accent === 'ok' ? '正常' : accent === 'warn' ? '关注' : accent === 'danger' ? '风险' : ''}</span>}</div>
      <div className="value" style={accent === 'danger' ? { color: 'var(--red)' } : undefined}>{value}{unit && <small>{unit}</small>}</div>
      {delta && <div className={`delta ${deltaCls ?? 'flatx'}`}>{delta}</div>}
    </div>
  )
}

const AXIS = {
  axisLine: { lineStyle: { color: 'rgba(125,146,171,0.25)' } },
  axisLabel: { color: '#7d92ab', fontSize: 10.5, fontFamily: 'JetBrains Mono, Consolas, monospace' },
  splitLine: { lineStyle: { color: 'rgba(56,189,248,0.07)' } },
}

export const CHART_BASE = {
  AXIS,
  grid: { left: 46, right: 16, top: 30, bottom: 26, containLabel: false },
  tooltip: {
    trigger: 'axis',
    backgroundColor: 'rgba(10,21,38,0.95)',
    borderColor: 'rgba(34,211,238,0.35)',
    textStyle: { color: '#d9e5f2', fontSize: 12 },
  },
  legend: { textStyle: { color: '#7d92ab', fontSize: 11 }, itemWidth: 12, itemHeight: 8, top: 2 },
} as const

export const C = {
  demand: '#f6b73c', supply: '#2dd4a0', header: '#22d3ee', tank: '#9d7cf5',
  power: '#4a9eff', base: '#7d92ab', ai: '#2dd4a0', band: 'rgba(74,158,255,0.14)',
  red: '#f4586a', amber: '#f6b73c', violet: '#9d7cf5', cyan: '#22d3ee', green: '#2dd4a0', blue: '#4a9eff',
}

export function timeFmt(ms: number): string {
  const d = new Date(ms)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

export function EChart({ option, height = 220, style }: { option: Record<string, unknown>; height?: number; style?: React.CSSProperties }) {
  const ref = useRef<HTMLDivElement>(null)
  const chart = useRef<ReturnType<typeof echartsCore.init> | null>(null)
  useEffect(() => {
    if (!ref.current) return
    chart.current = echartsCore.init(ref.current, undefined, { renderer: 'canvas' })
    const onResize = () => chart.current?.resize()
    window.addEventListener('resize', onResize)
    const ro = new ResizeObserver(onResize)
    ro.observe(ref.current)
    return () => { window.removeEventListener('resize', onResize); ro.disconnect(); chart.current?.dispose() }
  }, [])
  useEffect(() => {
    chart.current?.setOption(option as never, true)
  }, [option])
  return <div ref={ref} style={{ height, width: '100%', ...style }} />
}

export function healthColor(h: number): string {
  return h >= 90 ? 'var(--green)' : h >= 75 ? '#8ee6c0' : h >= 60 ? 'var(--amber)' : h >= 40 ? '#f08a5f' : 'var(--red)'
}

export function healthBand(h: number): string {
  return h >= 90 ? '优秀' : h >= 75 ? '良好' : h >= 60 ? '注意' : h >= 40 ? '风险' : '严重风险'
}

export function statusLabel(s: string): string {
  return { running: '运行中', standby: '待机', fault: '故障停机', maintenance: '检修中' }[s] ?? s
}

export function statusBadgeClass(s: string): string {
  return s
}

export const statusColor: Record<string, string> = {
  running: 'var(--green)', standby: 'var(--dim)', fault: 'var(--red)', maintenance: 'var(--amber)',
}

export function ScoreDial({ score, size = 92 }: { score: number; size?: number }) {
  const color = score >= 90 ? 'var(--green)' : score >= 75 ? 'var(--cyan)' : score >= 60 ? 'var(--amber)' : 'var(--red)'
  const r = size / 2 - 7
  const circ = 2 * Math.PI * r
  return (
    <div style={{ width: size, height: size, position: 'relative', flex: '0 0 auto' }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(125,146,171,0.18)" strokeWidth={6} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={6}
          strokeDasharray={`${(score / 100) * circ} ${circ}`} strokeLinecap="round"
          style={{ transition: 'stroke-dasharray 0.6s ease' }} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div className="num" style={{ fontSize: size / 3.6, fontWeight: 700, color }}>{score}</div>
          <div style={{ fontSize: 10, color: 'var(--dim)' }}>综合评分</div>
        </div>
      </div>
    </div>
  )
}

export function RadarScores({ scores }: { scores: { energy: number; stability: number; cycling: number; health: number; reserve: number; efficiency: number } }) {
  const labels = ['能耗', '稳定性', '启停', '健康', '备用', '效率']
  const vals = [scores.energy, scores.stability, scores.cycling, scores.health, scores.reserve, scores.efficiency]
  const cx = 70, cy = 66, r = 46
  const pt = (i: number, v: number) => {
    const a = Math.PI / 3 * i - Math.PI / 2
    return `${cx + Math.cos(a) * r * (v / 100)},${cy + Math.sin(a) * r * (v / 100)}`
  }
  const gridPt = (scale: number) => Array.from({ length: 6 }, (_, i) => {
    const a = Math.PI / 3 * i - Math.PI / 2
    return `${cx + Math.cos(a) * r * scale},${cy + Math.sin(a) * r * scale}`
  }).join(' ')
  return (
    <svg width="140" height="128" style={{ display: 'block' }}>
      {[0.33, 0.66, 1].map(s => <polygon key={s} points={gridPt(s)} fill="none" stroke="rgba(56,189,248,0.12)" />)}
      {Array.from({ length: 6 }, (_, i) => {
        const a = Math.PI / 3 * i - Math.PI / 2
        return <line key={i} x1={cx} y1={cy} x2={cx + Math.cos(a) * r} y2={cy + Math.sin(a) * r} stroke="rgba(56,189,248,0.1)" />
      })}
      <polygon points={vals.map((v, i) => pt(i, v)).join(' ')} fill="rgba(34,211,238,0.22)" stroke="var(--cyan)" strokeWidth={1.5} />
      {labels.map((l, i) => {
        const a = Math.PI / 3 * i - Math.PI / 2
        return <text key={l} x={cx + Math.cos(a) * (r + 11)} y={cy + Math.sin(a) * (r + 11) + 3} textAnchor="middle" fontSize={9.5} fill="#7d92ab">{l}</text>
      })}
    </svg>
  )
}

export function DemoSummaryModal({ summary, onClose }: { summary: DemoSummary; onClose: () => void }) {
  return (
    <div className="modal-mask" onClick={onClose}>
      <div className="modal anim-in" onClick={e => e.stopPropagation()} style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>3 分钟演示完成</div>
        <div className="hint" style={{ marginBottom: 16 }}>本次智能调度全过程动态计算结果：</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 16 }}>
          <div className="panel kpi"><div className="label">节电量</div><div className="value" style={{ color: 'var(--cyan)' }}>{summary.kwh}<small>kWh</small></div></div>
          <div className="panel kpi"><div className="label">节约电费</div><div className="value" style={{ color: 'var(--green)' }}>¥{summary.yuan}</div></div>
          <div className="panel kpi"><div className="label">压力稳定性提升</div><div className="value" style={{ color: 'var(--amber)' }}>{summary.pressureImprovePct}<small>%</small></div></div>
          <div className="panel kpi"><div className="label">减少不必要启停</div><div className="value" style={{ color: 'var(--violet)' }}>{summary.switchCuts}<small>次</small></div></div>
        </div>
        <div className="hint" style={{ textAlign: 'left', background: 'rgba(10,21,34,0.7)', border: '1px solid var(--line)', borderRadius: 8, padding: '10px 14px', lineHeight: 2 }}>
          <div>本次演示覆盖 {summary.windowMin} 分钟运行窗口（AI 接管 {summary.windowMin} 分钟）</div>
          <div>AI 模式平均功率 <b className="num" style={{ color: 'var(--green)' }}>{summary.avgPowerAi} kW</b> vs 级联基准 <b className="num">{summary.avgPowerBase} kW</b>，降幅 <b className="num" style={{ color: 'var(--cyan)' }}>{summary.avgPowerBase > 0 ? Math.max(0, Math.round((1 - summary.avgPowerAi / summary.avgPowerBase) * 1000) / 10) : 0}%</b></div>
          <div>管网压力波动 σ：基准 {summary.baseStd} bar → AI {summary.aiStd} bar，末端产线供气更平稳</div>
        </div>
        <div style={{ marginTop: 16 }}>
          <button className="btn primary lg" onClick={onClose}>完成演示，回到驾驶舱</button>
        </div>
      </div>
    </div>
  )
}

export function MiniBar({ value, max, color }: { value: number; max: number; color: string }) {
  return (
    <div className="bar" style={{ minWidth: 60 }}>
      <i style={{ width: `${Math.min(100, value / max * 100)}%`, background: color }} />
    </div>
  )
}
