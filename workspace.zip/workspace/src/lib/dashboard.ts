// 驾驶舱“供气紧张”判定：阈值与原因的单一事实来源（页面与测试共用，保证展示一致）
export interface LiveFlagsInput {
  header: number
  safeMin: number
  gap: number
  capReserve: number
  supplyMargin: number
  lowHealth: string[]
}

export interface LiveFlags {
  reasons: string[]
  tense: boolean
  critical: boolean
}

export const TENSE_THRESHOLDS = {
  headerWarnGap: 0.4,
  capReserveMin: 5,
  supplyMarginMin: 8,
}

export function liveDispatchFlags(i: LiveFlagsInput): LiveFlags {
  const reasons: string[] = []
  if (i.header < i.safeMin) reasons.push(`管网压力 ${i.header.toFixed(2)} bar 低于安全下限 ${i.safeMin} bar`)
  else if (i.header < i.safeMin + TENSE_THRESHOLDS.headerWarnGap) reasons.push(`管网压力 ${i.header.toFixed(2)} bar 接近安全下限`)
  if (i.gap > 0) reasons.push(`供气缺口 ${i.gap} Nm³/h，需立即增机`)
  else if (i.capReserve < TENSE_THRESHOLDS.capReserveMin) reasons.push(`可扩备用容量仅 ${i.capReserve.toFixed(1)}%，接近安全阈值`)
  else if (i.supplyMargin < TENSE_THRESHOLDS.supplyMarginMin) reasons.push(`供气裕度仅 ${i.supplyMargin}%，接近安全阈值`)
  if (i.lowHealth.length) reasons.push(`${i.lowHealth.join('、')} 健康度低于 40，已限负荷保护`)
  const critical = i.header < i.safeMin || i.gap > 0
  return { reasons, tense: reasons.length > 0, critical }
}
