import type { CompressorConfig, MachineState, SeriesPoint, PriceConfig } from './types'
import { machinePower, machineFlow, efficiencyFromHealth } from './params'

const DEMAND_TABLE: [number, number][] = [
  [0, 330], [4.5, 320], [6.5, 470], [8, 800], [10, 880], [11.8, 900],
  [12.3, 560], [13.3, 620], [14, 900], [17, 870], [18.2, 690], [19.5, 550],
  [21.5, 410], [23, 360], [24, 340],
]

function segInterp(x: number): number {
  for (let i = 1; i < DEMAND_TABLE.length; i++) {
    const [h1, v1] = DEMAND_TABLE[i]
    if (x <= h1) {
      const [h0, v0] = DEMAND_TABLE[i - 1]
      const u = (x - h0) / (h1 - h0)
      const s = u * u * (3 - 2 * u)
      return v0 + (v1 - v0) * s
    }
  }
  return DEMAND_TABLE[DEMAND_TABLE.length - 1][1]
}

function gauss(): number {
  let u = 0, v = 0
  while (u === 0) u = Math.random()
  while (v === 0) v = Math.random()
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v)
}

const AMBIENT = 24

export interface EngineInit {
  configs: CompressorConfig[]
  price: PriceConfig
  tankVolume: number
  bandLow: number
  bandHigh: number
  safeMin: number
  headerOffset: number
  startHour?: number
}

export interface TickInput {
  mode: 'baseline' | 'ai'
  planTargets: Record<string, number>
  tankSetpoint: number
  demandShock: number
  hourOffset: number
  demandOverride?: number | null
}

interface SpikeState {
  active: boolean
  minsLeft: number
  amp: number
}

export class SimEngine {
  configs: CompressorConfig[]
  cfgOf: Record<string, CompressorConfig>
  machines: MachineState[] = []
  history: SeriesPoint[] = []
  tank = 8.0
  header = 7.6
  demandNow = 700
  arNoise = 0
  arBias = 0
  spike: SpikeState = { active: false, minsLeft: 0, amp: 0 }
  simTime = 0
  price: PriceConfig
  tankVolume: number
  bandLow: number
  bandHigh: number
  safeMin: number
  headerOffset: number
  lastStartOrder: string[] = []
  rolling: Record<string, { temp: number[]; spec: number[] }> = {}
  anomalyCooldown: Record<string, number> = {}
  anomalyCounts: Record<string, number> = {}
  healthInit: Record<string, number> = {}
  faultsActive: Record<string, boolean> = {}

  constructor(init: EngineInit, startMs: number) {
    this.configs = init.configs
    this.cfgOf = Object.fromEntries(init.configs.map(c => [c.id, c]))
    this.price = init.price
    this.tankVolume = init.tankVolume
    this.bandLow = init.bandLow
    this.bandHigh = init.bandHigh
    this.safeMin = init.safeMin
    this.headerOffset = init.headerOffset
    this.simTime = startMs
    for (const c of init.configs) {
      this.rolling[c.id] = { temp: [], spec: [] }
      this.anomalyCooldown[c.id] = 0
      this.anomalyCounts[c.id] = 0
    }
  }

  seedHealth: Record<string, number> = { A1: 86, A2: 61, A3: 82, A4: 93 }
  seedHours: Record<string, number> = { A1: 12400, A2: 31600, A3: 21500, A4: 8900 }
  seedStarts: Record<string, number> = { A1: 2100, A2: 5300, A3: 3900, A4: 2400 }

  initMachines() {
    this.machines = this.configs.map(c => {
      const health = this.seedHealth[c.id] ?? 85
      this.healthInit[c.id] = health
      return {
        id: c.id, status: 'standby' as const, loaded: false, load: 0, flow: 0, power: 0,
        temp: AMBIENT + 2, runMinutes: 0, stopMinutes: 20,
        hoursTotal: this.seedHours[c.id] ?? 10000, startsTotal: this.seedStarts[c.id] ?? 2000,
        health, efficiency: efficiencyFromHealth(c.baseEff, health), anomalies24h: 0,
        highLoadMinutes: 30 + Math.random() * 60, noloadStreak: 0,
      }
    })
  }

  demandAt(ms: number): number {
    const d = new Date(ms)
    const hour = d.getHours() + d.getMinutes() / 60
    const days = Math.floor(ms / 86400000)
    const weekly = Math.sin(days * 0.9) * 25
    return segInterp(hour) + weekly
  }

  private nextDemand(shock: number, hourOffset: number): number {
    const base = this.demandAt(this.simTime + hourOffset * 3600000)
    if (this.spike.active) {
      this.spike.minsLeft -= 1
      if (this.spike.minsLeft <= 0) this.spike.active = false
    } else if (Math.random() < 0.006) {
      this.spike = { active: true, minsLeft: 6 + Math.floor(Math.random() * 12), amp: (Math.random() > 0.3 ? 1 : -1) * (90 + Math.random() * 160) }
    }
    this.arNoise = 0.93 * this.arNoise + gauss() * 11
    this.arBias = 0.995 * this.arBias + gauss() * 2.2
    const spikeVal = this.spike.active ? this.spike.amp : 0
    const v = (base + this.arNoise + this.arBias + spikeVal * Math.min(1, this.spike.minsLeft / 3)) * (1 + shock)
    return Math.max(150, Math.min(2600, v))
  }

  private updateMachinePhysics(m: MachineState, q: number, dtMin: number) {
    const c = this.cfgOf[m.id]
    const running = m.status === 'running'
    const fault = this.faultsActive[m.id]
    const tempTarget = running
      ? AMBIENT + 66 * (m.loaded ? 1 : 0.2) * (0.92 + (100 - m.health) / 220 + (1 - m.efficiency) * 1.2) + (fault ? 22 : 0)
      : AMBIENT + (fault ? 30 : 1)
    m.temp += (tempTarget - m.temp) / 6 * dtMin
    m.temp = Math.max(AMBIENT - 1, Math.min(135, m.temp))
    if (running) {
      m.hoursTotal += dtMin / 60
      m.runMinutes += dtMin
      m.stopMinutes = 0
      if (m.loaded) {
        m.highLoadMinutes += dtMin
        m.health -= 0.0018 * q * dtMin
      } else {
        m.health -= 0.0008 * dtMin
      }
    } else {
      m.stopMinutes += dtMin
      m.runMinutes = 0
      m.health = Math.min(99, m.health + 0.006 * dtMin)
    }
    if (m.temp > 95) m.health -= 0.004 * (m.temp - 95) * dtMin
    if (fault) m.health -= 0.5 * dtMin
    m.health = Math.max(fault ? 0 : 1, Math.min(99.5, m.health))
    m.efficiency = efficiencyFromHealth(c.baseEff, fault ? 40 : m.health)
    m.load = m.loaded ? 1 : (running ? 0.02 : 0)
    m.flow = machineFlow(c, m.loaded ? 1 : 0)
    m.power = running ? machinePower(c, m.loaded ? 1 : 0, m.efficiency) : 0
  }

  private startMachine(m: MachineState) {
    if (m.status !== 'standby') return
    m.status = 'running'; m.loaded = true; m.load = 1
    m.startsTotal += 1
    m.health -= 0.12
    m.noloadStreak = 0
    m.runMinutes = 0
  }

  private stopMachine(m: MachineState) {
    if (m.status !== 'running') return
    m.status = 'standby'; m.loaded = false; m.load = 0; m.flow = 0; m.power = 0
    m.stopMinutes = 0
    m.noloadStreak = 0
  }

  baselineControl(demand: number) {
    const order = [...this.configs].sort((a, b) => a.cascadeOrder - b.cascadeOrder)
    let supply = this.machines.filter(m => m.loaded).reduce((s, m) => s + this.cfgOf[m.id].ratedFlow, 0)
    const tankRising = this.tank >= this.bandHigh - 0.08
    const tankFalling = this.tank <= this.bandLow + 0.08 || this.header <= this.safeMin + 0.25
    if (tankFalling && (supply < demand * 1.02 || this.tank <= this.safeMin + 0.4)) {
      const idleUnloaded = this.machines.filter(m => m.status === 'running' && !m.loaded)
      if (idleUnloaded.length) {
        const best = idleUnloaded.sort((a, b) => this.cfgOf[b.id].ratedFlow - this.cfgOf[a.id].ratedFlow)[0]
        best.loaded = true; best.noloadStreak = 0
      } else {
        const cand = order.map(c => this.machines.find(m => m.id === c.id)!)
          .filter(m => m.status === 'standby' && m.stopMinutes >= 5)
        for (const m of cand) {
          const capAfter = supply + this.cfgOf[m.id].ratedFlow
          if (capAfter > demand * 1.85) continue
          this.startMachine(m); supply = this.machines.filter(x => x.loaded).reduce((s, x) => s + this.cfgOf[x.id].ratedFlow, 0); break
        }
      }
    } else if (tankRising) {
      const loadedList = this.machines.filter(m => m.loaded && m.status === 'running')
        .sort((a, b) => this.cfgOf[b.id].ratedFlow - this.cfgOf[a.id].ratedFlow)
      const big = loadedList[0]
      if (big && big.runMinutes > 10) {
        big.loaded = false; big.noloadStreak = 0
      }
    }
    if (this.tank >= 9.6) {
      const loadedList = this.machines.filter(m => m.loaded && m.status === 'running')
        .sort((a, b) => this.cfgOf[b.id].ratedFlow - this.cfgOf[a.id].ratedFlow)
      if (loadedList.length > 1) { loadedList[0].loaded = false; loadedList[0].noloadStreak = 0 }
      else if (loadedList.length === 1) { loadedList[0].loaded = false; loadedList[0].noloadStreak = 0 }
    }
    for (const m of this.machines) {
      if (m.status === 'running' && !m.loaded) {
        m.noloadStreak += 1
        if (m.noloadStreak > 13 && m.runMinutes > m.noloadStreak && supply - this.cfgOf[m.id].ratedFlow >= demand * 0.98 && m.stopMinutes >= 0) {
          this.stopMachine(m)
          supply -= this.cfgOf[m.id].ratedFlow
        }
      }
    }
  }

  applyPlan(targets: Record<string, number>, setpoint: number, supplyGapAdj: number) {
    for (const m of this.machines) {
      const t = targets[m.id]
      const shouldRun = t !== undefined
      if (m.status === 'fault' || m.status === 'maintenance') continue
      if (shouldRun && m.status === 'standby') {
        this.startMachine(m)
      } else if (!shouldRun && m.status === 'running') {
        this.stopMachine(m)
      }
    }
    const sumT = Object.entries(targets).reduce((s, [id, v]) => {
      const cc = this.cfgOf[id]
      if (!cc) return s
      return s + cc.ratedFlow * Math.min(cc.maxLoad, Math.max(cc.minLoad, v))
    }, 0)
    const demandCap = this.demandNow * 1.02 + 40
    const ratio = sumT > demandCap ? demandCap / sumT : 1
    const PI_BAND = (supplyGapAdj !== undefined ? supplyGapAdj : 0)
    const pi = Math.max(-0.12, Math.min(0.15, (setpoint - this.tank) * 0.13 + PI_BAND))
    const pend: { m: MachineState; load: number; flexibleFlow: number }[] = []
    let proj = 0
    for (const m of this.machines) {
      if (m.status !== 'running') continue
      const c = this.cfgOf[m.id]
      const tRaw = targets[m.id]
      if (tRaw === undefined) { m.loaded = false; m.load = 0.02; m.flow = 0; m.power = machinePower(c, 0, m.efficiency); continue }
      const t = Math.max(0, Math.min(c.maxLoad, tRaw))
      m.loaded = t > 0.05
      const load = m.loaded ? Math.max(c.minLoad, Math.min(c.maxLoad, t * ratio * (1 + pi))) : 0.02
      const fl = machineFlow(c, load)
      proj += fl
      pend.push({ m, load, flexibleFlow: Math.max(0, (load - c.minLoad) * c.ratedFlow) })
    }
    const envelope = this.demandNow * 1.05 + 20
    proj = pend.reduce((s, x) => s + machineFlow(this.cfgOf[x.m.id], x.load), 0)
    if (proj > envelope && pend.length) {
      const flexTotal = pend.reduce((s, x) => s + x.flexibleFlow, 0)
      const shrink = flexTotal > 0 ? Math.min(1, (proj - envelope) / flexTotal) : 0
      for (const x of pend) {
        const c = this.cfgOf[x.m.id]
        const load = Math.max(c.minLoad, x.load - (x.load - c.minLoad) * shrink)
        x.m.load = load
        x.m.flow = machineFlow(c, load)
        x.m.power = machinePower(c, load, x.m.efficiency)
      }
      const stillOver = pend.reduce((s, x) => s + x.m.flow, 0) > envelope + 1
      if (stillOver && this.tank > setpoint + 0.15) {
        const byFlex = [...pend].sort((a, b) => (b.load - this.cfgOf[b.m.id].minLoad) - (a.load - this.cfgOf[a.m.id].minLoad))
        let cur = pend.reduce((s, x) => s + x.m.flow, 0)
        for (const x of byFlex) {
          if (cur <= envelope) break
          cur -= x.m.flow
          x.m.loaded = false; x.m.load = 0.02; x.m.flow = 0; x.m.power = machinePower(this.cfgOf[x.m.id], 0, x.m.efficiency)
        }
      }
    } else {
      for (const x of pend) {
        x.m.load = x.load
        x.m.flow = machineFlow(this.cfgOf[x.m.id], x.load)
        x.m.power = machinePower(this.cfgOf[x.m.id], x.load, x.m.efficiency)
      }
    }
  }

  applyPressureDrain(input: TickInput) {
    if (input.mode === 'baseline') return
    if (this.tank > input.tankSetpoint + 0.55) {
      const f = 0.8
      for (const k of Object.keys(input.planTargets)) input.planTargets[k] = Math.max(this.cfgOf[k]?.minLoad ?? 0.05, input.planTargets[k] * f)
    } else if (this.tank > input.tankSetpoint + 0.3) {
      for (const k of Object.keys(input.planTargets)) input.planTargets[k] = Math.max(this.cfgOf[k]?.minLoad ?? 0.05, input.planTargets[k] * 0.92)
    }
  }

  private physics(demand: number, supply: number, dt: number) {
    const vent = Math.max(0, (this.tank - 9.85) * 260 + (supply > demand ? Math.max(0, supply - demand) - 20 : 0) * 0.15) * dt
    const dAir = (supply - demand) / 60 * dt - vent / 60
    this.tank = Math.max(5.5, Math.min(10.5, this.tank + dAir / this.tankVolume))
    const deficit = Math.max(0, demand - supply)
    this.header = Math.max(5.2, this.tank - this.headerOffset - demand / 2600 - deficit / 320 + gauss() * 0.03)
    if (demand > supply + 60) this.tank = Math.max(5.5, this.tank - deficit / 60 * dt / this.tankVolume * 0.35)
  }

  private detectAnomalies() {
    for (const m of this.machines) {
      const roll = this.rolling[m.id]
      if (m.status === 'running' && m.loaded) {
        roll.temp.push(m.temp)
        roll.spec.push(m.power / Math.max(1, m.flow))
      }
      if (roll.temp.length > 90) { roll.temp.shift(); roll.spec.shift() }
      if (roll.temp.length > 40 && this.anomalyCooldown[m.id] <= 0) {
        const mean = roll.temp.reduce((a, b) => a + b, 0) / roll.temp.length
        const sd = Math.sqrt(roll.temp.reduce((a, b) => a + (b - mean) ** 2, 0) / roll.temp.length) + 0.5
        if ((m.temp - mean) / sd > 4.2 && m.temp > 88) {
          this.anomalyCounts[m.id] += 1
          this.anomalyCooldown[m.id] = 25
        }
      }
      this.anomalyCooldown[m.id] -= 1
      m.anomalies24h = this.anomalyCounts[m.id]
    }
  }

  private pushPoint() {
    const supply = this.machines.reduce((s, m) => s + m.flow, 0)
    const power = this.machines.reduce((s, m) => s + m.power, 0)
    const p: SeriesPoint = {
      t: this.simTime, demand: this.demandNow, header: this.header, tank: this.tank,
      supply, power,
      perLoad: Object.fromEntries(this.machines.map(m => [m.id, m.load])),
      perPower: Object.fromEntries(this.machines.map(m => [m.id, m.power])),
      perTemp: Object.fromEntries(this.machines.map(m => [m.id, m.temp])),
      health: Object.fromEntries(this.machines.map(m => [m.id, m.health])),
      running: this.machines.filter(m => m.status === 'running').length,
    }
    this.history.push(p)
  }

  generateHistory(minutes: number) {
    this.initMachines()
    this.tank = (this.bandLow + this.bandHigh) / 2
    this.header = this.tank - this.headerOffset - 0.3
    this.history = []
    for (let i = 0; i < minutes; i++) {
      this.simTime += 60000
      this.demandNow = this.nextDemand(0, 0)
      this.baselineControl(this.demandNow)
      for (const m of this.machines) this.updateMachinePhysics(m, m.loaded ? 1 : 0, 1)
      const supply = this.machines.reduce((s, m) => s + m.flow, 0)
      this.physics(this.demandNow, supply, 1)
      this.detectAnomalies()
      this.pushPoint()
    }
    this.configs.forEach(c => { this.healthInit[c.id] = this.healthInit[c.id] ?? this.machines.find(m => m.id === c.id)!.health })
  }

  tick(input: TickInput, dtMin = 1) {
    this.simTime += 60000 * dtMin
    this.demandNow = this.nextDemand(input.demandShock, input.hourOffset)
    if (input.demandOverride != null && Number.isFinite(input.demandOverride)) {
      this.demandNow = Math.max(80, Math.min(2600, input.demandOverride))
    }
    this.applyPressureDrain(input)
    if (input.mode === 'baseline') {
      this.baselineControl(this.demandNow)
      for (const m of this.machines) {
        if (m.status === 'fault' || m.status === 'maintenance') continue
        this.updateMachinePhysics(m, m.loaded ? 1 : 0, dtMin)
      }
      for (const m of this.machines) {
        if (m.status === 'fault' || m.status === 'maintenance') {
          const c = this.cfgOf[m.id]
          void c
          m.temp += (AMBIENT + 34 - m.temp) / 6 * dtMin
          m.flow = 0; m.power = 0; m.load = 0
          m.health = Math.max(0, m.health - (m.status === 'fault' ? 0.25 : -0.15) * dtMin)
          if (m.status === 'maintenance') m.health = Math.min(96, m.health + 0.02 * dtMin)
        }
      }
    } else {
      const supplyNow = this.machines.reduce((s, m) => s + (m.status === 'running' ? m.flow : 0), 0)
      const gapAdj = Math.max(-0.1, Math.min(0.1, (this.demandNow - supplyNow) / Math.max(200, this.demandNow) * 0.5))
      this.applyPlan(input.planTargets, input.tankSetpoint, gapAdj)
      for (const m of this.machines) {
        if (m.status !== 'running' && m.status !== 'fault' && m.status !== 'maintenance') {
          m.flow = 0; m.power = 0; m.load = 0
          m.runMinutes = 0
          m.stopMinutes += dtMin
          continue
        }
        if (m.status === 'fault' || m.status === 'maintenance') {
          m.temp += (AMBIENT + (m.status === 'fault' ? 34 : 2) - m.temp) / 6 * dtMin
          m.flow = 0; m.power = 0; m.load = 0
          if (m.status === 'maintenance') m.health = Math.min(96, m.health + 0.06 * dtMin)
          continue
        }
        const q = m.loaded ? m.load : 0
        m.hoursTotal += dtMin / 60
        m.runMinutes += dtMin
        if (m.loaded) { m.highLoadMinutes += dtMin * (q > 0.9 ? 1 : 0); m.health -= 0.0016 * q * dtMin }
        else m.health -= 0.0006 * dtMin
        if (m.temp > 95) m.health -= 0.0038 * (m.temp - 95) * dtMin
        m.health = Math.max(1, Math.min(99.5, m.health))
        m.efficiency = efficiencyFromHealth(this.cfgOf[m.id].baseEff, m.health)
        const c = this.cfgOf[m.id]
        m.temp += (AMBIENT + 66 * (m.loaded ? q : 0.2) * (0.92 + (100 - m.health) / 220) - m.temp) / 6 * dtMin
        m.flow = machineFlow(c, m.load)
        m.power = machinePower(c, m.load, m.efficiency)
      }
    }
    const supply = this.machines.reduce((s, m) => s + m.flow, 0)
    this.physics(this.demandNow, supply, dtMin)
    this.detectAnomalies()
    this.pushPoint()
    if (this.history.length > 4320) this.history.splice(0, this.history.length - 4320)
  }

  setFault(id: string, on: boolean) {
    const m = this.machines.find(x => x.id === id)
    if (!m) return
    this.faultsActive[id] = on
    if (on) {
      if (m.status === 'running') this.stopMachine(m)
      m.status = 'fault'
      m.anomalies24h += 2
    } else {
      this.faultsActive[id] = false
      m.status = 'standby'
      m.health = Math.max(48, Math.min(70, m.health))
      m.temp = AMBIENT + 3
      m.stopMinutes = 20
    }
  }

  setMaintenance(id: string, on: boolean) {
    const m = this.machines.find(x => x.id === id)
    if (!m) return
    if (on) {
      if (m.status === 'running') this.stopMachine(m)
      m.status = 'maintenance'
      this.faultsActive[id] = false
    } else {
      m.status = 'standby'
      m.health = Math.min(99, Math.max(m.health, 78))
      m.stopMinutes = 30
      m.temp = AMBIENT + 2
    }
  }

  snapshotMachines(): MachineState[] {
    return this.machines.map(m => ({ ...m }))
  }
}
