export type MachineStatus = 'running' | 'standby' | 'fault' | 'maintenance'

export interface CompressorConfig {
  id: string
  name: string
  ratedFlow: number
  ratedPower: number
  minLoad: number
  maxLoad: number
  baseEff: number
  startCost: number
  minRunTime: number
  minStopTime: number
  noLoadFrac: number
  quadFrac: number
  cascadeOrder: number
}

export interface MachineState {
  id: string
  status: MachineStatus
  loaded: boolean
  load: number
  flow: number
  power: number
  temp: number
  runMinutes: number
  stopMinutes: number
  hoursTotal: number
  startsTotal: number
  health: number
  efficiency: number
  anomalies24h: number
  highLoadMinutes: number
  noloadStreak: number
}

export interface StationSnapshot {
  t: number
  demand: number
  headerPressure: number
  tankPressure: number
  supply: number
  totalPower: number
  machines: MachineState[]
}

export interface SeriesPoint {
  t: number
  demand: number
  header: number
  tank: number
  supply: number
  power: number
  perLoad: Record<string, number>
  perPower: Record<string, number>
  perTemp: Record<string, number>
  health: Record<string, number>
  running: number
}

export type PricePeriod = 'valley' | 'flat' | 'peak'

export interface PriceConfig {
  valley: number
  flat: number
  peak: number
  peakHours: [number, number][]
  flatHours: [number, number][]
  forcePeriod?: PricePeriod
}

export interface PlanUnit {
  id: string
  load: number
  flow: number
  power: number
}

export interface PlanScores {
  energy: number
  stability: number
  cycling: number
  health: number
  reserve: number
  efficiency: number
}

export interface SchedulePlan {
  key: 'A' | 'B' | 'C'
  name: string
  objective: string
  units: PlanUnit[]
  totalPower: number
  totalFlow: number
  specificPower: number
  costPerHour: number
  supplyCapacity: number
  reserveRatio: number
  headerPressureEst: number
  pressureStdEst: number
  startActions: number
  stopActions: number
  risk: number
  infeasibleHealthUnits: string[]
  scores: PlanScores
  totalScore: number
  feasible: boolean
  gap: number
  notes: string[]
  tankSetpoint: number
}

export interface ForecastResult {
  horizon: number[]
  values: number[]
  lower: number[]
  upper: number[]
  f30: number
  f60: number
  f240: number
  peak: number
  trough: number
  trend: 'up' | 'down' | 'flat'
  trendPct: number
  confidence: number
  method: string
}

export interface AnomalyFlag {
  id: string
  kind: 'temp' | 'power' | 'health' | 'pressure' | 'demand'
  level: 'warning' | 'critical'
  message: string
  t: number
  resolved: boolean
}

export interface SimEvent {
  id: string
  label: string
  type: 'demand' | 'fault' | 'tank' | 'price' | 'recover' | 'info'
  detail: string
  t: number
  active: boolean
}

export interface BaselineEstimate {
  units: PlanUnit[]
  totalPower: number
  specificPower: number
  costPerHour: number
  pressureStdEst: number
}

export interface OptimizerContext {
  configs: CompressorConfig[]
  machines: MachineState[]
  demand: number
  forecast: ForecastResult
  priceNow: number
  pricePeriod: PricePeriod
  futurePrices: { hour: number; price: number; period: PricePeriod }[]
  headerPressure: number
  tankPressure: number
  tankVolume: number
  safeMin: number
  weights: Record<keyof PlanScores, number>
  priceCfg: PriceConfig
  startedRecentlyIds: string[]
  simTimeMs: number
  headerPressureStd?: number
}

export interface PressureBoostInfo { pct: number; reason: string }

export interface OptimizeResult {
  plans: SchedulePlan[]
  current: SchedulePlan
  baseline: BaselineEstimate
  recommended: 'A' | 'B' | 'C'
  insufficient: { gap: number; minutesToLimit: number; measures: string[] } | null
  pressureBoost: PressureBoostInfo
}
