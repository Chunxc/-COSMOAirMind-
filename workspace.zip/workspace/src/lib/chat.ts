import type { OptimizerContext, MachineState, OptimizeResult, SchedulePlan, ForecastResult } from './types'
import { optimize } from './optimizer'
import { explainPlan, compareVsBaseline } from './explain'
import { healthBreakdown } from './health'

export interface ChatSnapshot {
  ctx: OptimizerContext
  result: OptimizeResult
  adoptedPlan: SchedulePlan | null
}

const fmt = (v: number, d = 0) => (Math.round(v * Math.pow(10, d)) / Math.pow(10, d)).toLocaleString('zh-CN', { maximumFractionDigits: d })

function block(conclusion: string, evidence: string[], suggestion: string, risk?: string): string {
  let s = `**【结论】** ${conclusion}\n\n**【数据依据】**\n`
  s += evidence.map(e => `- ${e}`).join('\n') + `\n\n**【推荐方案】** ${suggestion}`
  if (risk) s += `\n\n**【风险】** ${risk}`
  return s
}

const STATUS_LABEL: Record<MachineState['status'], string> = { running: '运行', standby: '待机', fault: '故障', maintenance: '检修' }

function band(h: number): string {
  return h >= 90 ? '优秀' : h >= 75 ? '良好' : h >= 60 ? '注意' : h >= 40 ? '风险' : '严重风险'
}

function machineDetail(snap: ChatSnapshot, id: string): string {
  const m = snap.ctx.machines.find(x => x.id === id)!
  const c = snap.ctx.configs.find(x => x.id === id)!
  return `${id}：${c.ratedFlow} Nm³/h / ${c.ratedPower} kW｜状态 ${STATUS_LABEL[m.status]}｜健康度 ${Math.round(m.health)}（${band(m.health)}）｜效率 ${Math.round(m.efficiency * 100)}%｜温度 ${Math.round(m.temp)}℃｜负荷 ${Math.round(m.load * 100)}%`
}

function cloneCtx(base: OptimizerContext, mutateMachines?: (ms: MachineState[]) => MachineState[], demandMult = 1, forecastOverride?: ForecastResult): OptimizerContext {
  const machines = mutateMachines ? mutateMachines(base.machines.map(m => ({ ...m }))) : base.machines
  const forecast = forecastOverride ?? base.forecast
  return {
    ...base,
    machines,
    demand: base.demand * demandMult,
    forecast: {
      ...forecast,
      f30: forecast.f30 * demandMult, f60: forecast.f60 * demandMult, f240: forecast.f240 * demandMult,
      peak: forecast.peak * demandMult,
      trend: demandMult > 1.1 ? 'up' : forecast.trend,
    },
  }
}

function bestOf(ctx: OptimizerContext) {
  const res = optimize(ctx)
  const plan = res.plans.find(p => p.key === res.recommended) ?? res.plans[0] ?? res.current
  return { res, plan }
}

function pickId(q: string): string | null {
  const m = q.match(/A[1-4]/i)
  return m ? m[0].toUpperCase() : null
}

export function answer(question: string, snap: ChatSnapshot): string {
  const { ctx, result } = snap
  const q = question.trim()
  const demand = Math.round(ctx.demand)
  const curPlan = result.plans.find(p => p.key === result.recommended) ?? result.current

  if (/你好|您好|^hi|^hello|帮助|你能做|能问什么|help/i.test(q)) {
    return block(
      '我是 AirMind 空压站调度智能体，所有回答基于系统实时数据与最新调度结果。',
      [
        `当前需求 ${demand} Nm³/h，罐压 ${ctx.tankPressure.toFixed(2)} bar，管网压力 ${ctx.headerPressure.toFixed(2)} bar，${ctx.pricePeriod === 'peak' ? '峰' : ctx.pricePeriod === 'flat' ? '平' : '谷'}价 ${ctx.priceNow.toFixed(2)} 元/kWh`,
        '示例问题：为什么不开A4｜为什么推荐这个组合｜未来1小时会不会缺气｜如果A2故障怎么办｜现在能省多少钱｜需求突增30%怎么办｜哪台设备健康度最低｜现在适合启动A4吗',
      ],
      '直接点击助手页的快捷问题卡片即可开始。',
    )
  }

  if (/(优先|首先|最应该|最该|建议).{0,6}(维护|检修|保养|维修)|(维护|检修|保养|维修).*(优先|哪台|哪一|顺序)/.test(q)) {
    const sorted = ctx.machines
      .filter(m => m.status !== 'maintenance')
      .map(m => ({ m, c: ctx.configs.find(x => x.id === m.id)!, hb: healthBreakdown(ctx.configs.find(x => x.id === m.id)!, m) }))
      .sort((a, b) => a.m.health - b.m.health)
    const t = sorted[0]
    return block(
      `${t.m.id} 最应优先维护：健康度 ${Math.round(t.m.health)} 分（${t.hb.band}）。`,
      sorted.slice(0, 4).map(r => `${r.m.id}：健康 ${Math.round(r.m.health)}（${r.hb.band}）· 温度 ${Math.round(r.m.temp)}℃ · 24h异常 ${r.m.anomalies24h} 次 · 累计启停 ${r.m.startsTotal} 次${r.hb.advice[0] ? ' · ' + r.hb.advice[0] : ''}`),
      t.hb.advice[0] ?? '建议按计划执行保养',
      t.m.health < 40 ? `${t.m.id} 已进入严重风险区，调度已将其负荷上限压至 70%，建议 48 小时内安排停机检修。` : t.m.health < 60 ? `${t.m.id} 处于风险区，建议本周安排保养并加强温度/振动监测。` : `${t.m.id} 处于关注区，可纳入近期预防性维护窗口。`,
    )
  }

  if (/(健康度|状态).*(最低|最差)|哪台.*(健康|最差|最旧)/.test(q)) {
    const pool = [...ctx.machines].sort((a, b) => a.health - b.health)
    const worst = pool[0]
    const c = ctx.configs.find(x => x.id === worst.id)!
    const adopted = snap.adoptedPlan?.units.some(u => u.id === worst.id)
    const capped = worst.health < 40 ? Math.min(c.maxLoad, 0.7) : worst.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad
    return block(
      `${worst.id} 健康度最低：${Math.round(worst.health)} 分，处于「${band(worst.health)}」区间。`,
      pool.map(healthLine),
      adopted
        ? `优化器已将其负荷上限压到 ${Math.round(capped * 100)}%（当前分配 ${Math.round((snap.adoptedPlan?.units.find(u => u.id === worst.id)?.load ?? 0) * 100)}%），在保供与保护之间取平衡；建议 48h 内安排保养。`
        : `当前推荐方案未安排 ${worst.id} 运行，将其保留为风险备用；建议尽快安排检修，恢复后它会重新参与组合优化。`,
      worst.health < 40 ? `${worst.id} 若被迫长期高负荷，故障概率显著上升，可能触发二次重调度。` : undefined,
    )
  }

  if (/如果.*A[1-4].*故障|A[1-4].*故障.*(怎么|办)|坏了一个|故障.*(后果|影响)/i.test(q)) {
    const id = pickId(q)!
    const m0 = ctx.machines.find(x => x.id === id)!
    if (m0.status === 'fault') {
      const { plan } = bestOf(ctx)
      return block(
        `${id} 当前已经是故障状态，AI 已完成重调度，新推荐组合：${plan.units.map(u => u.id).join(' + ')}。`,
        [`故障排除后剩余可调度组合重新优化，评分 ${plan.totalScore}，备用容量 ${plan.reserveRatio}%`, machineDetail(snap, id)],
        `采用方案 ${curPlan.key} 即可执行重调度结果；${id} 修复后可在事件仿真页恢复。`,
      )
    }
    const { res, plan } = bestOf(cloneCtx(ctx, ms => ms.map(m => (m.id === id ? { ...m, status: 'fault' as const, loaded: false, load: 0, flow: 0 } : m))))
    const capLeft = ctx.configs.filter(c => c.id !== id && ctx.machines.find(x => x.id === c.id) && ctx.machines.find(x => x.id === c.id)!.status !== 'fault' && ctx.machines.find(x => x.id === c.id)!.status !== 'maintenance').reduce((s, c) => s + c.ratedFlow, 0)
    if (res.insufficient) {
      return block(
        `若 ${id} 故障，剩余机组无法覆盖预测需求，将触发保供降级。`,
        [
          `${id} 故障后可调度能力 ${fmt(capLeft)} Nm³/h，30 分钟预测需求 ${fmt(ctx.forecast.f30)} Nm³/h`,
          `缺口 ${res.insufficient.gap} Nm³/h，罐压 ${ctx.tankPressure.toFixed(2)} bar 预计 ${res.insufficient.minutesToLimit} 分钟触及安全下限 ${ctx.safeMin} bar`,
        ],
        res.insufficient.measures.slice(0, 3).join('；') + '。',
        '低压将直接影响末端产线，建议尽快将检修计划前置。',
      )
    }
    const base0 = bestOf(ctx).plan
    const buffer = Math.round(ctx.tankVolume * Math.max(0, ctx.tankPressure - ctx.safeMin))
    return block(
      `若 ${id} 故障，系统可自动重调度：切换为 ${plan.units.map(u => `${u.id}@${Math.round(u.load * 100)}%`).join(' + ')}。`,
      [
        `剩余能力 ${fmt(capLeft)} Nm³/h ≥ 预测需求 ${fmt(ctx.forecast.f30)} Nm³/h，备用容量 ${plan.reserveRatio}%`,
        `重调度后功率 ${plan.totalPower} kW（原推荐 ${base0.totalPower} kW），电费 ¥${plan.costPerHour}/h，评分 ${plan.totalScore}`,
        `储气缓冲 ${buffer} Nm³：切换期间罐压有 ${Math.round(buffer / Math.max(1, ctx.demand))} 分钟级支撑，压力不跌破下限`,
      ],
      plan.startActions > 0
        ? `自动启动 ${plan.units.filter(u => !ctx.machines.some(m => m.id === u.id && m.status === 'running')).map(u => u.id).join('、')}，全程无人工介入。`
        : '现有运行机组重新分配负荷即可承接，无新增启停。',
      plan.reserveRatio < 10 ? '应急后裕度变小，此时段再发生故障将直接触发缺口预案。' : '系统同时提高罐压设定以增强抗冲击能力。',
    )
  }

  if (/需求.*(增加|上升|上涨|突增|翻倍)|(\+|增)\s*\d+\s*%|突增|冲击负荷/.test(q)) {
    const mm = q.match(/(\d+)\s*%/)
    const pctv = mm ? parseInt(mm[1], 10) : 30
    const mult = 1 + pctv / 100
    const base0 = bestOf(ctx).plan
    const { res, plan } = bestOf(cloneCtx(ctx, undefined, mult))
    if (res.insufficient) {
      return block(
        `需求突增 ${pctv}%（至约 ${fmt(ctx.demand * mult)} Nm³/h）将超出机组能力，出现保供缺口。`,
        [
          `可调度最大能力 ${fmt(Math.max(...res.plans.map(p => p.supplyCapacity)) || maxCapOf(ctx))} Nm³/h，需求 ${fmt(ctx.forecast.f30 * mult)} Nm³/h`,
          `缺口 ${res.insufficient.gap} Nm³/h · 罐压缓冲触限时间约 ${res.insufficient.minutesToLimit} 分钟`,
        ],
        res.insufficient.measures.slice(0, 3).join('；') + '。',
        '持续欠压影响产线品质，应与车间事先约定可中断负荷清单。',
      )
    }
    const extra = plan.totalPower - base0.totalPower
    const newIds = plan.units.filter(u => !base0.units.some(b => b.id === u.id)).map(u => u.id)
    return block(
      `需求增加 ${pctv}% 可以消化：AI 组合将切换为 ${plan.units.map(u => u.id).join(' + ')}。`,
      [
        `新需求 ${fmt(ctx.demand * mult)} Nm³/h，方案供气 ${fmt(plan.totalFlow)} Nm³/h，备用容量 ${plan.reserveRatio}%`,
        `功率 ${base0.totalPower} → ${plan.totalPower} kW（${extra >= 0 ? '+' : ''}${fmt(extra, 1)} kW），电费 ${fmt(base0.costPerHour, 1)} → ${fmt(plan.costPerHour, 1)} 元/h`,
        `涉及 ${plan.startActions} 起 ${plan.stopActions} 停，综合评分 ${plan.totalScore}`,
      ],
      newIds.length
        ? `提前启动 ${newIds.join('、')}（预测驱动，不等罐压跌到下限再被动响应）。`
        : '通过提升现有机组负荷即可覆盖，无新增启停，成本最低路径。',
      plan.reserveRatio < 12 ? '增幅后裕度收窄，若短时再来一次冲击建议手动锁定一台热备用。' : '储气罐 + 备用容量足以吸收该级别波动。',
    )
  }

  if (/省多少|节省|节约|收益|降低成本|电费.*(降|省)|划算/.test(q)) {
    const plan = snap.adoptedPlan ?? curPlan
    const cmp = compareVsBaseline(plan, result.baseline, ctx)
    const dayKwh = Math.max(0, (result.baseline.totalPower - plan.totalPower) * 24) / 1000
    return block(
      `${plan.name.split('·')[1]?.trim() || 'AI 推荐方案'}（${plan.units.map(u => u.id).join(' + ')}）相对传统压控级联基准，预计节省 ¥${fmt(Math.max(0, cmp.saveYuanPerHour), 1)}/h。`,
      [
        `基准总功率 ${result.baseline.totalPower} kW（定频级联 + 空载损耗模型）→ 方案 ${plan.totalPower} kW，降幅 ${fmt(Math.abs(cmp.deltaPowerPct), 1)}%`,
        `单位产气能耗 ${result.baseline.specificPower} → ${plan.specificPower} kW/(Nm³/h)`,
        `按当前${ctx.pricePeriod === 'peak' ? '峰' : ctx.pricePeriod === 'flat' ? '平' : '谷'}价 ${ctx.priceNow} 元/kWh 外推，日节电约 ${fmt(dayKwh, 1)} 度，年运行收益可达约 ${fmt(Math.max(0, cmp.saveYuanPerHour) * 24 * 300 / 10000, 1)} 万元（按年 300 天、当前负荷水平）`,
      ],
      '采用方案后，驾驶舱「当前节能率」与调度报告的累计收益会随真实 tick 数据动态更新。',
      '节能率随工况波动：峰价高需求时段绝对收益最大，谷价平段收益收窄但启停减少的隐性收益仍然存在。',
    )
  }

  if (/为什么.*不(开|启动|用|选).*A?(\d)|A(\d).*为什么.*(不开|闲置|待机)|不安排.*A?(\d)/i.test(q)) {
    const id = pickId(q)!
    const m = ctx.machines.find(x => x.id === id)!
    const c = ctx.configs.find(x => x.id === id)!
    if (curPlan?.units.some(u => u.id === id)) {
      return block(`${id} 其实在推荐方案内（分配负荷 ${Math.round((curPlan.units.find(u => u.id === id)?.load ?? 0) * 100)}%）。`, [machineDetail(snap, id)], '若指更早的时段，历史调度可在调度报告页追溯。')
    }
    if (m.status === 'fault' || m.status === 'maintenance') {
      return block(
        `${id} 处于「${STATUS_LABEL[m.status]}」硬约束状态，不能参与调度。`,
        [machineDetail(snap, id), `其余机组组合已覆盖预测需求 ${fmt(ctx.forecast.f30)} Nm³/h（评分 ${curPlan?.totalScore ?? '-'}）`],
        m.status === 'maintenance' ? '检修完成后在事件仿真页点击恢复，优化器自动纳入组合。' : '建议立即排查故障（温度/振动/压力历史见设备健康页）。',
      )
    }
    const estLoad = ctx.demand / c.ratedFlow
    const q2 = Math.max(0.3, Math.min(1, estLoad))
    const specIfOn = (c.ratedPower * (c.noLoadFrac + (1 - c.noLoadFrac - c.quadFrac) * q2 + c.quadFrac * q2 ** 2) / m.efficiency) / (c.ratedFlow * q2)
    const reasons: string[] = [machineDetail(snap, id)]
    if (estLoad < 0.55) reasons.push(`当前需求下 ${id} 负荷仅约 ${Math.round(estLoad * 100)}%，低于高效区（72-94%），基载损耗 ${Math.round(c.noLoadFrac * 100)}% 摊薄后单位能耗 ${fmt(specIfOn, 3)} kW/(Nm³/h)，比方案均值 ${fmt(curPlan?.specificPower ?? 0, 3)} 高 ${fmt((specIfOn / (curPlan?.specificPower ?? specIfOn) - 1) * 100, 0)}%`)
    if (m.status === 'standby' && m.stopMinutes < c.minStopTime) reasons.push(`${id} 尚在最小停机保护期（剩 ${Math.round(c.minStopTime - m.stopMinutes)} 分钟），硬约束禁止本周期启动`)
    if (m.health < 70) reasons.push(`健康度 ${Math.round(m.health)}（${band(m.health)}）：系统倾向保护该设备而非优先启用`)
    reasons.push(`现组合备用容量 ${fmt(curPlan?.reserveRatio ?? 0)}% + 储气罐缓冲已能吸收常见波动，${id} 作为梯队备用启动，性价比最优`)
    return block(
      `不开 ${id} 是多目标权衡的结果：低负荷区经济性差，且现组合保供裕度足够。`,
      reasons,
      `保持热备用。一旦预测需求突破 ${fmt((curPlan?.supplyCapacity ?? ctx.demand) * 1.03)} Nm³/h 或罐压跌破 ${(ctx.safeMin + 0.6).toFixed(2)} bar，系统会自动将其启动。`,
    )
  }

  if (/(为什么|为何).{0,6}(现在|此时|当前)?.{0,3}(启动|开启|投运|开).{0,3}A[1-4]|A[1-4].{0,4}(为什么|为何).{0,4}(启动|开启|开)/i.test(q)) {
    const id = pickId(q)!
    const m = ctx.machines.find(x => x.id === id)!
    const c = ctx.configs.find(x => x.id === id)!
    if (m.status === 'fault' || m.status === 'maintenance') {
      return block(`${id} 当前处于「${m.status === 'fault' ? '故障' : '检修'}」状态，不会被启动。`, [machineDetail(snap, id)], '若需要它参与，请先在事件仿真/设置页恢复其状态。')
    }
    const plan = snap.adoptedPlan ?? curPlan
    const u = plan.units.find(x => x.id === id)
    if (!u) {
      const uu = ctx.machines.find(x => x.id === id)!
      return block(`${id} 当前不在推荐方案（${plan.units.map(x => x.id).join('+') || '保底'}）中，因此不会启动。`, [
        `当前需求 ${Math.round(ctx.demand)} Nm³/h，方案供气 ${plan.totalFlow} Nm³/h（备用 ${plan.reserveRatio}%），无需 ${id}`,
        machineDetail(snap, id),
      ], `${id} 作为梯队备用保留，需求上行或机组故障时会被自动纳入。`)
    }
    const spec = u.power / Math.max(1, u.flow)
    const wasRunning = m.status === 'running'
    const reasons: string[] = [machineDetail(snap, id)]
    reasons.push(`承担负荷 ${Math.round(u.load * 100)}%（${Math.round(u.flow)} Nm³/h · ${u.power} kW · 单位能耗 ${spec.toFixed(3)}）`)
    if (!wasRunning) reasons.push(`新投入：启动成本 ¥${c.startCost}；预测/当前需求 ${Math.round(Math.max(ctx.demand, ctx.forecast.f30))} Nm³/h 需要它补足供气能力`)
    else reasons.push(`维持运行：当前负荷 ${Math.round(m.load * 100)}% → 计划 ${Math.round(u.load * 100)}%（调整 ${Math.round((u.load - m.load) * 100)}%），避免换机带来的启停磨损`)
    reasons.push(`健康度 ${Math.round(m.health)}（${healthBreakdown(c, m).band}），${m.health < 60 ? '已限负荷保护' : '状态可支撑该负荷'}`)
    return block(
      `启动/保留 ${id} 是因为它在当前工况下能效与健康度满足要求，且为满足预测需求 ${Math.round(Math.max(ctx.demand, ctx.forecast.f30))} Nm³/h 所必需。`,
      reasons,
      `若需求回落或 ${id} 健康度继续下降，调度会自动将其替换或降载。`,
      ctx.forecast.trend === 'up' ? `预测需求上行（${ctx.forecast.trendPct.toFixed(0)}%），建议保持其在运。` : undefined,
    )
  }

  if (/为什么.*(推荐|选择|选|用|开).*(A\d|组合|机组)|推荐.*理由|为什么这样(调|分配)|方案.*依据/.test(q)) {
    const plan = snap.adoptedPlan ?? curPlan
    const ex = explainPlan(plan, result.baseline, ctx, result)
    return block(ex.headline, [...ex.body, ...ex.reasons].slice(0, 6), ex.reasons[0] ?? '采纳方案即可执行', ex.warnings.length ? ex.warnings.join('；') : undefined)
  }

  if (/缺气|缺口|够不够|撑不住|断供|压力.*(会不会|还能)/.test(q)) {
    const f60 = ctx.forecast.f60, f240 = ctx.forecast.f240
    const cap = maxCapOf(ctx)
    const minMargin = Math.min(cap - f60, cap - f240)
    const buffer = Math.max(0, ctx.tankVolume * (ctx.tankPressure - ctx.safeMin))
    return block(
      minMargin >= 0 ? '未来 4 小时不会缺气，压力体系可控。' : `有风险：预测需求峰值将超出可调度能力约 ${fmt(-minMargin)} Nm³/h。`,
      [
        `可调度能力 ${fmt(cap)} Nm³/h ｜ 预测 30/60/240 分钟：${fmt(ctx.forecast.f30)} / ${fmt(f60)} / ${fmt(f240)} Nm³/h`,
        `当前罐压 ${ctx.tankPressure.toFixed(2)} bar，安全下限 ${ctx.safeMin} bar，储气缓冲 ${fmt(buffer)} Nm³`,
        `极端失衡 ${fmt(Math.max(0, ctx.forecast.peak - cap))} Nm³/h 时缓冲可撑约 ${Math.round(buffer / Math.max(1, ctx.forecast.peak - cap))} 分钟，大于重调度所需时间（秒级）`,
      ],
      minMargin >= 0 ? '当前推荐方案已含预启动逻辑，无需人工干预。' : '建议：恢复可用机组 / 与车间约定削峰限气 / 允许短时压力低位运行。',
      ctx.headerPressure < ctx.safeMin + 0.4 ? '管网压力已接近下限，保供优先于节能。' : undefined,
    )
  }

  if (/(适合|可以|应该|要不要|是否).*(启动|开|投运).*A(\d)|A(\d).*(能开|该开)/i.test(q)) {
    const id = pickId(q)!
    const m = ctx.machines.find(x => x.id === id)!
    const c = ctx.configs.find(x => x.id === id)!
    if (m.status === 'running') return block(`${id} 正在运行（负荷 ${Math.round(m.load * 100)}%，功率 ${Math.round(m.power)} kW）。`, [machineDetail(snap, id)], '如需改变其负荷归属，请在调度页切换方案。')
    if (m.status !== 'standby') return block(`${id} 处于${STATUS_LABEL[m.status]}状态，现在不能启动。`, [machineDetail(snap, id)], '请先处理故障/完成检修，状态恢复后 AI 会自动重新评估。')
    const protect = m.stopMinutes < c.minStopTime
    const inPlan = curPlan?.units.some(u => u.id === id)
    return block(
      inPlan ? '适合——推荐方案本身就是开它的。' : protect ? `还不适合：${id} 处于最小停机保护期。` : `技术上可以，但经济上不划算。`,
      [
        machineDetail(snap, id),
        `连续停机 ${Math.round(m.stopMinutes)} 分钟 / 约束 ≥ ${c.minStopTime} 分钟，启停成本 ¥${c.startCost}/次`,
        `预测需求 ${fmt(ctx.forecast.f30)} Nm³/h，现方案供气 ${fmt(curPlan?.totalFlow ?? 0)} Nm³/h（备用 ${fmt(curPlan?.reserveRatio ?? 0)}%）`,
      ],
      inPlan ? `到智能调度页采用方案 ${curPlan!.key} 即可自动执行启动。` : protect ? `再等 ${Math.round(c.minStopTime - m.stopMinutes)} 分钟解除保护；若届时需求上涨 AI 会主动启动它。` : '当前组合+储气缓冲足够，多开一台预计多耗 ¥' + fmt(c.ratedPower * 0.6 * ctx.priceNow, 1) + '/h，收益为负。',
      !inPlan && !protect ? '若车间确认有新增大负荷，请告诉我，我可以做 what-if 预演。' : undefined,
    )
  }

  if (/压力|波动|稳定/.test(q)) {
    return block(
      ctx.headerPressure < ctx.safeMin + 0.3 ? '压力偏低，保供优先级当前高于节能。' : '压力体系整体稳定，AI 连续调负荷消除了传统锯齿波动。',
      [
        `管网 ${ctx.headerPressure.toFixed(2)} bar（下限 ${ctx.safeMin}）｜罐压 ${ctx.tankPressure.toFixed(2)} bar`,
        `推荐方案压力波动预估 σ ≈ ${fmt(curPlan?.pressureStdEst ?? 0.1, 2)} bar，级联基准 σ ≈ ${fmt(result.baseline.pressureStdEst, 2)} bar`,
        `罐压目标设定 ${fmt(curPlan?.tankSetpoint ?? 8, 1)} bar`,
      ],
      'AI 用负荷连续调节 + 储气罐缓冲替代「满载/空载跳变」，末端产线感受到的压差更平。',
    )
  }

  if (/电价|峰谷|谷电|峰电/.test(q)) {
    const nw = ctx.futurePrices.slice(0, 6).map(p => `${p.hour}时${p.period === 'peak' ? '峰' : p.period === 'flat' ? '平' : '谷'}${p.price}`).join(' → ')
    return block(
      `当前处于${ctx.pricePeriod === 'peak' ? '峰价' : ctx.pricePeriod === 'flat' ? '平价' : '谷价'}时段（${ctx.priceNow} 元/kWh）。`,
      [
        `未来 6 小时电价走势：${nw}`,
        `峰谷价差 ${fmt(ctx.priceCfg.peak - ctx.priceCfg.valley, 2)} 元/kWh，最大优化空间在峰价时段控制基载损耗与预蓄能`,
        `推荐方案小时电费 ${fmt(curPlan?.costPerHour ?? 0, 1)} 元 vs 基准 ${fmt(result.baseline.costPerHour, 1)} 元`,
      ],
      curPlan && curPlan.tankSetpoint > 8.2 ? '方案已含「谷价末期蓄能」：提前把罐压抬高，峰价初段少开一台。' : 'AI 在每个 tick 均按当前+未来电价重算组合，无需人工盯峰谷。',
    )
  }

  return block(
    `基于实时数据的核心事实：AI 当前推荐 ${curPlan?.units.map(u => u.id).join(' + ') ?? '—'}，评分 ${fmt(curPlan?.totalScore ?? 0, 1)}。`,
    [
      `需求 ${demand} Nm³/h · 30 分钟预测 ${fmt(ctx.forecast.f30)} · 趋势 ${ctx.forecast.trend === 'up' ? '↑' : ctx.forecast.trend === 'down' ? '↓' : '→'}${fmt(Math.abs(ctx.forecast.trendPct), 0)}%`,
      `罐压 ${ctx.tankPressure.toFixed(2)} bar · 管网 ${ctx.headerPressure.toFixed(2)} bar · 电价 ${ctx.priceNow.toFixed(2)} 元/kWh`,
      '可以试试：为什么不开A4 / 为什么推荐这个组合 / 会不会缺气 / A2故障怎么办 / 需求增加30% / 能省多少钱 / 哪台健康度最低',
    ],
    '换个说法提问，或点击快捷卡片。',
  )
}

function healthLine(m: MachineState): string {
  return `${m.id}：健康度 ${Math.round(m.health)}（${band(m.health)}）· ${STATUS_LABEL[m.status]} · 温度 ${Math.round(m.temp)}℃ · 启停 ${m.startsTotal} 次 · 24h 异常 ${m.anomalies24h} 次`
}

function maxCapOf(ctx: OptimizerContext): number {
  return ctx.configs.reduce((s, c) => {
    const m = ctx.machines.find(x => x.id === c.id)
    if (!m) return s
    if (m.status === 'fault' || m.status === 'maintenance') return s
    if (m.status === 'standby' && m.stopMinutes < c.minStopTime) return s
    const hCap = m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad
    return s + c.ratedFlow * hCap
  }, 0)
}
