import type { CompressorConfig, PriceConfig } from './types'

export const DEFAULT_CONFIGS: CompressorConfig[] = [
  { id: 'A1', name: 'A1 螺杆机 500', ratedFlow: 500, ratedPower: 90, minLoad: 0.3, maxLoad: 1.0, baseEff: 0.985, startCost: 12, minRunTime: 10, minStopTime: 8, noLoadFrac: 0.32, quadFrac: 0.05, cascadeOrder: 4 },
  { id: 'A2', name: 'A2 螺杆机 600', ratedFlow: 600, ratedPower: 110, minLoad: 0.3, maxLoad: 1.0, baseEff: 0.955, startCost: 14, minRunTime: 10, minStopTime: 8, noLoadFrac: 0.33, quadFrac: 0.06, cascadeOrder: 3 },
  { id: 'A3', name: 'A3 离心机 800', ratedFlow: 800, ratedPower: 150, minLoad: 0.35, maxLoad: 1.0, baseEff: 0.97, startCost: 25, minRunTime: 20, minStopTime: 15, noLoadFrac: 0.35, quadFrac: 0.05, cascadeOrder: 2 },
  { id: 'A4', name: 'A4 离心机 1000', ratedFlow: 1000, ratedPower: 185, minLoad: 0.4, maxLoad: 1.0, baseEff: 0.99, startCost: 30, minRunTime: 20, minStopTime: 15, noLoadFrac: 0.34, quadFrac: 0.06, cascadeOrder: 1 },
]

export const DEFAULT_PRICE: PriceConfig = {
  valley: 0.38,
  flat: 0.68,
  peak: 1.05,
  peakHours: [[10, 12], [14, 19]],
  flatHours: [[7, 10], [19, 23]],
}

export const STATION_DEFAULTS = {
  tankVolume: 10,
  nominalPressure: 8.0,
  safeMinPressure: 6.8,
  bandLow: 7.4,
  bandHigh: 8.6,
  headerOffset: 0.5,
  initialDemand: 800,
}

export function machinePower(cfg: CompressorConfig, load: number, efficiency: number): number {
  if (load <= 0.001) return cfg.ratedPower * cfg.noLoadFrac / efficiency
  const q = Math.max(cfg.minLoad, load)
  const a = cfg.noLoadFrac
  const b = cfg.quadFrac
  const linear = 1 - a - b
  const f = a + linear * q + b * q * q
  return (cfg.ratedPower * f) / efficiency
}

export function machineFlow(cfg: CompressorConfig, load: number): number {
  if (load <= 0.001) return 0
  return cfg.ratedFlow * Math.max(cfg.minLoad, Math.min(cfg.maxLoad, load))
}

export function efficiencyFromHealth(baseEff: number, health: number): number {
  return baseEff * (0.86 + 0.14 * Math.sqrt(Math.max(0, Math.min(100, health)) / 100))
}

export function priceOfPeriod(p: PriceConfig, period: 'valley' | 'flat' | 'peak'): number {
  return period === 'peak' ? p.peak : period === 'flat' ? p.flat : p.valley
}

export function periodOfHour(p: PriceConfig, hour: number): 'valley' | 'flat' | 'peak' {
  const inRange = (r: [number, number][]) => r.some(([s, e]) => hour >= s && hour < e)
  if (inRange(p.peakHours)) return 'peak'
  if (inRange(p.flatHours)) return 'flat'
  return 'valley'
}
