import type {
  OptimizerContext, OptimizeResult, SchedulePlan, PlanScores, PlanUnit,
  MachineState, CompressorConfig, BaselineEstimate,
} from './types'
import { machinePower } from './params'
import { dispatchCostFactor } from './health'

const D = 10
const clamp100 = (v: number) => Math.max(0, Math.min(100, v))
const r1 = (v: number) => Math.round(v * 10) / 10
const r3 = (v: number) => Math.round(v * 1000) / 1000

interface AllocUnit { id: string; load: number; flow: number; power: number; cap: number }
interface Alloc { units: AllocUnit[]; totalPower: number; totalFlow: number }

function effectiveMax(c: CompressorConfig, m: MachineState): number {
  if (m.health < 40) return Math.min(c.maxLoad, 0.7)
  if (m.health < 60) return Math.min(c.maxLoad, 0.85)
  return c.maxLoad
}

interface Opt { q: number; fl: number; pw: number; idx: number }

function dpAllocate(subset: { c: CompressorConfig; m: MachineState }[], targetFlow: number, minFlow: number): Alloc | null {
  const N = Math.ceil(targetFlow / D)
  const opts: Opt[][] = subset.map(({ c, m }) => {
    const maxL = effectiveMax(c, m)
    const list: Opt[] = [{ q: 0, fl: 0, pw: 0, idx: 0 }]
    const steps = 50
    let lastIdx = -1
    for (let i = 1; i <= steps; i++) {
      const q = c.minLoad + (maxL - c.minLoad) * (i / steps)
      const fl = c.ratedFlow * q
      const idx = Math.max(1, Math.floor(fl / D))
      if (idx === lastIdx) continue
      lastIdx = idx
      list.push({ q, fl, pw: machinePower(c, q, m.efficiency), idx })
    }
    return list
  })
  const SIZE = N + 4
  const INF = Number.MAX_VALUE / 4
  let dp = new Float64Array(SIZE).fill(INF)
  dp[0] = 0
  const trace: { nd: Float64Array; choice: Int16Array }[] = []
  for (let i = 0; i < subset.length; i++) {
    const nd = new Float64Array(SIZE).fill(INF)
    const choice = new Int16Array(SIZE).fill(-1)
    for (let n = 0; n < SIZE; n++) {
      if (dp[n] >= INF) continue
      const optsI = opts[i]
      for (let oi = 0; oi < optsI.length; oi++) {
        const nn = n + optsI[oi].idx
        if (nn >= SIZE) continue
        const val = dp[n] + optsI[oi].pw
        if (val < nd[nn]) { nd[nn] = val; choice[nn] = oi }
      }
    }
    dp = nd
    trace.push({ nd, choice })
  }
  const candidates: number[] = []
  for (let n = Math.max(0, N - 3); n < SIZE; n++) if (dp[n] < INF / 4) candidates.push(n)
  candidates.sort((a, b) => dp[a] - dp[b])
  for (const startN of candidates) {
    const units: AllocUnit[] = []
    let n = startN
    let valid = true
    for (let i = subset.length - 1; i >= 0 && valid; i--) {
      const oi = trace[i].choice[n]
      if (oi < 0 && n > 0) { valid = false; break }
      const o = oi >= 0 ? opts[i][oi] : opts[i][0]
      const c = subset[i].c
      units.unshift({ id: c.id, load: r3(o.q), flow: r1(o.fl), power: r1(o.pw), cap: r1(c.ratedFlow * effectiveMax(c, subset[i].m)) })
      n = n - o.idx
      if (n < 0) valid = false
    }
    if (!valid || n !== 0) continue
    const active = filterActive(units)
    const totalFlow = units.reduce((s, u) => s + u.flow, 0)
    if (totalFlow + 0.5 < minFlow) continue
    return { units: active, totalPower: active.reduce((s, u) => s + u.power, 0), totalFlow }
  }
  return null
}

function filterActive(units: AllocUnit[]): AllocUnit[] {
  return units.filter(u => u.load > 0.03)
}

export function maxCapacity(cfgs: CompressorConfig[], machines: MachineState[]): number {
  return cfgs.reduce((s, c) => {
    const m = machines.find(x => x.id === c.id)
    if (!m || m.status === 'fault' || m.status === 'maintenance') return s
    return s + c.ratedFlow * effectiveMax(c, m)
  }, 0)
}

function estPressureStd(header: number, tank: number, safeMin: number, demand: number, f30: number): number {
  let v = header < 7 ? 0.3 : header < 7.3 ? 0.16 : 0.07
  if (tank < safeMin + 0.9) v += 0.22
  v += Math.max(0, (f30 - demand) / demand) * 0.5
  return v
}

function scoreDims(alloc: Alloc, ctx: OptimizerContext, starts: number, stops: number, minRunViol: number, capAll: number, headerStd2: number): PlanScores {
  const spec = alloc.totalPower / Math.max(1, alloc.totalFlow)
  const energy = clamp100((0.30 - spec) / (0.30 - 0.16) * 100)
  const margin = (alloc.totalFlow - ctx.demand) / Math.max(1, ctx.demand)
  const qs = alloc.units.map(u => u.load)
  const meanQ = qs.length ? qs.reduce((a, b) => a + b, 0) / qs.length : 0
  const stdL = qs.length ? Math.sqrt(qs.reduce((s, q) => s + (q - meanQ) ** 2, 0) / qs.length) : 0
  const maxRated = alloc.units.length ? Math.max(...alloc.units.map(u => ctx.configs.find(c => c.id === u.id)?.ratedFlow ?? 0)) : 0
  const redun = (alloc.totalFlow - maxRated) / Math.max(1, ctx.demand)
  const stability = clamp100(
    Math.min(1, Math.max(0, margin / 0.22)) * 26
    + (1 - Math.min(1, stdL / 0.35)) * 10
    + Math.max(0, Math.min(1, (redun + 0.05) / 0.2)) * 49
    + Math.max(0, 1 - headerStd2 / 0.45) * 15)
  let churn = 0
  for (const u of alloc.units) {
    const cm = ctx.machines.find(x => x.id === u.id)
    churn += cm && cm.status === 'running' ? Math.abs(u.load - cm.load) : 0
  }
  const churnNorm = alloc.units.length ? churn / alloc.units.length : 0
  const cycling = clamp100(100 - starts * 17 - stops * 13 - minRunViol * 25 - churnNorm * 55)
  const risk = alloc.units.reduce((s, u) => {
    const m = ctx.machines.find(x => x.id === u.id)
    return s + Math.pow(u.load, 1.4) * (100 - (m ? m.health : 70)) / 100
  }, 0) / Math.max(1, alloc.units.length)
  const health = clamp100(100 - risk * 118)
  const capR = (capAll - alloc.totalFlow) / Math.max(1, capAll)
  const reserve = clamp100(Math.min(1, capR / 0.3) * 100)
  let pen = 0
  for (const u of alloc.units) pen += Math.max(0, 0.72 - u.load) * 2.6 + Math.max(0, u.load - 0.94) * 3.2
  const efficiency = clamp100(100 - pen / Math.max(1, alloc.units.length) * 52)
  return {
    energy: r1(energy), stability: r1(stability), cycling: r1(cycling),
    health: r1(health), reserve: r1(reserve), efficiency: r1(efficiency),
  }
}

function totalScore(s: PlanScores, w: Record<keyof PlanScores, number>): number {
  const sum = Object.values(w).reduce((a, b) => a + b, 0) || 1
  return r1((s.energy * w.energy + s.stability * w.stability + s.cycling * w.cycling +
    s.health * w.health + s.reserve * w.reserve + s.efficiency * w.efficiency) / sum)
}

function pickTankSetpoint(ctx: OptimizerContext): number {
  const nxt = ctx.futurePrices.slice(0, 4)
  const soon = nxt.length ? Math.max(...nxt.map(p => p.price)) : ctx.priceNow
  const demandUp = ctx.forecast.trend === 'up' && ctx.forecast.trendPct > 12
  if (ctx.pricePeriod === 'peak' && nxt.length && nxt[0].price < ctx.priceNow * 0.85) return 7.7
  if (soon > ctx.priceNow * 1.15 || demandUp) return 8.4
  return 8.05
}

export interface Evaluated {
  alloc: Alloc
  ids: string[]
  starts: number
  stops: number
  minRunViol: number
}

function healthDispatchPenalty(alloc: Alloc, ctx: OptimizerContext): number {
  let pen = 0
  for (const u of alloc.units) {
    const m = ctx.machines.find(x => x.id === u.id)
    if (!m) continue
    pen += u.power * (dispatchCostFactor(m) - 1)
  }
  return pen
}

export interface PressureBoost { pct: number; reason: string }

export function pressureBoostOf(ctx: OptimizerContext): PressureBoost {
  const tankGap = ctx.safeMin + 1.0 - ctx.tankPressure
  const hdrLow = ctx.headerPressure < ctx.safeMin + 0.3 ? 0.07 : ctx.headerPressure < ctx.safeMin + 0.6 ? 0.035 : 0
  let pct = 0
  let reason = ''
  if (tankGap > 0) {
    pct = Math.max(pct, Math.min(0.12, tankGap * 0.085))
    reason = `罐压 ${ctx.tankPressure.toFixed(2)} bar 低于安全带（距安全下限 ${ctx.safeMin} bar 不足 1 bar），调度目标供气自动上浮，预留压力缓冲`
  }
  if (hdrLow > pct) {
    pct = hdrLow
    reason = `管网压力 ${ctx.headerPressure.toFixed(2)} bar 接近安全下限，提高组合供气裕度抑制压降`
  }
  return { pct: r3(pct), reason }
}

function allocRisk(alloc: Alloc, ctx: OptimizerContext): number {
  if (!alloc.units.length) return 0
  return alloc.units.reduce((s, u) => {
    const m = ctx.machines.find(x => x.id === u.id)
    return s + Math.pow(u.load, 1.4) * (100 - (m ? m.health : 80)) / 100
  }, 0) / alloc.units.length
}

export function feasibleAllocations(ctx: OptimizerContext): { evaluated: Evaluated[]; target: number; capAll: number; runningIds: string[]; lockout: string[]; schedulable: { c: CompressorConfig; m: MachineState }[]; boost: PressureBoost } {
  const { configs, machines, demand, forecast } = ctx
  const avail = configs.map(c => ({ c, m: machines.find(x => x.id === c.id)! })).filter(x => x.m && x.m.status !== 'fault' && x.m.status !== 'maintenance')
  const demandFloor = Math.max(demand, forecast.f30 * 0.97)
  const rawLock = avail.filter(x => x.m.status === 'standby' && x.m.stopMinutes < x.c.minStopTime)
  const runCap = avail.filter(x => x.m.status === 'running').reduce((s, x) => s + x.c.ratedFlow * x.c.maxLoad, 0)
  // 最小停机时间是软约束：运行机组足以覆盖「调度目标（含预测）」时才启用保护；否则锁定放开，保供优先
  const lockNeed = Math.max(demand, forecast.f30, forecast.f60 * 0.97)
  const lockout = runCap >= lockNeed ? rawLock.map(x => x.c.id) : []
  const schedulable = avail.filter(x => !lockout.includes(x.c.id))
  const runningIds = machines.filter(m => m.status === 'running').map(m => m.id)
  const capAll = maxCapacity(configs, machines)
  const vent = Math.max(0, ctx.tankPressure - 8.42) * 900
  const boost = pressureBoostOf(ctx)
  const Dplan = Math.max(demand * 0.92, Math.max(demand * 1.01, forecast.f30, forecast.f60 * 0.97) - vent) * (1 + boost.pct)
  const target = Math.ceil(Dplan / D) * D
  // 供气下界取全需求，但不超出 DP 搜索窗口；罐压偏高触发泄压时允许少产以泄压
  const minFlow = Math.min(Math.max(demandFloor, Dplan - 30), target + 3 * D)
  const evaluated: Evaluated[] = []
  for (let mask = 1; mask < (1 << schedulable.length); mask++) {
    const items = schedulable.filter((_, i) => mask & (1 << i))
    const cap = items.reduce((s, x) => s + x.c.ratedFlow * effectiveMax(x.c, x.m), 0)
    if (cap < demandFloor - 0.5) continue
    const alloc = dpAllocate(items, target, minFlow)
    if (!alloc) continue
    const ids = alloc.units.map(u => u.id)
    const starts = ids.filter(id => !runningIds.includes(id)).length
    const stops = runningIds.filter(id => !ids.includes(id)).length
    const minRunViol = runningIds.filter(id => !ids.includes(id))
      .map(id => machines.find(m => m.id === id)!)
      .filter(m => m.runMinutes < configs.find(c => c.id === m.id)!.minRunTime).length
    evaluated.push({ alloc, ids, starts, stops, minRunViol })
  }
  const seenCombos = new Set<string>()
  const uniq = evaluated.filter(e => {
    const k = e.alloc.units.map(u => u.id).sort().join('+')
    if (seenCombos.has(k)) return false
    seenCombos.add(k); return true
  })
  return { evaluated: uniq, target, capAll, runningIds, lockout, schedulable, boost }
}

export function optimize(ctx: OptimizerContext): OptimizeResult {
  const { configs, machines, forecast, priceNow, weights } = ctx
  const { evaluated, target, capAll, runningIds, lockout, schedulable, boost } = feasibleAllocations(ctx)
  const nowFlow = machines.reduce((s, m) => s + m.flow, 0)
  const nowPower = machines.reduce((s, m) => s + m.power, 0)
  const headerStd2 = estPressureStd(ctx.headerPressure, ctx.tankPressure, ctx.safeMin, ctx.demand, forecast.f30)
  const tankSetpoint = pickTankSetpoint(ctx)

  const toPlanUnits = (alloc: Alloc): PlanUnit[] => alloc.units.map(u => ({ id: u.id, load: u.load, flow: u.flow, power: u.power }))

  const buildPlan = (key: 'A' | 'B' | 'C', name: string, objective: string, ev: Evaluated): SchedulePlan => {
    const scores = scoreDims(ev.alloc, ctx, ev.starts, ev.stops, ev.minRunViol, capAll, headerStd2)
    const margin = (ev.alloc.totalFlow - ctx.demand) / Math.max(1, ctx.demand)
    const riskUnits = ev.alloc.units.filter(u => {
      const m = ctx.machines.find(x => x.id === u.id)!
      return m.health < 60 && u.load > 0.75
    }).map(u => u.id)
    const notes: string[] = []
    const newStarts = ev.alloc.units.filter(u => !runningIds.includes(u.id)).map(u => u.id)
    if (newStarts.length) notes.push(`启动 ${newStarts.join('、')} 补足供气能力`)
    const toStop = runningIds.filter(id => !lockout.includes(id) && !ev.ids.includes(id))
    if (toStop.length) notes.push(`停机 ${toStop.join('、')} 消除空载损耗`)
    if (ev.minRunViol > 0) notes.push(`${ev.minRunViol} 台未满最小连续运行时间，强行停机将增加启停磨损`)
    if (riskUnits.length) notes.push(`${riskUnits.join('、')} 健康度偏低，负荷上限已被压缩保护`)
    if (lockout.length && !ev.ids.some(id => lockout.includes(id))) notes.push(`${lockout.join('、')} 处于最小停机保护期，本周期不纳入调度`)
    if (tankSetpoint >= 8.3) notes.push(`未来电价上行或需求看涨，储气罐设定升至 ${tankSetpoint} bar 提前蓄能`)
    if (tankSetpoint <= 7.8 && ctx.pricePeriod === 'peak') notes.push(`峰价时段将罐压设定降至 ${tankSetpoint} bar，减少高价电压缩功`)
    return {
      key, name, objective,
      units: toPlanUnits(ev.alloc),
      totalPower: r1(ev.alloc.totalPower),
      totalFlow: r1(ev.alloc.totalFlow),
      specificPower: r3(ev.alloc.totalPower / Math.max(1, ev.alloc.totalFlow)),
      costPerHour: r1(ev.alloc.totalPower * priceNow),
      supplyCapacity: r1(ev.alloc.totalFlow),
      reserveRatio: r1(Math.max(0, margin) * 100),
      headerPressureEst: r1(ctx.tankPressure - 0.5 - ctx.demand / 2600),
      pressureStdEst: r3(headerStd2),
      startActions: ev.starts,
      stopActions: ev.stops,
      risk: r1(100 - scores.health),
      infeasibleHealthUnits: riskUnits,
      scores, totalScore: totalScore(scores, weights),
      feasible: true, gap: 0, notes, tankSetpoint,
    }
  }

  let plans: SchedulePlan[] = []
  if (evaluated.length) {
    const byEnergy = [...evaluated].sort((a, b) =>
      (a.alloc.totalPower / target + a.starts * 0.004 + a.stops * 0.003 + allocRisk(a.alloc, ctx) * 0.02 + healthDispatchPenalty(a.alloc, ctx) / target)
      - (b.alloc.totalPower / target + b.starts * 0.004 + b.stops * 0.003 + allocRisk(b.alloc, ctx) * 0.02 + healthDispatchPenalty(b.alloc, ctx) / target))[0]
    const byStab = [...evaluated].map(e => ({ e, sc: scoreDims(e.alloc, ctx, e.starts, e.stops, e.minRunViol, capAll, headerStd2) }))
      .sort((a, b) => (b.sc.stability * 1.2 + b.sc.reserve * 0.9 + b.sc.health * 0.8 + b.sc.cycling * 0.7) - (a.sc.stability * 1.2 + a.sc.reserve * 0.9 + a.sc.health * 0.8 + a.sc.cycling * 0.7))[0].e
    const byTotal = [...evaluated].map(e => ({ e, v: totalScore(scoreDims(e.alloc, ctx, e.starts, e.stops, e.minRunViol, capAll, headerStd2), weights) }))
      .sort((a, b) => (b.v - a.v))[0].e
    plans = [
      buildPlan('A', '方案A · 最低能耗', '最小化实时电费用：能耗与启停成本优先', byEnergy),
      buildPlan('B', '方案B · 最高稳定性', '最大化供气裕度：稳定性/备用容量/健康保护优先', byStab),
      buildPlan('C', '方案C · 综合最优', '六维加权评分：能耗/稳定/启停/健康/备用/效率全局最优', byTotal),
    ]
  }

  const curUnits: PlanUnit[] = machines.filter(m => m.status === 'running').map(m => ({
    id: m.id, load: r3(m.load), flow: r1(m.flow), power: r1(m.power),
  }))
  const curAlloc: Alloc = {
    units: curUnits.map(u => {
      const c = configs.find(x => x.id === u.id)!
      return { ...u, cap: c.ratedFlow * effectiveMax(c, machines.find(m => m.id === u.id)!) }
    }),
    totalPower: nowPower, totalFlow: nowFlow,
  }
  const curScores = scoreDims(
    curAlloc.totalFlow > 0 ? curAlloc : { units: [], totalPower: 0.001, totalFlow: 0.001 },
    { ...ctx, demand: Math.max(ctx.demand, 1) }, 0, 0, 0, capAll, r3(Math.max(0.12, headerStd2 * 1.8)))
  const current: SchedulePlan = {
    key: 'C', name: '当前运行工况', objective: '现场实际运行数据回放',
    units: curUnits,
    totalPower: r1(nowPower),
    totalFlow: r1(nowFlow),
    specificPower: r3(nowPower / Math.max(1, nowFlow)),
    costPerHour: r1(nowPower * priceNow),
    supplyCapacity: r1(nowFlow),
    reserveRatio: r1(Math.max(0, (nowFlow - ctx.demand) / Math.max(1, ctx.demand)) * 100),
    headerPressureEst: r1(ctx.headerPressure),
    pressureStdEst: r3(Math.max(0.05, headerStd2 * 1.8)),
    startActions: 0, stopActions: 0,
    risk: r1(100 - curScores.health),
    infeasibleHealthUnits: [],
    scores: curScores, totalScore: totalScore(curScores, weights),
    feasible: nowFlow >= ctx.demand * 0.97, gap: r1(Math.max(0, ctx.demand - nowFlow)),
    notes: nowFlow < ctx.demand * 0.97 ? ['当前供气能力低于用气需求，罐压持续下降'] : [],
    tankSetpoint,
  }

  let insufficient: OptimizeResult['insufficient'] = null
  if (!evaluated.length) {
    const capSched = schedulable.reduce((s2, x) => s2 + x.c.ratedFlow * effectiveMax(x.c, x.m), 0)
    const gap = Math.max(1, Math.round(target - capAll))
    const rate = Math.max(0.02, gap / 60 / ctx.tankVolume)
    if (lockout.length && maxCapacity(configs, machines.map(m => m)) >= target) {
      const l = configs.find(c => c.id === lockout[0])!
      const gapLock = Math.max(1, Math.round(target - capSched))
      insufficient = {
        gap: gapLock, minutesToLimit: Math.round(Math.max(0, (ctx.tankPressure - ctx.safeMin) / rate)),
        measures: [`强制启动处于保护期的 ${lockout.join('、')} 可补足缺口 ${gapLock} Nm³/h（承担额外启停磨损，约 ¥${l.startCost}/次）`, '联系用气车间对非关键产线限流 10-15%'],
      }
    } else {
      insufficient = {
        gap: r1(gap), minutesToLimit: Math.round(Math.max(0, ctx.tankPressure - ctx.safeMin) / rate),
        measures: [
          `调度能力缺口约 ${r1(gap)} Nm³/h，预计 ${Math.round(Math.max(0, ctx.tankPressure - ctx.safeMin) / rate)} 分钟后管网压力降至安全下限`,
          '恢复检修/故障机组或启用备用机组',
          '对次要生产线实施 10-15% 限气',
          '必要时按最大能力运行全部机组并接受短时压力低位',
        ],
      }
    }
  }

  const feasiblePlans = plans.filter(p => p.feasible)
  const recommended = feasiblePlans.length
    ? feasiblePlans.reduce((a, b) => (b.totalScore > a.totalScore ? b : a)).key
    : 'C'
  const baseline = estimateBaseline(ctx)
  return { plans, recommended, current, baseline, insufficient, pressureBoost: boost }
}

export function estimateBaseline(ctx: OptimizerContext): BaselineEstimate {
  const { configs, machines, demand, forecast, priceNow } = ctx
  const order = [...configs]
    .filter(c => {
      const m = machines.find(x => x.id === c.id)
      return m && m.status !== 'fault' && m.status !== 'maintenance'
    })
    .sort((a, b) => a.cascadeOrder - b.cascadeOrder)
  const Dplan = Math.max(demand * 1.01, forecast.f30)
  let cap = 0
  let k = 0
  for (const c of order) { cap += c.ratedFlow; k++; if (cap >= Dplan) break }
  const chosen = order.slice(0, cap < Dplan ? order.length : k)
  const units: PlanUnit[] = []
  let totalP = 0
  if (cap >= Dplan) {
    const prevCap = cap - chosen[chosen.length - 1].ratedFlow
    const duty = Math.max(0.05, Math.min(1, (Dplan - prevCap) / chosen[chosen.length - 1].ratedFlow))
    chosen.forEach((c, i) => {
      const m = machines.find(x => x.id === c.id)!
      const full = machinePower(c, 1, m.efficiency)
      const no = machinePower(c, 0, m.efficiency)
      const isLast = i === chosen.length - 1
      const p = isLast ? full * duty + no * (1 - duty) : full
      totalP += p
      units.push({ id: c.id, load: isLast ? r1(duty) : 1, flow: r1(c.ratedFlow * (isLast ? duty : 1)), power: r1(p) })
    })
  } else {
    for (const c of chosen) {
      const m = machines.find(x => x.id === c.id)!
      const full = machinePower(c, 1, m.efficiency)
      totalP += full
      units.push({ id: c.id, load: 1, flow: c.ratedFlow, power: r1(full) })
    }
  }
  const L = totalP * 1.12
  return {
    units,
    totalPower: r1(L),
    specificPower: r3(L / Math.max(1, Math.min(Dplan, cap || Dplan))),
    costPerHour: r1(L * priceNow),
    pressureStdEst: 0.4,
  }
}

export function baselineSeries(
  demandVals: number[], configs: CompressorConfig[], machines: MachineState[], priceFn: (i: number, t: number) => number, t0: number,
): { power: number[]; spec: number[]; cost: number[] } {
  const power: number[] = [], spec: number[] = [], cost: number[] = []
  const order = [...configs].filter(c => {
    const m = machines.find(x => x.id === c.id)
    return m && m.status !== 'fault' && m.status !== 'maintenance'
  }).sort((a, b) => a.cascadeOrder - b.cascadeOrder)
  demandVals.forEach((d, i) => {
    const est = estimateBaselineForDemand(d, order, machines)
    power.push(r1(est.power))
    spec.push(r3(est.spec))
    cost.push(r1(est.power * priceFn(i, t0 + i * 60000)))
  })
  return { power, spec, cost }
}

function estimateBaselineForDemand(d: number, order: CompressorConfig[], machines: MachineState[]) {
  let cap = 0, k = 0
  for (const c of order) { cap += c.ratedFlow; k++; if (cap >= d) break }
  const chosen = order.slice(0, Math.min(k, order.length))
  let power = 0
  if (cap >= d && chosen.length) {
    const last = chosen[chosen.length - 1]
    const prev = cap - last.ratedFlow
    const duty = Math.max(0.05, Math.min(1, (d - prev) / last.ratedFlow))
    chosen.forEach((c, i) => {
      const m = machines.find(x => x.id === c.id)!
      const full = machinePower(c, 1, m.efficiency)
      const no = machinePower(c, 0, m.efficiency)
      power += i === chosen.length - 1 ? full * duty + no * (1 - duty) : full
    })
  } else {
    for (const c of chosen) {
      const m = machines.find(x => x.id === c.id)!
      power += machinePower(c, 1, m.efficiency)
    }
  }
  const pl = power * 1.12
  const supply = Math.min(d, cap) || 1
  return { power: pl, spec: pl / supply, cost: pl, feasible: cap >= d }
}

export { estimateBaselineForDemand }

export interface MachineEval {
  id: string
  status: MachineState['status']
  ratedFlow: number
  ratedPower: number
  health: number
  currentLoad: number
  planLoad: number
  ramp: number
  targetFlow: number
  targetPower: number
  specificPower: number      // 该机组在本方案工况下的单位产气能耗 kW/(Nm3/h)
  hypotheticalSpec: number   // 若单独用它当前时刻满开承担需求的单位能耗
  maxFlow: number            // 健康约束后的可用能力
  decision: 'run' | 'stop' | 'standby' | 'blocked'
  reasons: string[]
}

export function rankMachinesForPlan(ctx: OptimizerContext, plan: SchedulePlan): MachineEval[] {
  const combSpec = plan.totalPower / Math.max(1, plan.totalFlow)
  const runningCount = ctx.machines.filter(m => m.status === 'running').length
  return ctx.configs.map(c => {
    const m = ctx.machines.find(x => x.id === c.id)!
    const pu = plan.units.find(u => u.id === c.id)
    const maxL = effectiveMax(c, m)
    const maxFlow = Math.round(c.ratedFlow * maxL)
    const loadAloneNeed = Math.max(c.minLoad, Math.min(maxL, ctx.demand / c.ratedFlow))
    const hypoSpec = machinePower(c, loadAloneNeed, m.efficiency) / Math.max(1, c.ratedFlow * loadAloneNeed)
    const ramp = pu && m.status === 'running' ? pu.load - m.load : pu ? pu.load : 0
    let decision: MachineEval['decision']
    const reasons: string[] = []
    if (m.status === 'fault' || m.status === 'maintenance') {
      decision = 'blocked'
      reasons.push(m.status === 'fault' ? '故障硬约束：已从可调度集合隔离' : '检修计划占用：本周期不可调度')
      const others = ctx.configs.filter(x => x.id !== c.id).reduce((s, x) => {
        const mm = ctx.machines.find(q => q.id === x.id)!
        return mm.status === 'fault' || mm.status === 'maintenance' ? s : s + x.ratedFlow
      }, 0)
      reasons.push(`其余可用机组能力 ${others} Nm³/h，当前组合以 {${plan.units.map(u => u.id).join('+')}} 顶托需求，本台修复后将重新参与梯队轮换`)
      return fin()
    }
    if (pu) {
      decision = 'run'
      reasons.push(`单位能耗 ${(pu.power / Math.max(1, pu.flow)) <= combSpec * 1.0 ? `低于` : `高于`}方案均值：${(pu.power / Math.max(1, pu.flow)).toFixed(3)} vs ${combSpec.toFixed(3)} kW/(Nm³/h)`)
      if (m.status === 'running') {
        reasons.push(Math.abs(ramp) < 0.12 ? `维持运行，负荷仅调整 ${Math.round(ramp * 100)}%（避免大幅升降载冲击）` : `负荷上调 ${Math.round(ramp * 100)}% 承接预测需求`)
      } else {
        reasons.push(`新投入设备：启动成本 ¥${c.startCost}，健康度 ${Math.round(m.health)}（效率 ${Math.round(m.efficiency * 100)}%），为组合贡献 ${pu.flow} Nm³/h`)
      }
      if (m.health < 60) reasons.push(`健康度 ${Math.round(m.health)} 偏低，负荷上限压缩至 ${Math.round(maxL * 100)}%（当前计划 ${Math.round(pu.load * 100)}%）`)
    } else if (m.status === 'running') {
      decision = 'stop'
      const noload = Math.round(machinePower(c, 0, m.efficiency) * 10) / 10
      reasons.push(`退出运行可消除空载损耗 ${noload} kW（满载 空载比 ${Math.round(c.noLoadFrac * 100)}%）`)
      reasons.push(`需求 ${Math.round(ctx.demand)} 由 ${plan.units.map(u => u.id).join('+')} 梯队承担即可；停机磨损 ¥${c.startCost}/下次启动 vs 每小时省电费 ¥${Math.round(noload * ctx.priceNow * 10) / 10}`)
      if (m.runMinutes < c.minRunTime) reasons.push(`⚠ 连续运行 ${Math.round(m.runMinutes)}min 未达最小 ${c.minRunTime}min，建议延迟执行停机`)
    } else {
      decision = 'standby'
      if (m.stopMinutes < c.minStopTime) {
        reasons.push(`最小停机保护期（剩 ${Math.round(c.minStopTime - m.stopMinutes)}min），本周期不评估启动`)
      }
      reasons.push(hypoSpec > combSpec * 1.05
        ? `单机承担当前需求落在 ${Math.round(loadAloneNeed * 100)}% 负荷区，单位能耗 ${hypoSpec.toFixed(3)} 高于方案均值 ${combSpec.toFixed(3)}，投入不经济`
        : `单位能耗尚可（${hypoSpec.toFixed(3)}），但组合+储气罐顶托已够，作为梯队备用减少启停`)
      reasons.push(`保留为备用：额定 +${c.ratedFlow} Nm³/h（健康限流后 +${maxFlow}），启动后可用备用容量至 ${Math.max(0, Math.round((plan.totalFlow + maxFlow - ctx.demand) / Math.max(1, ctx.demand) * 100))}%`)
    }
    function fin(): MachineEval {
      return {
        id: c.id, status: m.status, ratedFlow: c.ratedFlow, ratedPower: c.ratedPower,
        health: Math.round(m.health), currentLoad: Math.round(m.load * 100), planLoad: pu ? Math.round(pu.load * 100) : 0,
        ramp: pu ? Math.round((pu.load - (m.status === 'running' ? m.load : 0)) * 100) : -Math.round(m.load * 100),
        targetFlow: pu ? Math.round(pu.flow) : 0, targetPower: pu ? Math.round(pu.power * 10) / 10 : 0,
        specificPower: pu ? Math.round(pu.power / Math.max(1, pu.flow) * 1000) / 1000 : 0,
        hypotheticalSpec: Math.round(hypoSpec * 1000) / 1000, maxFlow, decision, reasons,
      }
    }
    if (runningCount === 0 && !pu && decision === 'standby' && m.stopMinutes >= c.minStopTime) {
      reasons.push(`若需求继续上涨，它是最优先启动梯队之一`)
    }
    return fin()
  })
}

export interface PreDispatchAdvice {
  escalate: boolean
  inMinutes: number
  requiredFlow: number
  supplyGap: number
  recommendStarts: string[]
  reason: string
}

// 预测驱动的提前调度提示：当预测需求将超过当前运行机组可调能力时，提前给出增机建议
export function forecastPreDispatch(ctx: OptimizerContext): PreDispatchAdvice | null {
  const running = ctx.machines.filter(m => m.status === 'running')
  if (!running.length) return null
  const runCap = running.reduce((s, m) => {
    const c = ctx.configs.find(x => x.id === m.id)!
    return s + c.ratedFlow * effectiveMax(c, m)
  }, 0)
  const f = ctx.forecast
  const horizon = [
    { min: 30, val: f.f30 },
    { min: 60, val: f.f60 },
    { min: 240, val: f.f240 },
  ]
  const breach = horizon.find(h => h.val > runCap * 0.97)
  if (!breach) return null
  const rise = breach.val > ctx.demand * 1.06 || f.trend === 'up'
  if (!rise && breach.val <= runCap * 1.03) return null
  const standby = ctx.configs
    .map(c => ({ c, m: ctx.machines.find(x => x.id === c.id)! }))
    .filter(x => x.m.status === 'standby')
    .map(x => ({ ...x, spec: machinePower(x.c, 0.8, x.m.efficiency) / (x.c.ratedFlow * 0.8) }))
    .sort((a, b) => a.spec - b.spec)
  let need = breach.val - runCap
  const recommendStarts: string[] = []
  for (const s of standby) {
    if (need <= 0) break
    recommendStarts.push(s.c.id)
    need -= s.c.ratedFlow * effectiveMax(s.c, s.m)
  }
  const gap = Math.max(0, Math.round(breach.val - runCap))
  const starts = recommendStarts.join('、')
  const reason = starts
    ? `负荷预测显示 ${breach.min} 分钟内需求将升至 ${Math.round(breach.val)} Nm³/h，超出现有机组可调能力 ${Math.round(runCap)} Nm³/h（缺口 ${gap}），建议提前启动 ${starts} 承接`
    : `负荷预测显示 ${breach.min} 分钟内需求将升至 ${Math.round(breach.val)} Nm³/h，现有可调能力偏紧（缺口 ${gap}），请关注备用机组就绪状态`
  return {
    escalate: recommendStarts.length > 0,
    inMinutes: breach.min,
    requiredFlow: Math.round(breach.val),
    supplyGap: gap,
    recommendStarts,
    reason,
  }
}
