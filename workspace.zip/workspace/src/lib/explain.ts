import type { OptimizerContext, OptimizeResult, SchedulePlan, BaselineEstimate } from './types'

const pct = (v: number) => (v >= 0 ? '' : '-') + Math.abs(Math.round(v * 10) / 10) + '%'

export function compareVsBaseline(plan: SchedulePlan, baseline: BaselineEstimate, ctx: OptimizerContext) {
  const dp = plan.totalPower - baseline.totalPower
  const dpPct = baseline.totalPower > 0 ? (dp / baseline.totalPower) * 100 : 0
  const ds = plan.specificPower - baseline.specificPower
  const dsPct = baseline.specificPower > 0 ? (ds / baseline.specificPower) * 100 : 0
  const costYuan = dp * ctx.priceNow
  const pressureDropPct = baseline.pressureStdEst > 0 ? (1 - plan.pressureStdEst / baseline.pressureStdEst) * 100 : 0
  return {
    deltaPower: Math.round(dp * 10) / 10,
    deltaPowerPct: Math.round(dpPct * 10) / 10,
    deltaSpec: Math.round(ds * 1000) / 1000,
    deltaSpecPct: Math.round(dsPct * 10) / 10,
    saveYuanPerHour: Math.round(-costYuan * 10) / 10,
    pressureImprovePct: Math.round(pressureDropPct),
    baselinePower: baseline.totalPower,
    planPower: plan.totalPower,
  }
}

export interface Explanation {
  headline: string
  body: string[]
  reasons: string[]
  warnings: string[]
}

export function explainPlan(
  plan: SchedulePlan, baseline: BaselineEstimate, ctx: OptimizerContext, result: OptimizeResult,
): Explanation {
  const cmp = compareVsBaseline(plan, baseline, ctx)
  const sel = plan.units.map(u => u.id).join(' + ')
  const periodLabel = ctx.pricePeriod === 'peak' ? '峰' : ctx.pricePeriod === 'flat' ? '平' : '谷'
  const f30 = Math.round(ctx.forecast.f30)
  const body: string[] = []
  body.push(`当前实测用气需求 ${Math.round(ctx.demand)} Nm³/h，未来 30 分钟预测需求 ${f30} Nm³/h（趋势${ctx.forecast.trend === 'up' ? '上升' : ctx.forecast.trend === 'down' ? '下降' : '平稳'}，置信度 ${Math.round(ctx.forecast.confidence * 100)}%）。`)
  body.push(`系统推荐机组组合：${sel}，总供气 ${Math.round(plan.totalFlow)} Nm³/h，总功率 ${plan.totalPower} kW，小时电费约 ¥${plan.costPerHour}（${periodLabel}价 ¥${ctx.priceNow}/kWh）。`)
  if (cmp.saveYuanPerHour > 0.5) {
    body.push(`相比传统压控级联基准（约 ${cmp.baselinePower} kW），新方案总功率下降 ${Math.abs(cmp.deltaPowerPct)}%，单位产气能耗下降 ${Math.abs(cmp.deltaSpecPct)}%，压力波动预计下降 ${cmp.pressureImprovePct}%，预计节省电费 ¥${cmp.saveYuanPerHour}/h。`)
  } else if (cmp.saveYuanPerHour < -0.5) {
    body.push(`注意：为保稳定性，该方案功率较基准上升 ${Math.abs(cmp.deltaPowerPct)}%（约 ¥${Math.abs(cmp.saveYuanPerHour)}/h），换取约 ${plan.reserveRatio}% 的备用容量与更稳的管网压力。`)
  } else {
    body.push(`该方案与基准工况能耗基本持平，调度价值主要体现在启停优化与设备保护。`)
  }
  if (result.insufficient) {
    body.push(`⚠ 当前可用机组供气能力不足，缺口约 ${result.insufficient.gap} Nm³/h，罐压将在约 ${result.insufficient.minutesToLimit} 分钟内跌破安全下限。`)
  }

  const reasons: string[] = []
  const runningIds = ctx.machines.filter(m => m.status === 'running').map(m => m.id)
  const newStarts = plan.units.filter(u => !runningIds.includes(u.id))
  const toStop = ctx.machines.filter(m => m.status === 'running' && !plan.units.some(u => u.id === m.id))
  if (plan.units.every(u => u.load > 0.55)) {
    reasons.push(`所选机组均运行在 ${Math.round(Math.min(...plan.units.map(u => u.load)) * 100)}% 以上负荷的高效区间，避免大机小用。`)
  }
  const lowQ = plan.units.filter(u => u.load < 0.45)
  if (lowQ.length) {
    reasons.push(`${lowQ.map(u => `${u.id}（${Math.round(u.load * 100)}%）`).join('、')} 处于中低负荷，系统通过分配负荷而非停机来控制压力，减少启停损耗。`)
  }
  const worst = [...ctx.machines].filter(m => m.status !== 'fault' && m.status !== 'maintenance').sort((a, b) => a.health - b.health)[0]
  if (worst && worst.health < 75) {
    const inPlan = plan.units.find(u => u.id === worst.id)
    if (!inPlan) reasons.push(`${worst.id} 当前健康度仅 ${Math.round(worst.health)} 分（${worst.health < 60 ? '风险' : '注意'}区间），本方案不安排其运行，避免高负荷加速磨损。`)
    else if (inPlan.load < 0.6) reasons.push(`${worst.id} 健康度 ${Math.round(worst.health)} 分偏低的背景下，系统将其负荷压至 ${Math.round(inPlan.load * 100)}% 以平衡保供与保护。`)
  }
  const notSel = ctx.configs.filter(c => !plan.units.some(u => u.id === c.id))
    .filter(c => { const m = ctx.machines.find(x => x.id === c.id); return m && m.status !== 'fault' && m.status !== 'maintenance' })
  for (const c of notSel) {
    const m = ctx.machines.find(x => x.id === c.id)!
    const wouldSpec = (m.efficiency > 0 ? (c.ratedPower * (c.noLoadFrac + (1 - c.noLoadFrac - c.quadFrac) * (ctx.demand * 0.8 / c.ratedFlow) + c.quadFrac * Math.pow(ctx.demand * 0.8 / c.ratedFlow, 2)) / m.efficiency) : 0) / (c.ratedFlow * (ctx.demand * 0.8 / c.ratedFlow))
    const avgSpec = plan.totalPower / Math.max(1, plan.totalFlow)
    if (wouldSpec > avgSpec * 1.12) {
      reasons.push(`${c.id} 额定 ${c.ratedFlow} Nm³/h 在当前需求下将落入约 ${Math.round(ctx.demand * 0.8 / c.ratedFlow * 100)}% 低负荷区，预估单位能耗 ${Math.round(wouldSpec * 1000) / 1000} kW/(Nm³/h) 高于方案均值 ${Math.round(avgSpec * 1000) / 1000}，经济性不佳，保留为备用。`)
      break
    } else if (m.status === 'standby' && m.stopMinutes < c.minStopTime) {
      reasons.push(`${c.id} 处于最小停机时间保护期（还需 ${Math.round(c.minStopTime - m.stopMinutes)} 分钟），本时段不纳入启动集合。`)
      break
    } else if (m.health < 55) {
      reasons.push(`${c.id} 健康度 ${Math.round(m.health)} 属风险区间，仅作为极端工况下的保底备用。`)
      break
    }
  }
  if (newStarts.length) reasons.push(`新增启动 ${newStarts.map(u => u.id).join('、')}：预测需求高于当前供气能力，提前一步投运可避免罐压跌破下限后再被动响应。`)
  if (toStop.length) reasons.push(`停止 ${toStop.map(m => m.id).join('、')}：其空载功率约 ${Math.round(toStop.reduce((s, m) => s + ctx.configs.find(c => c.id === m.id)!.ratedPower * ctx.configs.find(c => c.id === m.id)!.noLoadFrac, 0))} kW，是传统压控模式下最常见的隐性浪费。`)
  if (plan.tankSetpoint >= 8.3 && ctx.pricePeriod !== 'peak') {
    const nextPeak = ctx.futurePrices.find(p => p.period === 'peak')
    reasons.push(`检测到 ${nextPeak ? `${nextPeak.hour} 时进入峰价` : '高价时段临近'}，提前将罐压蓄至 ${plan.tankSetpoint} bar，峰值期可用储气顶托部分负荷。`)
  }
  if (newStarts.length === 0 && toStop.length === 0) {
    reasons.push(`维持现有开机组合不变，仅重新分配负荷：这是启停成本最低的策略，避免频繁切换带来的冲击损耗。`)
  }

  const warnings: string[] = []
  if (plan.reserveRatio < 8) warnings.push(`备用容量仅 ${plan.reserveRatio}%，需求再涨 10% 可能触发起动备用机。`)
  if (plan.scores.cycling < 60) warnings.push(`本方案涉及 ${plan.startActions} 起 ${plan.stopActions} 停，启停偏多，若需求持续震荡将增加机械磨损。`)
  const hot = plan.units.filter(u => { const m = ctx.machines.find(x => x.id === u.id); return m && m.temp > 95 })
  if (hot.length) warnings.push(`${hot.map(u => u.id).join('、')} 排气温度超过 95℃，建议同步检查冷却系统。`)
  if (!plan.feasible) warnings.push('当前方案无法完全满足需求，存在供气缺口。')

  const headline = plan.feasible
    ? `推荐 ${sel}，综合评分 ${plan.totalScore} 分` + (cmp.saveYuanPerHour > 0 ? `，预计节省 ¥${cmp.saveYuanPerHour}/h` : '')
    : `供气紧张：${sel} 仍无法覆盖需求`
  return { headline, body, reasons: reasons.slice(0, 5), warnings }
}

import { machinePower } from './params'
import { healthBreakdown } from './health'
import type { MachineState } from './types'

export interface QA { q: string; a: string }

function maxCapOf(ctx: OptimizerContext): number {
  return ctx.configs.reduce((s, c) => {
    const m = ctx.machines.find(x => x.id === c.id)
    if (!m || m.status === 'fault' || m.status === 'maintenance') return s
    const cap = m.health < 40 ? Math.min(c.maxLoad, 0.7) : m.health < 60 ? Math.min(c.maxLoad, 0.85) : c.maxLoad
    return s + c.ratedFlow * cap
  }, 0)
}

// 每次调度结果都必须回答的“调度六问”（全部由当前实时数据动态生成）
export function explainSixQuestions(plan: SchedulePlan, baseline: BaselineEstimate, ctx: OptimizerContext, result: OptimizeResult): QA[] {
  const priceLabel = ctx.pricePeriod === 'peak' ? '峰' : ctx.pricePeriod === 'flat' ? '平' : '谷'
  const runningIds = ctx.machines.filter(m => m.status === 'running').map(m => m.id)
  const cmp = compareVsBaseline(plan, baseline, ctx)
  const unitOf = (id: string): MachineState => ctx.machines.find(x => x.id === id)!

  const sel = plan.units.map(u => {
    const m = unitOf(u.id)
    const spec = u.power / Math.max(1, u.flow)
    const tag = runningIds.includes(u.id) ? '维持运行' : '新投入'
    return `${u.id}（${tag}·负荷${Math.round(u.load * 100)}%·${Math.round(u.flow)}Nm³/h·${u.power}kW·单位能耗${spec.toFixed(3)}·健康${Math.round(m.health)}）`
  }).join('、') || '无（保供降级）'
  const q1 = `推荐组合 ${plan.units.map(u => u.id).join(' + ') || '—'}。${sel}。`
    + `目标：在满足预测需求 ${Math.round(Math.max(ctx.demand, ctx.forecast.f30))} Nm³/h 前提下${plan.objective}；`
    + `该组合单位产气能耗 ${plan.specificPower.toFixed(3)} kW/(Nm³/h)，综合评分 ${plan.totalScore}（${plan.units.length} 台协同，压力σ预估 ${plan.pressureStdEst} bar）。`

  const reasons: string[] = []
  for (const c of ctx.configs) {
    if (plan.units.some(u => u.id === c.id)) continue
    const m = unitOf(c.id)
    if (m.status === 'fault') { reasons.push(`${c.id} 处于故障隔离`); continue }
    if (m.status === 'maintenance') { reasons.push(`${c.id} 处于检修占用`); continue }
    if (m.status === 'standby' && m.stopMinutes < c.minStopTime) { reasons.push(`${c.id} 最小停机保护期（剩 ${Math.round(c.minStopTime - m.stopMinutes)} min）`); continue }
    const need = Math.max(c.minLoad, Math.min(c.maxLoad, ctx.demand / c.ratedFlow))
    const spec = machinePower(c, need, m.efficiency) / Math.max(1, c.ratedFlow * need)
    if (m.health < 60) reasons.push(`${c.id} 健康度仅 ${Math.round(m.health)}（${healthBreakdown(c, m).band}），高负荷将加速磨损，保留为梯队备用`)
    else if (spec > plan.specificPower * 1.08) reasons.push(`${c.id} 若投入在 ${Math.round(need * 100)}% 负荷区运行，单位能耗 ${spec.toFixed(3)} 高于方案均值 ${plan.specificPower.toFixed(3)}，经济性不佳`)
    else reasons.push(`${c.id} 能力与能耗均可用，但现组合+储气罐顶托已够，保留备用更利于减少启停`)
  }
  const q2 = reasons.length ? reasons.join('；') : '除所选机组外暂无可调度设备'

  const q3 = `总功率 ${plan.totalPower} kW，单位产气能耗 ${plan.specificPower.toFixed(3)} kW/(Nm³/h)，小时电费约 ¥${plan.costPerHour}（${priceLabel}价 ¥${ctx.priceNow}/kWh）。`
    + `相对传统级联基准 ${baseline.totalPower} kW：${cmp.deltaPowerPct <= 0
      ? `节能 ${Math.abs(cmp.deltaPowerPct).toFixed(1)}%，约节省 ¥${Math.max(0, cmp.saveYuanPerHour).toFixed(1)}/h`
      : `功率 +${cmp.deltaPowerPct.toFixed(1)}%（以能效换取稳定性，属保供必要投入）`}`

  const q4 = `当前管网压力 ${ctx.headerPressure.toFixed(2)} bar，罐压 ${ctx.tankPressure.toFixed(2)} bar；`
    + `本方案预测压力波动 σ≈${plan.pressureStdEst} bar，运行后管网预计 ${plan.headerPressureEst} bar（安全下限 ${ctx.safeMin} bar）。`
    + `判定：${ctx.headerPressure > ctx.safeMin && plan.headerPressureEst > ctx.safeMin + 0.2 ? '压力安全，裕度充足' : '压力偏紧，需以保供优先'}`

  const cap = maxCapOf(ctx)
  const reserveOk = plan.reserveRatio >= 8
  const q5 = `方案供气 ${plan.totalFlow} Nm³/h，对当前需求 ${Math.round(ctx.demand)} 保留备用容量 ${plan.reserveRatio}%；`
    + `全网可调度最大能力 ${Math.round(cap)} Nm³/h（含健康限流）。`
    + `判定：${reserveOk ? '备用容量充足（≥8%）' : '备用容量偏低，若需求继续上涨需立即增机'}`

  const riskUnits = plan.units.filter(u => unitOf(u.id).health < 60)
  const worst = [...ctx.machines].filter(m => m.status !== 'fault' && m.status !== 'maintenance').sort((a, b) => a.health - b.health)[0]
  const worstCfg = worst ? ctx.configs.find(c => c.id === worst.id)! : null
  const q6 = riskUnits.length
    ? `存在健康风险：${riskUnits.map(u => {
        const m = unitOf(u.id)
        const capL = m.health < 40 ? 0.7 : 0.85
        return `${u.id}（健康 ${Math.round(m.health)}，负荷限流至 ${Math.round(capL * 100)}%）`
      }).join('、')}。调度已压缩其负荷上限，建议近期优先保养。`
    : `本方案所选机组健康度均 ≥60，无突出健康风险；全局最需关注 ${worst ? `${worst.id}（${Math.round(worst.health)} 分）` : '无'}${worst && worstCfg && healthBreakdown(worstCfg, worst).advice[0] ? `，建议：${healthBreakdown(worstCfg, worst).advice[0]}` : ''}`

  return [
    { q: '为什么选择这些空压机？', a: q1 },
    { q: '为什么没有选择其他设备？', a: q2 },
    { q: '当前预计能耗是多少？', a: q3 },
    { q: '压力是否安全？', a: q4 },
    { q: '是否保留了足够备用容量？', a: q5 },
    { q: '是否存在设备健康风险？', a: q6 },
  ]
}

export interface RescheduleBefore {
  t: number
  demand: number; combo: string; power: number; cost: number; reserve: number
  flow: number; header: number; tank: number; specificPower: number; gap: number
  label: string; units: { id: string; load: number; flow: number; power: number }[]
}

export interface RescheduleExplanation {
  headline: string
  body: string[]
  reasons: string[]
  risk: string | null
  changes: { metric: string; before: string; after: string; delta: string; good: boolean }[]
}

export function explainReschedule(before: RescheduleBefore, after: SchedulePlan, ctx: OptimizerContext, result: OptimizeResult): RescheduleExplanation {
  const afterCmp = compareVsBaseline(after, result.baseline, ctx)
  const fid = (before.label.match(/A[1-4]/) || [])[0]
  const reasons: string[] = []
  const label = before.label

  if (fid) {
    const m = ctx.machines.find(x => x.id === fid)
    if (m && (m.status === 'fault' || m.status === 'maintenance')) {
      reasons.push(`${fid} ${m.status === 'fault' ? '故障' : '检修'}触发硬约束：已将其从可调度集合隔离，调度算法本周期不再使用该设备`)
    } else {
      reasons.push(`${fid} 状态变更已同步到调度器，重新纳入可调集合评估`)
    }
    const newStarts = after.units.filter(u => !before.units.some(b => b.id === u.id)).map(u => u.id)
    const newStops = before.units.filter(b => !after.units.some(u => u.id === b.id)).map(b => b.id)
    if (newStarts.length) reasons.push(`自动启动 ${newStarts.join('、')} 补足能力（事件后剩余可用机组需重新编组）`)
    if (newStops.length) reasons.push(`自动退出 ${newStops.join('、')}（其能力已被其他机组覆盖，减少空载与磨损）`)
  } else if (/需求/.test(label)) {
    const upm = label.match(/(\d+)/)
    reasons.push(`用气需求冲击${upm ? ` +${upm[1]}%` : ''}：调度目标由 ${Math.round(before.demand)} 上修至 ${Math.round(Math.max(ctx.demand, ctx.forecast.f30))} Nm³/h，需扩大机组组合或提升负荷`)
    const newStarts = after.units.filter(u => !before.units.some(b => b.id === u.id)).map(u => u.id)
    if (newStarts.length) reasons.push(`提前启动 ${newStarts.join('、')}，不等罐压触底再被动响应`)
  } else if (/罐|储气/.test(label)) {
    reasons.push(`储气罐压力骤降（${before.tank.toFixed(2)} → ${ctx.tankPressure.toFixed(2)} bar）：系统切换快速补压模式，提高目标产气并加大组合裕度`)
  } else if (/电价|峰/.test(label)) {
    reasons.push(`进入峰价时段（¥${ctx.priceNow}/kWh）：调度目标转向抑制高价电消耗，必要时降低罐压设定、减少高功率机组运行`)
  }

  const healthRisk = after.units.filter(u => (ctx.machines.find(x => x.id === u.id)?.health ?? 100) < 60).map(u => u.id)
  if (healthRisk.length) reasons.push(`${healthRisk.join('、')} 健康度偏低，重调度已按其健康上限压缩负荷，避免事件后过度使用`)

  const changes = [
    { metric: '机组组合', before: before.combo, after: after.units.map(u => u.id).join('+') || '保底', delta: '', good: true },
    { metric: '总功率', before: `${before.power} kW`, after: `${after.totalPower} kW`, delta: `${after.totalPower - before.power >= 0 ? '+' : ''}${(after.totalPower - before.power).toFixed(1)} kW`, good: after.totalPower <= before.power },
    { metric: '供气流量', before: `${before.flow} Nm³/h`, after: `${after.totalFlow} Nm³/h`, delta: `${after.totalFlow - before.flow >= 0 ? '+' : ''}${(after.totalFlow - before.flow).toFixed(0)}`, good: after.totalFlow >= before.flow * 0.9 },
    { metric: '单位能耗', before: `${before.specificPower.toFixed(3)}`, after: `${after.specificPower.toFixed(3)}`, delta: `${after.specificPower - before.specificPower >= 0 ? '+' : ''}${(after.specificPower - before.specificPower).toFixed(3)}`, good: after.specificPower <= before.specificPower * 1.03 },
    { metric: '管网压力预估', before: `${before.header.toFixed(2)} bar`, after: `${after.headerPressureEst} bar`, delta: '', good: after.headerPressureEst >= ctx.safeMin },
    { metric: '备用容量', before: `${before.reserve}%`, after: `${after.reserveRatio}%`, delta: `${after.reserveRatio - before.reserve >= 0 ? '+' : ''}${(after.reserveRatio - before.reserve).toFixed(1)}pt`, good: after.reserveRatio >= 8 },
  ]

  const headline = result.insufficient
    ? `事件「${label}」导致供气能力不足：缺口 ${result.insufficient.gap} Nm³/h，已启动降级预案`
    : `事件「${label}」已识别并自动重调度：新组合 ${after.units.map(u => u.id).join('+') || '保底'}（评分 ${after.totalScore}）`

  const body: string[] = []
  body.push(`事件发生在 ${new Date(before.t).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}，触发前组合 ${before.combo}（${before.power} kW，备用 ${before.reserve}%）。`)
  body.push(`重调度后采用 ${after.units.map(u => u.id).join(' + ') || '保底组合'}，供气 ${after.totalFlow} Nm³/h、功率 ${after.totalPower} kW、备用 ${after.reserveRatio}%、压力预估 ${after.headerPressureEst} bar（安全下限 ${ctx.safeMin}）。`)
  if (afterCmp.saveYuanPerHour !== 0) body.push(`相对传统级联基准，${afterCmp.saveYuanPerHour > 0 ? `仍节省 ¥${afterCmp.saveYuanPerHour.toFixed(1)}/h` : `功率上升 ¥${Math.abs(afterCmp.saveYuanPerHour).toFixed(1)}/h（以保供/稳定优先）`}。`)

  const risk = result.insufficient
    ? `供气缺口 ${result.insufficient.gap} Nm³/h，罐压约 ${result.insufficient.minutesToLimit} 分钟后触及安全下限。解决措施：${result.insufficient.measures.join('；')}。`
    : after.reserveRatio < 8
    ? `备用容量仅 ${after.reserveRatio}%，若再叠加一次冲击可能触发起动备用机，建议关注预测趋势。`
    : null

  return { headline, body, reasons, risk, changes }
}
