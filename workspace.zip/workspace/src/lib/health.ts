import type { CompressorConfig, MachineState } from './types'
import { machinePower } from './params'

export interface HealthDim {
  key: string
  label: string
  score: number
  weight: number
  detail: string
}

export interface HealthBreakdown {
  id: string
  score: number
  band: string
  dims: HealthDim[]
  advice: string[]
  maintenance: boolean
}

const clamp100 = (v: number) => Math.max(0, Math.min(100, v))
const r1 = (v: number) => Math.round(v * 10) / 10

export function healthBand(h: number): string {
  return h >= 90 ? '优秀' : h >= 75 ? '良好' : h >= 60 ? '注意' : h >= 40 ? '风险' : '严重风险'
}

// 健康度 → 调度成本系数：健康越低，单位能耗的调度代价越高（用于避免长期优先使用低健康设备）
export function dispatchCostFactor(m: MachineState): number {
  const gap = Math.max(0, 92 - m.health) / 92
  return 1 + Math.pow(gap, 1.6) * 0.35
}

export function healthBreakdown(c: CompressorConfig, m: MachineState): HealthBreakdown {
  const nominalSpec = c.ratedPower / c.ratedFlow
  const actualSpec = m.status === 'running' && m.flow > 5 ? m.power / m.flow : nominalSpec
  const specDev = (actualSpec - nominalSpec) / Math.max(0.02, nominalSpec)

  const runtimeScore = clamp100(100 - (m.hoursTotal / 40000) * 60)
  const cycleScore = clamp100(100 - (m.startsTotal / 9000) * 55)
  const tempScore = clamp100(100 - Math.max(0, m.temp - 75) * 2.4)
  const loadFrac = Math.min(1, m.highLoadMinutes / 1440)
  const loadScore = clamp100(100 - Math.max(0, loadFrac - 0.35) * 160)
  const powerScore = clamp100(100 - Math.max(0, specDev) * 260)
  const effRatio = m.efficiency / Math.max(0.01, c.baseEff)
  const effScore = clamp100((effRatio - 0.86) / (1 - 0.86) * 100)
  const anomalyScore = clamp100(100 - m.anomalies24h * 12)

  const dims: HealthDim[] = [
    { key: 'runtime', label: '累计运行磨损', score: r1(runtimeScore), weight: 0.18, detail: `累计 ${(m.hoursTotal / 1000).toFixed(1)}k h / 设计 40k h` },
    { key: 'cycling', label: '启停疲劳', score: r1(cycleScore), weight: 0.15, detail: `累计启停 ${m.startsTotal} 次 / 基准 9000 次` },
    { key: 'temperature', label: '温度历史', score: r1(tempScore), weight: 0.16, detail: `排气温度 ${Math.round(m.temp)}℃` },
    { key: 'load', label: '高负荷时长', score: r1(loadScore), weight: 0.14, detail: `24h 高负荷(>90%) ${Math.round(m.highLoadMinutes)} min` },
    { key: 'power', label: '功率偏离', score: r1(powerScore), weight: 0.17, detail: `单位功率 ${actualSpec.toFixed(3)} vs 额定 ${nominalSpec.toFixed(3)} kW/(Nm³/h)` },
    { key: 'efficiency', label: '效率衰减', score: r1(effScore), weight: 0.12, detail: `当前效率 ${Math.round(m.efficiency * 100)}% / 基准 ${Math.round(c.baseEff * 100)}%` },
    { key: 'anomaly', label: '异常事件', score: r1(anomalyScore), weight: 0.08, detail: `24h 异常 ${m.anomalies24h} 次` },
  ]

  const advice: string[] = []
  if (runtimeScore < 70) advice.push('运行时长接近设计寿命，建议纳入大修计划评估叶轮/轴承')
  if (cycleScore < 70) advice.push('启停次数偏多，建议优化调度以减少起停或延长最小运行时间')
  if (tempScore < 65) advice.push(`排气温度 ${Math.round(m.temp)}℃ 偏高，检查冷却器/冷却水/滤网`)
  if (loadScore < 70) advice.push('长期高负荷运行，建议轮换到低负荷时段或安排保养')
  if (powerScore < 70) advice.push(`单位能耗偏离额定 ${(specDev * 100).toFixed(1)}%，检查泄漏/阀件/主机效率`)
  if (effScore < 70) advice.push('效率较基准明显衰减，建议做能效标定与保养')
  if (anomalyScore < 70) advice.push('近期异常事件偏多，排查传感器与运行工况')

  const score = r1(m.health)
  const maintenance = score < 60 || (m.temp > 96 && m.status === 'running') || m.anomalies24h >= 3
  return { id: c.id, score, band: healthBand(score), dims, advice, maintenance }
}

export function healthSpecificPower(c: CompressorConfig, m: MachineState, load: number): number {
  const q = Math.max(c.minLoad, Math.min(c.maxLoad, load))
  return machinePower(c, q, m.efficiency) / Math.max(1, c.ratedFlow * q)
}
