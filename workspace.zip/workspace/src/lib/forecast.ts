import type { ForecastResult } from './types'

function holt(values: number[], alpha = 0.28, beta = 0.06): { level: number; trend: number; resid: number } {
  const n = values.length
  let level = values[0], trend = (values[Math.min(6, n - 1)] - values[0]) / 6
  let se = 0, cnt = 0
  for (let i = 1; i < n; i++) {
    const prevLevel = level
    level = alpha * values[i] + (1 - alpha) * (level + trend)
    trend = beta * (level - prevLevel) + (1 - beta) * trend
    const e = values[i] - (prevLevel + trend)
    se += e * e
    cnt++
  }
  return { level, trend, resid: Math.sqrt(se / Math.max(1, cnt - 1)) }
}

export function forecastDemand(
  demandSeries: number[],
  simTime: number,
  hourlyBase: (ms: number) => number,
): ForecastResult {
  const recent = demandSeries.slice(-240)
  const h = holt(recent)
  const kHorizon = 240
  const values: number[] = []
  for (let k = 1; k <= kHorizon; k++) {
    const ms = simTime + k * 60000
    const base = hourlyBase(ms)
    const w = Math.max(0.22, Math.exp(-k / 55))
    const trendVal = h.level + h.trend * k
    const blend = w * trendVal + (1 - w) * ((base + h.level) / 2)
    values.push(Math.max(60, blend))
  }
  const spread = h.resid
  const lower = values.map((v, i) => Math.max(40, v - 1.65 * spread * (1 + i / 180)))
  const upper = values.map((v, i) => v + 1.65 * spread * (1 + i / 180))
  const f30 = values[29], f60 = values[59], f240 = values[239]
  const last30 = recent.slice(-30)
  const lastMean = last30.reduce((a, b) => a + b, 0) / last30.length
  const next60 = values.slice(0, 60)
  const nextMean = next60.reduce((a, b) => a + b, 0) / next60.length
  const trendPct = (nextMean - lastMean) / lastMean * 100
  const trend: 'up' | 'down' | 'flat' = trendPct > 6 ? 'up' : trendPct < -6 ? 'down' : 'flat'
  const peak = Math.max(...values.slice(0, 240))
  const trough = Math.min(...values.slice(0, 240))
  const confidence = Math.max(0.55, Math.min(0.97, 1 - spread / Math.max(120, nextMean) * 1.35))
  return {
    horizon: Array.from({ length: kHorizon }, (_, i) => simTime + (i + 1) * 60000),
    values, lower, upper, f30, f60, f240, peak, trough, trend, trendPct, confidence,
    method: 'Holt双指数平滑 + 日内基线曲线混合加权',
  }
}
