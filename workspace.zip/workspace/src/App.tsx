import { useEffect, useRef, useState } from 'react'
import { HashRouter, NavLink, Routes, Route, useNavigate } from 'react-router-dom'
import { useStore, engine, DEMO_SCRIPT } from './store'
import Dashboard from './pages/Dashboard'
import Scheduling from './pages/Scheduling'
import Health from './pages/Health'
import ForecastPage from './pages/Forecast'
import Sandbox from './pages/Sandbox'
import Events from './pages/Events'
import Assistant from './pages/Assistant'
import Report from './pages/Report'
import Settings from './pages/Settings'
import { DemoSummaryModal } from './components/ui'

const NAV = [
  { path: '/', label: '智能驾驶舱', ico: '◉' },
  { path: '/scheduling', label: '智能调度', ico: '⇶' },
  { path: '/sandbox', label: '调度沙盘', ico: '⬡' },
  { path: '/forecast', label: '负荷预测', ico: '∿' },
  { path: '/health', label: '设备健康', ico: '♥' },
  { path: '/events', label: '事件仿真', ico: '⚡' },
  { path: '/assistant', label: 'AI 调度助手', ico: '✦' },
  { path: '/report', label: '调度报告', ico: '▤' },
  { path: '/settings', label: '系统设置', ico: '⚙' },
]

function fmtClock(ms: number): string {
  const d = new Date(ms)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`
}

function TopBar() {
  const station = useStore(s => s.station)
  const result = useStore(s => s.result)
  const running = useStore(s => s.running)
  const speed = useStore(s => s.speed)
  const setRunning = useStore(s => s.setRunning)
  const setSpeed = useStore(s => s.setSpeed)
  const adoptedKey = useStore(s => s.adoptedKey)
  const demoRunning = useStore(s => s.demo.running)
  const startDemo = useStore(s => s.startDemo)
  const priceNow = useStore(s => s.priceNow)
  const pricePeriod = useStore(s => s.pricePeriod)
  const savePct = result.baseline.totalPower > 0 ? Math.max(0, (result.baseline.totalPower - station.power) / result.baseline.totalPower * 100) : 0
  return (
    <div className="topbar">
      <div className="top-title">空压站运行监控</div>
      <div className="top-metrics">
        <div className="tm"><span>需求</span><b className="num">{Math.round(station.demand)}</b><span>Nm³/h</span></div>
        <div className="tm"><span>供气</span><b className="num">{Math.round(station.supply)}</b><span>Nm³/h</span></div>
        <div className="tm"><span>管网压力</span><b className="num" style={{ color: station.header < engine.safeMin ? 'var(--red)' : station.header < engine.safeMin + 0.4 ? 'var(--amber)' : 'inherit' }}>{station.header.toFixed(2)}</b><span>bar</span></div>
        <div className="tm"><span>罐压</span><b className="num">{station.tank.toFixed(2)}</b><span>bar</span></div>
        <div className="tm"><span>总功率</span><b className="num">{Math.round(station.power)}</b><span>kW</span></div>
        <div className="tm"><span>当前节能率</span><b className="num" style={{ color: 'var(--green)' }}>{adoptedKey === 'baseline' ? 'AI未接管' : `${savePct.toFixed(1)}%`}</b></div>
      </div>
      <div className="top-right">
        <span className="badge standby" title="本演示全部数据由数字孪生仿真生成，非真实工业现场">仿真数据</span>
        <span className={`badge ${pricePeriod === 'peak' ? 'danger' : pricePeriod === 'flat' ? 'warn' : 'info'}`}>{pricePeriod === 'peak' ? '峰' : pricePeriod === 'flat' ? '平' : '谷'}价 ¥{priceNow.toFixed(2)}</span>
        <span className={`badge ${adoptedKey === 'baseline' ? 'warn' : 'ok'}`}>{adoptedKey === 'baseline' ? '传统压控运行' : 'AI 调度接管'}</span>
        <span className="clock num">{fmtClock(engine.simTime)}</span>
        {!demoRunning && <button className="btn primary" onClick={() => startDemo('quick')}>▶ 30秒演示</button>}
        {!demoRunning && <button className="btn ghost" onClick={() => startDemo('full')}>完整演示 3 分钟</button>}
        <button className="btn ghost" onClick={() => setRunning(!running)}>{running ? '⏸ 暂停' : '▶ 运行'}</button>
        <select value={speed} onChange={e => setSpeed(parseFloat(e.target.value))} style={{ width: 74 }}>
          <option value={0.5}>0.5×</option>
          <option value={1}>1×</option>
          <option value={2}>2×</option>
          <option value={4}>4×</option>
        </select>
      </div>
    </div>
  )
}

function Toasts() {
  const alerts = useStore(s => s.alerts)
  const demo = useStore(s => s.demo)
  const [shown, setShown] = useState<{ id: string; level: string; message: string }[]>([])
  const seen = useRef<Set<string>>(new Set())
  useEffect(() => {
    const fresh = alerts.filter(a => !seen.current.has(a.id) && (a.level === 'critical' || a.level === 'warning')).slice(0, 3)
    if (!fresh.length) return
    fresh.forEach(a => seen.current.add(a.id))
    setShown(prev => [
      ...prev,
      ...fresh.map(a => ({ id: a.id, level: a.level, message: a.message })),
    ].slice(-3))
    const t = setTimeout(() => setShown(prev => prev.filter(x => !fresh.some(f => f.id === x.id))), 6500)
    return () => clearTimeout(t)
  }, [alerts])
  if (demo.running) return null
  return (
    <div className="toast-wrap">
      {shown.map(tst => (
        <div key={tst.id} className={`toast ${tst.level === 'critical' ? 'critical' : 'warning'}`}>
          <span style={{ color: tst.level === 'critical' ? 'var(--red)' : 'var(--amber)' }}>● </span>
          {tst.message}
        </div>
      ))}
    </div>
  )
}

function DemoBanner() {
  const demo = useStore(s => s.demo)
  const stopDemo = useStore(s => s.stopDemo)
  const tickCount = useStore(s => s.tickCount)
  const navigate = useNavigate()
  const NAVMAP = ['/', '/', '/forecast', '/scheduling', '/', '/sandbox', '/events', '/sandbox', '/assistant', '/']
  if (!demo.running && demo.summary) return <DemoSummaryModal summary={demo.summary} onClose={() => stopDemo()} />
  if (!demo.running) return null
  const ph = DEMO_SCRIPT[Math.max(0, demo.phase)]
  return (
    <>
      <div className="demo-banner">
        <span className="badge running" style={{ animation: 'breathe 1.6s infinite' }}>{demo.scale < 1 ? '30 秒演示' : '一键演示'} 阶段 {(demo.phase + 1)}/{DEMO_SCRIPT.length}</span>
        <span className="ph-label">{ph?.label}</span>
        <span className="ph-desc">{ph?.desc}</span>
        <span className="num" style={{ fontSize: 12 }}>tick {tickCount}</span>
        <button className="btn" onClick={() => navigate(NAVMAP[demo.phase] ?? '/')}>查看现场 →</button>
        <button className="btn ghost" onClick={stopDemo}>结束演示</button>
      </div>
    </>
  )
}

export default function App() {
  const running = useStore(s => s.running)
  const speed = useStore(s => s.speed)
  const tick = useStore(s => s.tick)
  const demoRunning = useStore(s => s.demo.running)
  useEffect(() => {
    if (!running && !demoRunning) return
    const ms = Math.max(220, 1050 / (demoRunning ? 2.4 : speed))
    const id = setInterval(() => tick(), ms)
    return () => clearInterval(id)
  }, [running, speed, tick, demoRunning])

  return (
    <HashRouter>
      <div className="app-shell">
        <aside className="sider">
          <div className="logo">
            <div className="logo-mark" style={{ fontSize: 19, color: 'var(--cyan)' }}>◉</div>
            <div>
              <div className="logo-name">AirMind</div>
              <div className="logo-sub">空压站智能调度中枢</div>
            </div>
          </div>
          <nav className="nav">
            {NAV.map(n => (
              <NavLink key={n.path} to={n.path} className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`} end={n.path === '/'} title={n.label}>
                <span className="ico">{n.ico}</span><span className="nav-label">{n.label}</span>
              </NavLink>
            ))}
          </nav>
          <div className="sider-foot">
            <div>运行模式 <b style={{ color: 'var(--cyan)' }}>仿真数字孪生</b></div>
            <div>赛题 02 · 多机协同智能调度</div>
          </div>
        </aside>
        <div className="main">
          <TopBar />
          <div className="content">
            <DemoBanner />
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/scheduling" element={<Scheduling />} />
              <Route path="/sandbox" element={<Sandbox />} />
              <Route path="/forecast" element={<ForecastPage />} />
              <Route path="/health" element={<Health />} />
              <Route path="/events" element={<Events />} />
              <Route path="/assistant" element={<Assistant />} />
              <Route path="/report" element={<Report />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </div>
        </div>
        <Toasts />
      </div>
    </HashRouter>
  )
}
