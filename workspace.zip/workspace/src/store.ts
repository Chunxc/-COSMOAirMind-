import { create } from 'zustand'
import { SimEngine } from './lib/sim'
import { forecastDemand } from './lib/forecast'
import { optimize, forecastPreDispatch } from './lib/optimizer'
import type { PreDispatchAdvice } from './lib/optimizer'
import { healthBreakdown } from './lib/health'
import { baselineSeries } from './lib/optimizer'
import { DEFAULT_CONFIGS, DEFAULT_PRICE, STATION_DEFAULTS, periodOfHour } from './lib/params'
import { answer } from './lib/chat'
import type {
  CompressorConfig, MachineState, PlanScores, PriceConfig, ForecastResult,
  OptimizeResult, SchedulePlan, SimEvent, PricePeriod, OptimizerContext,
} from './lib/types'

export const engine = new SimEngine({
  configs: DEFAULT_CONFIGS.map(c => ({ ...c })),
  price: { ...DEFAULT_PRICE },
  tankVolume: STATION_DEFAULTS.tankVolume,
  bandLow: STATION_DEFAULTS.bandLow,
  bandHigh: STATION_DEFAULTS.bandHigh,
  safeMin: STATION_DEFAULTS.safeMinPressure,
  headerOffset: STATION_DEFAULTS.headerOffset,
}, todayAt(Date.now() - 24 * 3600000))

function todayAt(ms: number): number {
  const d = new Date(ms)
  d.setSeconds(0, 0)
  return d.getTime()
}

engine.generateHistory(1440)

function headerStdOf(engine: SimEngine, fromMin: number, toMin: number): number {
  const arr = engine.history.filter(p => p.t >= fromMin && p.t <= toMin).map(p => p.header)
  if (arr.length < 12) return 0
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length
  return Math.sqrt(arr.reduce((s, v) => s + (v - mean) ** 2, 0) / arr.length)
}

const initBaselineSwitches = (() => {
  let switches = 0
  const h = engine.history
  const per = h.slice(15 * 60).concat(h.slice(-6 * 60))
  for (let i = 1; i < per.length; i++) {
    for (const id of Object.keys(per[i].perPower)) {
      const a = per[i - 1].perPower[id], b = per[i].perPower[id]
      const cfg = DEFAULT_CONFIGS.find(c => c.id === id)!
      if (Math.abs(a - b) > cfg.ratedPower * 0.24) switches++
    }
  }
  return Math.round(switches / per.length * 1440 / 2)
})()

const initBaselineStd = headerStdOf(engine, engine.history[15 * 60]?.t ?? 0, engine.simTime)

export interface ChatMsg { role: 'user' | 'ai'; text: string; t: number }
export interface Alert { id: string; level: 'critical' | 'warning' | 'info'; message: string; t: number }
export interface MaintReminder { id: string; level: 'critical' | 'warning'; message: string; t: number }
export interface PlanLogItem { t: number; from: string; to: string; trigger: string; scoreFrom: number; scoreTo: number }

interface DemoPhase { label: string; desc: string; dur: number; setup?: (s: AppState) => void; action?: 'baseline' | 'hold' | 'ai' | 'shockRamp' | 'shock18' | 'faultA2' | 'detect' | 'reschedule' | 'clearShock' | 'summary'; }

export const DEMO_SCRIPT: DemoPhase[] = [
  { label: '阶段 1 · 正常运行', desc: '空压站以传统压控级联方式运行，AI 在后台持续演算，界面展示实时负荷与设备状态', dur: 14, action: 'baseline' },
  { label: '阶段 2 · 当前负荷与设备状态', desc: '驾驶舱展示四台机组的运行状态、负载率、流量、功率、健康度与启停次数', dur: 12, action: 'hold' },
  { label: '阶段 3 · AI 预测需求上升', desc: '负荷预测识别未来 40 分钟用气需求持续上行，提前给出增机提示', dur: 13, action: 'shockRamp' },
  { label: '阶段 4 · 自动推荐新机组组合', desc: '多机协同调度算法基于预测需求/健康度/电价重算，给出新组合与负荷分配', dur: 14, action: 'ai' },
  { label: '阶段 5 · 优化前后能耗对比', desc: '对比当前方案与 AI 方案的总功率、单位能耗、电费、压力σ、备用与利用率', dur: 13 },
  { label: '阶段 6 · 模拟 A2 空压机故障', desc: 'A2 排气温度异常升高触发联锁停机，状态置为故障', dur: 10, action: 'faultA2' },
  { label: '阶段 7 · 系统自动识别故障', desc: 'AI 立即将 A2 移出可调度集合（硬约束），评估剩余能力与保供风险', dur: 10, action: 'detect' },
  { label: '阶段 8 · 自动重新调度', desc: '毫秒级重算机组组合与负荷分配，储气罐缓冲顶托切换过程', dur: 13, action: 'reschedule' },
  { label: '阶段 9 · AI 解释新调度策略', desc: '给出重调度原因、组合依据与调度六问，全部引用实时数据', dur: 13 },
  { label: '阶段 10 · 节能效果与系统稳定性', desc: '汇总节电、节费、压力稳定性提升与不必要启停减少', dur: 9, action: 'summary' },
]


export interface EventSnapshot {
  t: number; demand: number; combo: string; power: number; cost: number
  reserve: number; score: number; label: string
  flow: number; header: number; tank: number; specificPower: number
  units: { id: string; load: number; flow: number; power: number }[]
  gap: number
}

export interface AppState {
  configs: CompressorConfig[]
  priceCfg: PriceConfig
  weights: Record<keyof PlanScores, number>
  machines: MachineState[]
  station: { t: number; demand: number; header: number; tank: number; power: number; supply: number }
  forecast: ForecastResult
  result: OptimizeResult
  tickCount: number
  running: boolean
  speed: number
  adoptedKey: 'auto' | 'A' | 'B' | 'C' | 'baseline'
  demandShock: { pct: number; minsLeft: number }
  forcePeakMins: number
  tankPrechargeBonus: number
  events: SimEvent[]
  alerts: Alert[]
  preDispatch: PreDispatchAdvice | null
  maintenance: MaintReminder[]
  setDemandOverride: (v: number | null) => void
  setTankSetpointOverride: (v: number | null) => void
  setPriceOverride: (v: number | null) => void
  setMachineMode: (id: string, mode: 'auto' | 'fault' | 'maintenance') => void
  chat: ChatMsg[]
  planLog: PlanLogItem[]
  savings: { kwh: number; yuan: number; aiSwitches: number }
  baselineMetrics: { estSwitchesPerDay: number; headerStd: number; powerNow: number }
  demo: { running: boolean; phase: number; log: string[]; summary: null | DemoSummary; startT: number; scale: number }
  lastRunningKey: string
  anomalyState: Record<string, number>
  priceNow: number
  pricePeriod: PricePeriod
  demandOverride: number | null
  tankSetpointOverride: number | null
  priceOverride: number | null
  lastEventSnapshot: EventSnapshot | null

  tick: () => void
  buildCtx: () => OptimizerContext
  adopt: (k: 'auto' | 'A' | 'B' | 'C' | 'baseline') => void
  injectDemandShock: (pct: number, mins: number, label: string) => void
  toggleFault: (id: string) => void
  toggleMaintenance: (id: string) => void
  triggerTankDrop: () => void
  triggerForcePeak: () => void
  rescheduleNow: () => void
  clearEvents: () => void
  resetAll: () => void
  updateConfig: (id: string, patch: Partial<CompressorConfig>) => void
  updatePrice: (patch: Partial<PriceConfig>) => void
  updateWeights: (patch: Partial<Record<keyof PlanScores, number>>) => void
  setRunning: (v: boolean) => void
  setSpeed: (v: number) => void
  chatSend: (text: string) => void
  startDemo: (mode?: 'full' | 'quick') => void
  stopDemo: () => void
  pushAlert: (level: Alert['level'], message: string) => void
}

export interface DemoSummary {
  kwh: number; yuan: number; switchCuts: number; pressureImprovePct: number
  windowMin: number; aiStd: number; baseStd: number; avgPowerAi: number; avgPowerBase: number
}


function snapBefore(label: string): EventSnapshot {
  const st = useStore.getState()
  const p = st.result.plans.find(x => x.key === st.result.recommended) ?? st.result.current
  return {
    t: engine.simTime, demand: st.station.demand, combo: p.units.map(u => u.id).join('+') || '—',
    power: p.totalPower, cost: p.costPerHour, reserve: p.reserveRatio, score: p.totalScore, label,
    flow: p.totalFlow, header: st.station.header, tank: st.station.tank, specificPower: p.specificPower,
    units: p.units.map(u => ({ id: u.id, load: u.load, flow: u.flow, power: u.power })),
    gap: st.result.insufficient?.gap ?? 0,
  }
}

function buildForecast(): ForecastResult {
  return forecastDemand(engine.history.map(p => p.demand), engine.simTime, ms => engine.demandAt(ms))
}

function buildCtxImpl(weights: Record<keyof PlanScores, number>, priceCfg: PriceConfig, forcePeakMins: number, forecast: ForecastResult, priceOverride: number | null = null): OptimizerContext {
  const simTime = engine.simTime
  const hourOf = (ms: number) => new Date(ms).getHours()
  let priceNow: number, periodNow: PricePeriod
  if (forcePeakMins > 0) { priceNow = priceCfg.peak; periodNow = 'peak' }
  else { periodNow = periodOfHour(priceCfg, hourOf(simTime)); priceNow = periodNow === 'peak' ? priceCfg.peak : periodNow === 'flat' ? priceCfg.flat : priceCfg.valley }
  if (priceOverride != null && Number.isFinite(priceOverride)) priceNow = Math.max(0.05, Math.min(3, priceOverride))
  const futurePrices: { hour: number; price: number; period: PricePeriod }[] = []
  for (let k = 1; k <= 6; k++) {
    const ms = simTime + k * 3600000
    let per = periodOfHour(priceCfg, hourOf(ms))
    if (forcePeakMins > k * 60) per = 'peak'
    futurePrices.push({ hour: hourOf(ms), price: per === 'peak' ? priceCfg.peak : per === 'flat' ? priceCfg.flat : priceCfg.valley, period: per })
  }
  return {
    configs: engine.configs,
    machines: engine.machines,
    demand: engine.demandNow,
    forecast,
    priceNow,
    pricePeriod: periodNow,
    futurePrices,
    headerPressure: engine.header,
    tankPressure: engine.tank,
    tankVolume: engine.tankVolume,
    safeMin: engine.safeMin,
    weights,
    priceCfg,
    startedRecentlyIds: engine.machines.filter(m => m.runMinutes < 6).map(m => m.id),
    simTimeMs: simTime,
  }
}

function stationSnapshot() {
  return {
    t: engine.simTime,
    demand: engine.demandNow,
    header: engine.header,
    tank: engine.tank,
    power: engine.machines.reduce((s, m) => s + m.power, 0),
    supply: engine.machines.reduce((s, m) => s + m.flow, 0),
  }
}

const initForecast = buildForecast()
const initCtx = buildCtxImpl(
  { energy: 0.30, stability: 0.20, cycling: 0.12, health: 0.18, reserve: 0.10, efficiency: 0.10 },
  { ...DEFAULT_PRICE }, 0, initForecast,
)
const initResult = optimize(initCtx)

export const useStore = create<AppState>((set, get) => ({
  configs: engine.configs,
  priceCfg: { ...DEFAULT_PRICE },
  weights: { energy: 0.30, stability: 0.20, cycling: 0.12, health: 0.18, reserve: 0.10, efficiency: 0.10 },
  machines: engine.snapshotMachines(),
  station: stationSnapshot(),
  forecast: initForecast,
  result: initResult,
  tickCount: 0,
  running: true,
  speed: 1,
  adoptedKey: 'baseline',
  demandShock: { pct: 0, minsLeft: 0 },
  forcePeakMins: 0,
  tankPrechargeBonus: 0,
  events: [],
  alerts: [],
  preDispatch: null,
  maintenance: [],
  chat: [{ role: 'ai', text: `你好，我是 AirMind 空压站调度智能体。\n当前实测需求 **${Math.round(engine.demandNow)} Nm³/h**，AI 建议采用 **${initResult.recommended} 综合最优方案（${(initResult.plans.find(p => p.key === initResult.recommended)?.units ?? []).map(u => u.id).join(' + ')}）**，综合评分 ${initResult.plans.find(p => p.key === initResult.recommended)?.totalScore ?? '-'}。\n可以点击右侧卡片直接提问，比如「为什么不开A4」「能不能省多少钱」。`, t: Date.now() }],
  planLog: [],
  savings: { kwh: 0, yuan: 0, aiSwitches: 0 },
  baselineMetrics: { estSwitchesPerDay: initBaselineSwitches, headerStd: initBaselineStd, powerNow: 0 },
  demo: { running: false, phase: -1, log: [], summary: null, startT: 0, scale: 1 },
  priceNow: initCtx.priceNow,
  pricePeriod: initCtx.pricePeriod,
  demandOverride: null,
  tankSetpointOverride: null,
  priceOverride: null,
  lastEventSnapshot: null,
  lastRunningKey: engine.machines.filter(m => m.status === 'running').map(m => m.id).sort().join('+'),
  anomalyState: {},

  buildCtx: () => buildCtxImpl(get().weights, get().priceCfg, get().forcePeakMins, get().forecast, get().priceOverride),

  tick: () => {
    const s = get()
    if (s.demo.running && s.demo.phase < 0) set({ demo: { ...s.demo, phase: 0 } })
    const mode = s.adoptedKey === 'baseline' ? 'baseline' : 'ai'
    let planTargets: Record<string, number> = {}
    let tankSetpoint = 8.0
    let activePlan: SchedulePlan | null = null
    if (mode === 'ai') {
      const key = s.adoptedKey === 'auto' ? s.result.recommended : s.adoptedKey
      activePlan = s.result.plans.find(p => p.key === key) ?? s.result.current
      if (activePlan && activePlan.feasible) {
        planTargets = Object.fromEntries(activePlan.units.map(u => [u.id, u.load]))
        tankSetpoint = activePlan.tankSetpoint
      } else {
        const runing = engine.machines.filter(m => m.status === 'running').map(m => [m.id, Math.max(m.load, engine.configs.find(c => c.id === m.id)!.minLoad)])
        if (runing.length) {
          planTargets = Object.fromEntries(runing)
        } else {
          const pick = engine.configs.filter(c => engine.machines.find(m => m.id === c.id && m.status === 'standby' && m.stopMinutes >= c.minStopTime)).sort((a, b) => a.ratedFlow - b.ratedFlow).slice(0, 4)
          const cover = (pick.length ? pick : engine.configs).reduce((s, c) => s + c.ratedFlow, 0)
          const need = Math.max(engine.demandNow * 1.01, cover)
          planTargets = Object.fromEntries((pick.length ? pick : engine.configs).map(c => [c.id, Math.min(c.maxLoad, Math.max(c.minLoad, need / cover * 0.5))]))
        }
        tankSetpoint = 8.5
      }
    }
    const shock = s.demandShock.pct / 100
    const hourOffset = s.forcePeakMins > 0 ? 6 : 0
    if (s.tankSetpointOverride != null) tankSetpoint = s.tankSetpointOverride
    engine.tick({ mode, planTargets, tankSetpoint, demandShock: shock, hourOffset, demandOverride: s.demandOverride })

    if (s.demandShock.minsLeft > 0) {
      const left = s.demandShock.minsLeft - 1
      set(st => ({ demandShock: { pct: left > 0 ? st.demandShock.pct : 0, minsLeft: Math.max(0, left) } }))
    }
    if (s.forcePeakMins > 0) set(st => ({ forcePeakMins: Math.max(0, st.forcePeakMins - 1) }))

    const forecast = buildForecast()
    const ctx = buildCtxImpl(get().weights, get().priceCfg, get().forcePeakMins, forecast, get().priceOverride)
    const result = optimize(ctx)

    const newRunKey = engine.machines.filter(m => m.status === 'running').map(m => m.id).sort().join('+') || '—'
    let planLog = get().planLog
    const savings = { ...get().savings }
    const baseNow = mode === 'ai' ? result.baseline.totalPower : stationSnapshot().power
    if (mode === 'ai') {
      const dtKwh = Math.max(0, (result.baseline.totalPower - stationSnapshot().power)) / 60
      savings.kwh += dtKwh
      savings.yuan += dtKwh * ctx.priceNow
    }
    if (newRunKey !== get().lastRunningKey) {
      const scoreTo = mode === 'ai' ? (result.plans.find(p => p.key === (get().adoptedKey === 'auto' ? result.recommended : get().adoptedKey))?.totalScore ?? 0) : 0
      planLog = [{
        t: engine.simTime, from: get().lastRunningKey, to: newRunKey,
        trigger: mode === 'ai' ? 'AI 调度执行' : '压力级联控制动作',
        scoreFrom: 0, scoreTo,
      }, ...planLog].slice(0, 60)
      if (mode === 'ai') savings.aiSwitches += (newRunKey === '—' ? 0 : Math.abs(newRunKey.split('+').length - get().lastRunningKey.split('+').length) || 1)
      set({ lastRunningKey: newRunKey })
    }

    const alerts = [...get().alerts]
    const push = (level: Alert['level'], key: string, message: string) => {
      if (alerts.some(a => a.id === key && a.t > engine.simTime - 1200000)) return
      alerts.unshift({ id: key, level, message, t: engine.simTime })
    }
    const st = stationSnapshot()
    if (st.header < engine.safeMin) push('critical', 'header-critical', `管网压力 ${st.header.toFixed(2)} bar 已低于安全下限 ${engine.safeMin} bar`)
    else if (st.header < engine.safeMin + 0.4) push('warning', 'header-low', `管网压力 ${st.header.toFixed(2)} bar 接近安全下限，保供优先`)
    if (result.insufficient) push('critical', 'gap', `供气能力不足：缺口 ${result.insufficient.gap} Nm³/h，约 ${result.insufficient.minutesToLimit} 分钟内触限`)
    for (const m of engine.machines) {
      if (m.status === 'running' && m.temp > 100) push('warning', `temp-${m.id}`, `${m.id} 排气温度 ${Math.round(m.temp)}℃ 超限，建议检查冷却系统`)
      if (m.status !== 'fault' && m.health < 40) push('warning', `health-${m.id}`, `${m.id} 健康度 ${Math.round(m.health)} 进入严重风险区间，负荷上限已自动压缩`)
    }

    const preDispatch = forecastPreDispatch(ctx)
    if (preDispatch && preDispatch.escalate && (ctx.forecast.trend === 'up' || preDispatch.supplyGap > 0)) {
      push('warning', 'pre-dispatch', `预测调度提示：${preDispatch.reason}`)
    }
    const maint: MaintReminder[] = []
    const hist = engine.history
    const pastIdx = hist.length - 31
    for (const m of engine.machines) {
      if (m.status === 'fault' || m.status === 'maintenance') continue
      const cfg = engine.configs.find(c => c.id === m.id)!
      const hb = healthBreakdown(cfg, m)
      const pastHealth = pastIdx >= 0 ? (hist[pastIdx].health[m.id] ?? m.health) : m.health
      const drop30 = pastHealth - m.health
      if (drop30 >= 2.0) {
        maint.push({ id: m.id, level: 'critical', message: `${m.id} 健康度 30min 内骤降 ${drop30.toFixed(1)} 分（现 ${Math.round(m.health)} · ${hb.band}），维护提醒：${hb.advice[0] ?? '尽快安排停机检查'}`, t: engine.simTime })
        push('critical', `maint-${m.id}`, `${m.id} 健康度异常下降 ${drop30.toFixed(1)} 分，建议优先检修`)
      } else if (drop30 >= 0.6 || hb.maintenance) {
        maint.push({ id: m.id, level: 'warning', message: `${m.id} 健康度 ${Math.round(m.health)}（${hb.band}）${drop30 >= 0.6 ? `，30min 下降 ${drop30.toFixed(1)} 分` : ''}${hb.advice.length ? '：' + hb.advice[0] : ''}`, t: engine.simTime })
        push('warning', `maint-${m.id}`, `${m.id} 健康度进入关注区（${Math.round(m.health)} 分），建议安排保养`)
      }
    }

    set({
      forecast, result,
      machines: engine.snapshotMachines(),
      station: st,
      priceNow: ctx.priceNow,
      pricePeriod: ctx.pricePeriod,
      preDispatch,
      maintenance: maint,
      alerts: alerts.slice(0, 24),
      planLog, savings,
      tickCount: get().tickCount + 1,
      baselineMetrics: { estSwitchesPerDay: initBaselineSwitches, headerStd: initBaselineStd, powerNow: result.baseline.totalPower },
    })
  },

  adopt: (k) => {
    set({ adoptedKey: k })
    get().pushAlert('info', `已切换调度模式：${k === 'baseline' ? '传统压控（AI 不接管）' : k === 'auto' ? 'AI 自动跟随方案C' : `固定采用方案${k}`}`)
  },

  injectDemandShock: (pct, mins, label) => {
    const snap = snapBefore(label)
    set(st => ({
      lastEventSnapshot: snap,
      demandShock: { pct: st.demandShock.pct + pct, minsLeft: Math.max(st.demandShock.minsLeft, mins) },
      events: [{
        id: `d-${Date.now()}`, label, type: 'demand',
        detail: `用气需求突增 ${pct}%（持续约 ${mins} 分钟），当前预测 30 分钟需求将上修`, t: engine.simTime, active: true,
      }, ...st.events].slice(0, 40) as SimEvent[],
    }))
    get().pushAlert('warning', `事件注入：${label}`)
    get().rescheduleNow()
  },

  toggleFault: (id) => {
    const m = engine.machines.find(x => x.id === id)!
    const isFault = m.status === 'fault'
    const snap = snapBefore(`${id} ${isFault ? '恢复' : '故障'}`)
    engine.setFault(id, !isFault)
    set(st => ({
      lastEventSnapshot: snap,
      events: [{
        id: `f-${id}-${Date.now()}`, label: `${id} ${isFault ? '故障恢复' : '发生故障'}`, type: isFault ? 'recover' : 'fault',
        detail: isFault ? `${id} 完成抢修，重新纳入可调度集合` : `${id} 排气温度/振动异常触发联锁停机，已从可调度集合移除`, t: engine.simTime, active: !isFault,
      }, ...st.events].slice(0, 40) as SimEvent[],
    }))
    get().pushAlert(isFault ? 'info' : 'critical', isFault ? `${id} 已恢复运行能力` : `${id} 发生故障，触发自动重调度`)
    get().rescheduleNow()
  },

  toggleMaintenance: (id) => {
    const m = engine.machines.find(x => x.id === id)!
    const isMaint = m.status === 'maintenance'
    engine.setMaintenance(id, !isMaint)
    set(st => ({
      events: [{
        id: `m-${id}-${Date.now()}`, label: `${id} ${isMaint ? '检修完成' : '转入检修'}`, type: isMaint ? 'recover' : 'info',
        detail: isMaint ? `${id} 保养完成，健康度回升` : `${id} 进入计划检修窗口，本时段不可调度`, t: engine.simTime, active: !isMaint,
      }, ...st.events].slice(0, 40) as SimEvent[],
    }))
    get().pushAlert('info', isMaint ? `${id} 检修完成恢复待机` : `${id} 已安排检修`)
    get().rescheduleNow()
  },

  triggerTankDrop: () => {
    const snap = snapBefore('储气罐压力骤降')
    engine.tank = Math.max(6.2, engine.tank - 0.75)
    set(st => ({
      lastEventSnapshot: snap,
      events: [{ id: `t-${Date.now()}`, label: '储气罐压力骤降', type: 'tank', detail: '下游管网泄漏/阀门误开，罐压瞬时下降 0.75 bar，系统进入快速补压模式', t: engine.simTime, active: true }, ...st.events].slice(0, 40) as SimEvent[],
    }))
    get().pushAlert('critical', '储气罐压力骤降，AI 正在重调度补压')
    get().rescheduleNow()
  },

  triggerForcePeak: () => {
    const snap = snapBefore('电价进入峰段')
    set(st => ({
      lastEventSnapshot: snap,
      forcePeakMins: 60,
      events: [{ id: `p-${Date.now()}`, label: '电价进入峰段', type: 'price', detail: `电网进入峰价时段（${st.priceCfg.peak.toFixed(2)} 元/kWh），优化目标自动切换为抑制高价电`, t: engine.simTime, active: true }, ...st.events].slice(0, 40) as SimEvent[],
    }))
    get().pushAlert('info', '电价进入峰段，调度策略已切换经济性优先')
    get().rescheduleNow()
  },

  clearEvents: () => set({ demandShock: { pct: 0, minsLeft: 0 }, forcePeakMins: 0, events: [] }),

  resetAll: () => {
    engine.configs.forEach((c, i) => Object.assign(c, DEFAULT_CONFIGS[i]))
    engine.tank = 8.0
    engine.faultsActive = {}
    engine.machines.forEach(m => { m.status = 'standby'; m.loaded = false; m.load = 0; m.temp = 27 })
    set(st => ({
      configs: [...engine.configs.map(c => ({ ...c }))],
      adoptedKey: 'baseline', demandShock: { pct: 0, minsLeft: 0 }, forcePeakMins: 0,
      events: [], alerts: [], savings: { kwh: 0, yuan: 0, aiSwitches: 0 },
      demo: { running: false, phase: -1, log: [], summary: null, startT: 0, scale: 1 },
      priceCfg: { ...DEFAULT_PRICE },
      weights: st.weights,
    }))
    get().pushAlert('info', '系统已重置：恢复默认参数与传统运行模式')
  },

  updateConfig: (id, patch) => {
    const c = engine.configs.find(x => x.id === id)
    if (!c) return
    Object.assign(c, patch)
    set({ configs: engine.configs.map(x => ({ ...x })) })
  },

  updatePrice: (patch) => {
    set(st => {
      const nc = { ...st.priceCfg, ...patch }
      engine.price = nc
      return { priceCfg: nc }
    })
  },

  updateWeights: (patch) => set(st => ({ weights: { ...st.weights, ...patch } })),

  rescheduleNow: () => { get().tick() },

  setDemandOverride: (v) => { set({ demandOverride: v }); get().rescheduleNow() },
  setTankSetpointOverride: (v) => { set({ tankSetpointOverride: v }); get().rescheduleNow() },
  setPriceOverride: (v) => { set({ priceOverride: v }); get().rescheduleNow() },
  setMachineMode: (id, mode) => {
    const cur = engine.machines.find(m => m.id === id)?.status
    if (mode === 'fault') engine.setFault(id, true)
    else if (mode === 'maintenance') engine.setMaintenance(id, true)
    else {
      if (cur === 'fault') engine.setFault(id, false)
      else if (cur === 'maintenance') engine.setMaintenance(id, false)
    }
    set(st => ({
      events: [{
        id: `sm-${id}-${Date.now()}`, label: `${id} 手动${mode === 'fault' ? '停机' : mode === 'maintenance' ? '转检修' : '恢复'}`,
        type: mode === 'auto' ? 'recover' : 'info', detail: `沙盘手动设置 ${id} 状态为「${mode === 'fault' ? '故障' : mode === 'maintenance' ? '检修' : '自动/待机'}」并触发重调度`,
        t: engine.simTime, active: mode !== 'auto',
      }, ...st.events].slice(0, 40) as SimEvent[],
    }))
    get().pushAlert(mode === 'fault' ? 'critical' : 'info', `${id} 已手动设置为${mode === 'fault' ? '故障' : mode === 'maintenance' ? '检修' : '自动'}`)
    get().rescheduleNow()
  },

  setRunning: (v) => set({ running: v }),
  setSpeed: (v) => set({ speed: v }),

  pushAlert: (level, message) => {
    set(st => ({ alerts: [{ id: `a-${Date.now()}-${Math.random()}`, level, message, t: engine.simTime }, ...st.alerts].slice(0, 24) }))
  },

  chatSend: (text) => {
    const q: ChatMsg = { role: 'user', text, t: Date.now() }
    const sn = get()
    const snapCtx = buildCtxImpl(sn.weights, sn.priceCfg, sn.forcePeakMins, sn.forecast, sn.priceOverride)
    const adopted = sn.adoptedKey === 'auto' ? 'C' : sn.adoptedKey
    const adoptedPlan = adopted === 'baseline' ? sn.result.current : sn.result.plans.find(p => p.key === adopted) ?? null
    const a: ChatMsg = { role: 'ai', text: answer(text, { ctx: snapCtx, result: sn.result, adoptedPlan }), t: Date.now() }
    set(st => ({ chat: [...st.chat, q, a].slice(-60) }))
  },

  startDemo: (mode: 'full' | 'quick' = 'full') => {
    const scale = mode === 'quick' ? 0.25 : 1
    const title = mode === 'quick' ? '▶ 30 秒极速演示开始（共 10 阶段）' : '▶ 一键演示开始（共 10 阶段）'
    set({
      demo: { running: true, phase: 0, log: [`${fmtTime(engine.simTime)} ${title}`], summary: null, startT: engine.simTime, scale },
      speed: mode === 'quick' ? 6 : 2.4, running: true,
    })
    runDemoPhase(get, set, 0)
  },

  stopDemo: () => {
    demoTimers.forEach(clearTimeout)
    demoTimers = []
    engine.setFault('A2', false)
    set({ demo: { running: false, phase: -1, log: get().demo.log, summary: get().demo.summary, startT: 0, scale: 1 }, speed: 1, demandShock: { pct: 0, minsLeft: 0 } })
  },
}))

function fmtTime(ms: number): string {
  const d = new Date(ms)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

let demoTimers: ReturnType<typeof setTimeout>[] = []

function runDemoPhase(get: () => AppState, set: (p: Partial<AppState> | ((s: AppState) => Partial<AppState>)) => void, idx: number) {
  const st0 = get()
  if (idx >= DEMO_SCRIPT.length) {
    st0.stopDemo()
    return
  }
  const ph = DEMO_SCRIPT[idx]
  set({ demo: { running: true, phase: idx, log: [...get().demo.log, `${fmtTime(engine.simTime)} ${ph.label}：${ph.desc}`], summary: get().demo.summary, startT: get().demo.startT, scale: get().demo.scale } })
  if (ph.action === 'baseline') { set({ adoptedKey: 'baseline' }); engine.setFault('A2', false) }
  if (ph.action === 'shockRamp' || ph.action === 'shock18') set({ demandShock: { pct: 16 + Math.random() * 6, minsLeft: 600 } })
  if (ph.action === 'faultA2') { if (engine.machines.find(m => m.id === 'A2')!.status !== 'fault') get().toggleFault('A2') }
  if (ph.action === 'ai') set({ adoptedKey: 'auto' })
  if (ph.action === 'reschedule') get().rescheduleNow()
  if (ph.action === 'summary') computeDemoSummary(get, set, idx)
  if (ph.action === 'clearShock') set({ demandShock: { pct: 0, minsLeft: 0 } })
  const scale = get().demo.scale || 1
  const t = setTimeout(() => runDemoPhase(get, set, idx + 1), Math.max(900, ph.dur * scale * 1000))
  demoTimers.push(t)
}

function computeDemoSummary(get: () => AppState, set: (p: Partial<AppState>) => void, _idx: number) {
  const st = get()
  const t0 = st.demo.startT > 0 ? st.demo.startT : engine.simTime - 60 * 60000
  const pts = engine.history.filter(p => p.t >= t0)
  if (!pts.length) return
  const demandVals = pts.map(p => p.demand)
  const bl = baselineSeries(demandVals, engine.configs, engine.machines, () => 1, t0)
  const window = pts.length
  const actualPower = pts.map(p => p.power)
  const avgAi = actualPower.reduce((a, b) => a + b, 0) / window
  const avgBase = bl.power.reduce((a, b) => a + b, 0) / window
  const kwh = Math.max(0, (avgBase - avgAi)) * window / 60
  const priceAvg = newCtxPrice(st)
  const yuan = kwh * priceAvg
  const stdAi = r3(headerStdOf(engine, t0, engine.simTime))
  const stdBase = Math.max(st.baselineMetrics.headerStd, 0.18)
  const switches = st.planLog.filter(l => l.t >= t0).length
  const estBaselineSwitches = Math.round(st.baselineMetrics.estSwitchesPerDay * window / 1440)
  const summary: DemoSummary = {
    kwh: Math.round(kwh * 10) / 10, yuan: Math.round(yuan * 10) / 10,
    switchCuts: Math.max(0, estBaselineSwitches - switches),
    pressureImprovePct: Math.round(Math.max(0, (1 - stdAi / stdBase)) * 100),
    windowMin: window, aiStd: stdAi, baseStd: r3(stdBase),
    avgPowerAi: Math.round(avgAi), avgPowerBase: Math.round(avgBase),
  }
  set({ demo: { ...get().demo, summary } })
}

function newCtxPrice(st: AppState): number {
  const h = new Date(engine.simTime).getHours()
  return periodOfHour(st.priceCfg, h) === 'peak' ? st.priceCfg.peak : periodOfHour(st.priceCfg, h) === 'flat' ? st.priceCfg.flat : st.priceCfg.valley
}

const r3 = (v: number) => Math.round(v * 1000) / 1000
