# 用户指令记忆

本文件记录了用户的指令、偏好和教导，用于在未来的交互中提供参考。

## 格式

[条目摘要]
- Date: YYYY-MM-DD
- Context / Category / Instructions

## 条目

AirMind 竞赛最终验收
- Date: 2026-10-08
- Context: 最后一轮竞赛验收（含控制台错误、跨页一致、演示重启、十项场景、AI 溯源）
- Category: 测试方法
- Instructions:
  - 交付前跑 `tsx scripts/final-acceptance.tsx`（29 项）；其用 console 拦截检测真实渲染错误（过滤 React SSR 已知提示）
  - `insufficient.gap` 必须为正值且按「目标 - 可调度能力」计算（锁定分支用 schedulable 能力，禁止出现负缺口）
  - 仿真标注：顶栏“仿真数据”、预测“估计值”、报告“基于仿真数据生成”，三处不得缺失
  - 验收脚本避免用 toggle 语义做全故障（会误恢复）；用 `setMachineMode(id,'fault'|'auto')` 显式设置

AirMind 工程审查与统一口径
- Date: 2026-10-08
- Context: 全局工程审查与逻辑修复（统一状态、算法校验、自动测试）
- Category: 排错调试
- Instructions:
  - 参数与状态唯一来源：机组参数 `engine.configs`、状态 `engine.machines`、站级 `store.station`（stationSnapshot）、图表 `engine.history`；页面禁止自建随机数或独立状态（已核查 pages/components 无 Math.random）
  - 禁止硬编码：安全下限用 `engine.safeMin`、工作带用 `engine.bandLow/High`、罐压设定用 `plan.tankSetpoint`；能耗对比须同口径同电价（基准用 `result.baseline.specificPower`）
  - 无可执行方案时（`result.plans` 为空 / `insufficient`）不得标注为“推荐方案”，按钮禁用并提示恢复能力
  - 仿真/估计标注：预测页标注“估计值”，报告标注“基于仿真数据生成”，调度区标注基准/电价/周期
  - 回归必跑 `tsx scripts/scenarios.ts`（65 项，覆盖需求+20%/+40%/+4故障/低压/能力不足/峰谷/健康下降/报告一致）

AirMind 首页数据一致性口径
- Date: 2026-10-08
- Context: 驾驶舱数据一致性与展示逻辑修复
- Category: 排错调试
- Instructions:
  - 首页所有当前值必须取同一 tick 的 `useStore()` 快照：`s.station` 与 `engine.history` 末点严格相等（已由 dash-consistency 每 tick 校验）
  - 供气紧张判定集中在 `src/lib/dashboard.ts::liveDispatchFlags`（页面与测试共用，禁止页面内重复实现）：压力/缺口/可扩备用/供气裕度/低健康五类阈值+原因
  - 告警展示区分「当前告警」(与当前状态相符) 与「历史告警·已恢复」(带时间)；备用容量口径区分 供气裕度(reserveRatio) 与 可扩备用((可调度能力-需求)/需求)
  - 注意：React SSR 下 zustand 的 server snapshot 在同一进程内被冻结，SSR 字符串不能用于校验动态值；动态一致性用数据层断言或新建进程渲染，回归跑 `tsx scripts/dash-consistency.tsx`

AirMind 最终验收口径
- Date: 2026-10-07
- Context: 比赛交付前按真实用户操作链路的最终验收
- Category: 测试方法
- Instructions:
  - 交付前必须跑 `tsx scripts/acceptance.tsx`（35 项：需求800→预测→健康度→组合→+20%→A2故障→重调度→解释→报告 全链路，含 9 页 SSR 渲染、无空白/无 NaN、23 个动作实际调用无异常、图表与状态一致、store 结果与独立重算一致）
  - 备用容量口径区分：`reserveRatio`=供气裕度（(供气-需求)/需求）；可扩备用容量=(全网可调度能力-需求)/需求；UI 分别标注，不得混用

AirMind 一键演示与报告展示
- Date: 2026-10-07
- Context: 比赛展示功能（一键演示 10 阶段 + 12 章节调度报告）
- Category: 工作流协作
- Instructions:
  - 演示流程固定在 store 的 `DEMO_SCRIPT`（10 阶段），横幅跳转映射在 App 的 `NAVMAP`，二者必须同序对齐；演示起点记录 `demo.startT` 供结论汇总按真实窗口统计
  - 报告章节顺序为评审要求，如需调整须保证 12 主题不变；回归跑 `tsx scripts/demo-report.tsx`（演示端到端 + 报告章节齐全 + 无 NaN）

AirMind 工业级 UI 与响应式约束
- Date: 2026-10-07
- Context: 对首页与全站做工业驾驶舱视觉/响应式优化（不改算法与功能）
- Category: 工作流协作
- Instructions:
  - UI 优化只允许改 src/pages、src/components、src/theme.css、src/App.tsx，禁止触碰 src/lib 算法；改后必跑 tsc + ssr + 全套回归 + build
  - 各页大量使用内联网格（未带 .grid 类），响应式统一用属性选择器 `[style*="grid-template-columns"]` + !important 覆盖，断点 1180/900/720；侧栏 ≤1080 收起为图标栏，导航文字需包在 .nav-label
  - 首页三段式固定信息层级：总览 10 KPI / 设备区 6 字段 / 调度区前后对比，勿随意增删顺序

AirMind 修改后的强制验证链路
- Date: 2026-10-07
- Context: 参赛作品开发期确立的质量门禁；本环境无浏览器，页面正确性靠 SSR+无头数据流验证
- Category: 排错调试
- Instructions:
  - 每次改动 src/ 后按顺序执行：`npx tsc --noEmit` → `tsx scripts/sched-quality.ts`（调度最优性/8因子/换机权衡）→ `tsx scripts/soak.ts`（600tick 稳态罐压+节能回归）→ `tsx scripts/smoke.ts`→ `tsx scripts/scenario.ts`（9步验收场景）→ `tsx scripts/headless.ts`（store 时序压测）→ `tsx scripts/ssr.tsx`（9页面冷热数据渲染）→ `npm run build`
  - 任何一项 FAIL 先修复再继续，禁止只报告不修复
  - 预览部署：`nohup npm run dev > /tmp/vite.log 2>&1 &`，端口 5173（vite.config 已设 host 0.0.0.0 与 allowedHosts 通配 cosmoplat 各域），预览地址以端口结尾不带路径

AirMind 仿真模型关键不变量
- Date: 2026-10-07
- Context: Agent 调试"待机虚增功率 150kW 压没节能卖点"与"罐压顶格"时发现
- Category: 排错调试
- Instructions:
  - engine.tick 每个分支：非 running 机组必须 `continue` 并清零 flow/power/load 且累加 stopMinutes（standby=停机零耗电，只有 loaded=false 才计空载功率）；否则 station.power 虚高、节能率归零、图表失真
  - AI 模式三重保供禁泄漏叠加：applyPlan 需求封顶 ratio + gas envelope(≤demand*1.05) + 高压泄荷 applyPressureDrain/泄放阀 vent；改任一处都需 soak 验证罐压收敛
  - "节能率/省费"来自 estimateBaseline（级联+1.12 切换损耗）与 AI 实测功率差，禁止硬编码；用 `tsx scripts/soak.ts` 稳态回归：持续断供需=0、tank∈[6.4,10)、saved>0 才算通过
  - 优化器 DP 以 floor 离散+minFlow 校验保证总供气≥需求（供气下界= max(demand*1.01,f30,f60*0.97)-30 量化容差）；estimateBaseline 供 UI、rankMachinesForPlan 输出逐台决策与理由
  - 预测/健康度必须参与调度：预测经 f30/f60 进入 Dplan 并由 forecastPreDispatch 产出提前增机建议；健康度经 effectiveMax 限流、health 评分维度、dispatchCostFactor 成本系数三重参与，改动后须跑 `tsx scripts/forecast-health.ts`
  - AI 解释与对话必须跟随所选策略：调度页/助手页的 rec 取值 = adoptedKey==='auto' ? recommended : adoptedKey（不可写死 recommended），调度六问 `explainSixQuestions` 与对话回答全部引用实时数据且只允许出现 A1–A4，改动后须跑 `tsx scripts/assistant.ts`
  - 在 zustand selector 中禁止直接返回 `buildCtx()` 等新对象（会触发渲染告警/循环），统一用 `useMemo(() => useStore.getState().buildCtx(), [tickCount])`
  - 最小停机锁定放开条件必须按调度目标 `max(demand, f30, f60*0.97)` 判断（不能只看当前 demand），否则预测上行时备用机被锁定→无可行组合误报缺口；事件注入后统一调用 `rescheduleNow()` 即时重算，回归跑 `tsx scripts/events.ts`
  - DP 供气下界 `minFlow` 必须限制在搜索窗口内 `min(max(demandFloor,Dplan-30), target+3*D)`，且罐压>8.42 的 vent 会大幅压低 target——若 minFlow 用全需求会导致所有子集无解误报缺口（沙盘/助手空方案根因）；沙盘手动覆盖统一走后端 store（demandOverride/tankSetpointOverride/priceOverride/setMachineMode）并 `rescheduleNow()`，回归跑 `tsx scripts/sandbox.ts`
