#!/usr/bin/env bash
#
# AirMind 生产模式启动脚本
#   - 端口固定 5173（可用 PORT 覆盖）
#   - 已在运行 → 直接返回 0
#   - 启动成功 → 返回 0
#   - 启动失败 → 返回 2
#
set -u

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR" || exit 2

PORT="${PORT:-5173}"
HOST="${HOST:-0.0.0.0}"
LOG_DIR="$DIR/logs"
LOG_FILE="$LOG_DIR/app.log"
PID_FILE="$LOG_DIR/app.pid"
mkdir -p "$LOG_DIR"

is_running() {
  ss -ltn | grep -qE ":${PORT}([[:space:]]|$)"
}

# 1) 已启动则直接返回 0
if is_running; then
  echo "AirMind 已在运行（端口 ${PORT}），无需重复启动"
  exit 0
fi

echo "AirMind 未运行，开始生产模式启动（端口 ${PORT}）..."

# 2) 先停止可能残留的旧进程，避免端口被占用
"$DIR/stop.sh" || true

# 3) 清理构建缓存后执行生产构建（生产构建内存峰值可控，并用 --max-old-space-size 兜底）
rm -rf "$DIR/dist"
echo "执行生产构建：npm run build"
if ! NODE_OPTIONS="--max-old-space-size=1024" npm run build; then
  echo "构建失败，启动终止"
  exit 2
fi

if [ ! -f "$DIR/dist/index.html" ]; then
  echo "构建产物 dist/index.html 缺失，启动终止"
  exit 2
fi

# 4) 启动生产静态服务（环境变量先 export，再 nohup node，避免被 nohup 当作命令名；不使用 timeout）
export PORT HOST
echo "启动服务：node --max-old-space-size=256 server.mjs"
nohup node --max-old-space-size=256 "$DIR/server.mjs" > "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

# 5) 就绪探测（轮询端口 + HTTP 200，绝不用 timeout 包裹服务）
ready=0
i=1
while [ "$i" -le 60 ]; do
  if is_running; then
    code="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${PORT}/")"
    if [ "$code" = "200" ]; then
      ready=1
      break
    fi
  fi
  i=$((i + 1))
  sleep 0.5
done

if [ "$ready" = "1" ]; then
  echo "启动成功：http://${HOST}:${PORT}/（PID $(cat "$PID_FILE")）"
  exit 0
fi

echo "启动失败（端口未就绪或 HTTP 非 200）。最近日志："
tail -n 30 "$LOG_FILE" || true
"$DIR/stop.sh" || true
exit 2
